export const DZD_PER_USD = 220;
export const POINT_PRICE_USD = 0.002; // 500 نقطة = 1$
export const MIN_WITHDRAW_USD = 2; // قديم للتوافق
export const MIN_WITHDRAW_POINTS = 10000; // الحد الأدنى الجديد بالنقاط
export const POINTS_PER_DIAMOND = 50; // 5000 نقطة = 100 جوهرة
export const REFERRAL_BONUS_USD = 0.1;
export const REFERRAL_PERCENT = 10;

export function usdToPoints(usd: number | string) {
  const v = typeof usd === "string" ? parseFloat(usd) : usd;
  if (!v || isNaN(v)) return 1;
  return Math.max(1, Math.round(v / POINT_PRICE_USD));
}

export function pointsToUsd(pts: number | string) {
  const v = typeof pts === "string" ? parseInt(pts) : pts;
  if (!v || isNaN(v)) return 0;
  return v * POINT_PRICE_USD;
}

export function pointsToDzd(pts: number | string) {
  return usdToDzd(pointsToUsd(pts));
}

export function formatPoints(n: number | string) {
  const v = typeof n === "string" ? parseInt(n) : n;
  return `${(isNaN(v) ? 0 : v).toLocaleString("en")} نقطة`;
}

export function formatUsd(n: number | string) {
  const v = typeof n === "string" ? parseFloat(n) : n;
  return `$${(isNaN(v) ? 0 : v).toFixed(2)}`;
}

export function formatDzd(n: number | string) {
  const v = typeof n === "string" ? parseFloat(n) : n;
  return `${(isNaN(v) ? 0 : v).toFixed(0)} د.ج`;
}

export function usdToDzd(usd: number | string) {
  const v = typeof usd === "string" ? parseFloat(usd) : usd;
  return (isNaN(v) ? 0 : v) * DZD_PER_USD;
}

export const TASK_TYPE_LABELS: Record<string, { label: string; emoji: string; color: string }> = {
  ad_watch: { label: "مشاهدة إعلان", emoji: "📺", color: "from-amber-500 to-orange-500" },
  install_app: { label: "تحميل تطبيق", emoji: "📲", color: "from-sky-500 to-blue-600" },
  app_level: { label: "الوصول لمستوى", emoji: "🎮", color: "from-purple-500 to-fuchsia-600" },
  register_app: { label: "تسجيل في تطبيق", emoji: "📝", color: "from-emerald-500 to-teal-600" },
  follow_youtube: { label: "متابعة YouTube", emoji: "▶️", color: "from-red-500 to-rose-600" },
  follow_tiktok: { label: "متابعة TikTok", emoji: "🎵", color: "from-pink-500 to-fuchsia-600" },
  follow_telegram: { label: "انضمام Telegram", emoji: "✈️", color: "from-sky-400 to-blue-500" },
  other: { label: "مهمة أخرى", emoji: "✨", color: "from-slate-500 to-slate-600" },
};

export const FREEFIRE_POINTS_PACKAGES = [
  { id: "ff_100", label: "100 جوهرة", diamonds: 100, points: 5000 },
  { id: "ff_310", label: "310 جوهرة", diamonds: 310, points: 15500 },
  { id: "ff_520", label: "520 جوهرة", diamonds: 520, points: 26000 },
  { id: "ff_1060", label: "1060 جوهرة", diamonds: 1060, points: 53000 },
  { id: "ff_2180", label: "2180 جوهرة", diamonds: 2180, points: 109000 },
];

export const GAME_PACKAGES = {
  freefire: [
    { id: "ff_100", label: "100 جوهرة", usd: 0.99 },
    { id: "ff_310", label: "310 جوهرة", usd: 2.99 },
    { id: "ff_520", label: "520 جوهرة", usd: 4.99 },
    { id: "ff_1060", label: "1060 جوهرة", usd: 9.99 },
    { id: "ff_2180", label: "2180 جوهرة", usd: 19.99 },
  ],
  pubg: [
    { id: "pubg_60", label: "60 UC", usd: 0.99 },
    { id: "pubg_325", label: "325 UC", usd: 4.99 },
    { id: "pubg_660", label: "660 UC", usd: 9.99 },
    { id: "pubg_1800", label: "1800 UC", usd: 24.99 },
    { id: "pubg_3850", label: "3850 UC", usd: 49.99 },
  ],
} as const;

export const POINT_PACKAGES = [
  { points: 500, usd: 1 },
  { points: 1200, usd: 2 },
  { points: 3200, usd: 5 },
  { points: 7000, usd: 10 },
  { points: 15000, usd: 20 },
];
