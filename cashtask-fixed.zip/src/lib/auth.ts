import { eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users } from "@/db/schema";
import { cookies } from "next/headers";
import { randomBytes, timingSafeEqual, scrypt as scryptCb } from "crypto";
import { promisify } from "util";
import type { NextResponse } from "next/server";

const scrypt = promisify(scryptCb);

export const SESSION_COOKIE = "ct_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 30;

// scrypt is a slow, memory-hard hash (unlike plain SHA-256) which makes
// brute-forcing stolen password hashes far more expensive. No extra
// npm dependency needed — it ships with Node's built-in crypto module.
export async function hashPassword(password: string, salt: string) {
  const derived = (await scrypt(password, salt, 64)) as Buffer;
  return derived.toString("hex");
}

export function generateSalt() {
  return randomBytes(16).toString("hex");
}

export function generateReferralCode() {
  return randomBytes(4).toString("hex").toUpperCase();
}

export function generateSessionToken() {
  return randomBytes(32).toString("hex");
}

export function sessionCookieOptions(expiresAt: Date) {
  return {
    httpOnly: true, // JS on the page can no longer read the session token (blocks XSS token theft)
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production", // requires HTTPS in production
    path: "/",
    expires: expiresAt,
  };
}

export async function createSession(userId: number) {
  const token = generateSessionToken();
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  await db.insert(sessions).values({ token, userId, expiresAt });
  return { token, expiresAt };
}

export function applySessionCookie(
  res: NextResponse,
  token: string,
  expiresAt: Date
) {
  res.cookies.set(SESSION_COOKIE, token, sessionCookieOptions(expiresAt));
  return res;
}

export async function destroySession() {
  const c = await cookies();
  const token = c.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }
  c.delete(SESSION_COOKIE);
}

let guestCache: typeof users.$inferSelect | null = null;

export async function ensureGuestUser() {
  if (guestCache) return guestCache;
  const existing = await db
    .select()
    .from(users)
    .where(eq(users.username, "guest"))
    .limit(1);
  if (existing[0]) {
    guestCache = existing[0];
    return existing[0];
  }

  const salt = generateSalt();
  const hash = await hashPassword("guest123", salt);
  try {
    const inserted = await db
      .insert(users)
      .values({
        username: "guest",
        email: "guest@cashtask.app",
        passwordHash: hash,
        passwordSalt: salt,
        referralCode: "GUEST01",
        balance: "1.250000",
        points: 350,
        isAdmin: false,
      })
      .returning();
    guestCache = inserted[0];
    return inserted[0];
  } catch {
    const again = await db
      .select()
      .from(users)
      .where(eq(users.username, "guest"))
      .limit(1);
    if (again[0]) return again[0];
    const anyUser = await db.select().from(users).limit(1);
    if (anyUser[0]) return anyUser[0];
    throw new Error("NO_USER");
  }
}

export async function getSessionUser() {
  try {
    const c = await cookies();
    const token = c.get(SESSION_COOKIE)?.value;
    if (token) {
      const row = await db
        .select({
          token: sessions.token,
          expiresAt: sessions.expiresAt,
          user: users,
        })
        .from(sessions)
        .innerJoin(users, eq(users.id, sessions.userId))
        .where(eq(sessions.token, token))
        .limit(1);
      if (row[0] && row[0].expiresAt.getTime() >= Date.now()) {
        return row[0].user;
      }
    }
  } catch {
    /* ignore cookie errors */
  }
  return ensureGuestUser();
}

export function requireUser(user: Awaited<ReturnType<typeof getSessionUser>>) {
  if (!user) throw new Error("UNAUTHORIZED");
  return user;
}

export function requireAdmin(user: Awaited<ReturnType<typeof getSessionUser>>) {
  const u = requireUser(user);
  if (!u.isAdmin) throw new Error("FORBIDDEN");
  return u;
}

export function safeCompare(a: string, b: string) {
  if (a.length !== b.length) return false;
  return timingSafeEqual(Buffer.from(a), Buffer.from(b));
}
