// NOTE: this used to also mirror the session token into a JS-writable
// document.cookie, which completely defeats the httpOnly protection on
// the real session cookie (any XSS could then read it). That mirroring
// has been removed. The server's Set-Cookie response header (see
// src/lib/auth.ts) is the only thing that should ever set ct_session.
export function persistClientSession(_token: string) {
  // intentionally a no-op now — kept so existing call sites don't break.
}

export function clearClientSession() {
  try {
    localStorage.removeItem("ct_session");
  } catch {
    /* ignore */
  }
}
