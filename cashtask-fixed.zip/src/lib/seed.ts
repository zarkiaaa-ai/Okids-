import { randomBytes } from "crypto";
import { db } from "@/db";
import { ads, contests, tasks, users } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { generateSalt, hashPassword } from "@/lib/auth";

function generateReferralCode() {
  return randomBytes(4).toString("hex").toUpperCase();
}

let seeded = false;
let running: Promise<void> | null = null;

export async function seedIfEmpty() {
  if (seeded) return;
  if (running) return running;
  running = (async () => {
    await ensureAdmin();
    await ensureGuest();
    await ensureTasks();
    await ensureExtraOffers();
    await ensureAds();
    await ensureContests();
    seeded = true;
  })().catch((e) => {
    running = null;
    throw e;
  });
  return running;
}

async function ensureAdmin() {
  const existingAdmin = await db
    .select()
    .from(users)
    .where(eq(users.isAdmin, true))
    .limit(1);
  if (existingAdmin.length > 0) return;
  const salt = generateSalt();
  const hash = await hashPassword("admin123", salt);
  await db.insert(users).values({
    username: "admin",
    email: "admin@cashtask.app",
    passwordHash: hash,
    passwordSalt: salt,
    isAdmin: true,
    referralCode: generateReferralCode(),
    balance: "0",
    points: 0,
  });
  console.warn(
    "\n⚠️  تم إنشاء حساب مسؤول افتراضي: admin@cashtask.app / admin123" +
    "\n⚠️  غيّر كلمة المرور فوراً من صفحة /profile بعد أول تسجيل دخول — هذا الحساب معروف للعامة.\n"
  );
}

async function ensureGuest() {
  const existing = await db
    .select()
    .from(users)
    .where(eq(users.username, "guest"))
    .limit(1);
  if (existing.length > 0) return;
  const salt = generateSalt();
  const hash = await hashPassword("guest123", salt);
  try {
    await db.insert(users).values({
      username: "guest",
      email: "guest@cashtask.app",
      passwordHash: hash,
      passwordSalt: salt,
      isAdmin: false,
      referralCode: "GUEST01",
      balance: "1.250000",
      points: 350,
    });
  } catch {
    /* already exists */
  }
}

async function ensureTasks() {
  const [count] = await db.select({ c: sql<number>`count(*)::int` }).from(tasks);
  if ((count?.c || 0) > 0) return;

  await db.insert(tasks).values([
    {
      title: "تابع قناة Telegram الرسمية",
      description: "انضم إلى قناتنا على تيليجرام وابقَ مشتركاً.",
      type: "follow_telegram",
      reward: "0.05",
      targetUrl: "https://t.me/example",
      proofHint: "أدخل اسم المستخدم على تيليجرام",
    },
    {
      title: "تابع قناتنا على YouTube",
      description: "اشترك في القناة وفعّل الجرس.",
      type: "follow_youtube",
      reward: "0.08",
      targetUrl: "https://youtube.com/@example",
      proofHint: "رابط قناتك على يوتيوب",
    },
    {
      title: "تابعنا على TikTok",
      description: "تابع الحساب الرسمي وأرسل اسم المستخدم.",
      type: "follow_tiktok",
      reward: "0.05",
      targetUrl: "https://tiktok.com/@example",
      proofHint: "اسم المستخدم على تيك توك",
    },
    {
      title: "سجّل في تطبيق جديد",
      description: "أنشئ حساباً جديداً في التطبيق المرفق.",
      type: "register_app",
      reward: "0.80",
      targetUrl: "https://example.com/signup",
      proofHint: "لقطة شاشة بعد التسجيل",
    },
    {
      title: "حمّل لعبة واصل للمستوى 10",
      description: "نزّل اللعبة واصل للمستوى 10.",
      type: "app_level",
      reward: "1.50",
      targetUrl: "https://example.com/game",
      proofHint: "لقطة شاشة تظهر المستوى",
    },
    {
      title: "ثبّت تطبيق المحفظة",
      description: "حمّل التطبيق وسجّل حساباً جديداً.",
      type: "install_app",
      reward: "0.40",
      targetUrl: "https://example.com/wallet",
      proofHint: "صورة للشاشة الرئيسية",
    },
    {
      title: "استبيان قصير - رأي المستهلك",
      description: "أجب عن استبيان من 5 دقائق واحصل على النقاط.",
      type: "other",
      reward: "0.35",
      targetUrl: "https://example.com/survey",
      proofHint: "رمز إتمام الاستبيان",
    },
    {
      title: "ثبّت تطبيق التسوق وأكمل الطلب الأول",
      description: "مهمة Offerwall: ثبّت التطبيق وأكمل التسجيل.",
      type: "install_app",
      reward: "1.20",
      targetUrl: "https://example.com/shop",
      proofHint: "لقطة شاشة للتسجيل",
    },
  ]);
}

async function ensureExtraOffers() {
  const all = await db.select({ type: tasks.type, title: tasks.title }).from(tasks);
  const extra = [];
  if (!all.some((t) => t.type === "other")) {
    extra.push(
      { title: "استطلاع رأي المستهلك", description: "5 دقائق", type: "other", reward: "0.35", targetUrl: "https://example.com/survey", proofHint: "رمز الإتمام" },
      { title: "استطلاع تطبيقات الجوال", description: "أسئلة سريعة", type: "other", reward: "0.25", targetUrl: "https://example.com/survey2", proofHint: "رمز" },
      { title: "استطلاع عادات التسوق", description: "دقيقتان", type: "other", reward: "0.20", targetUrl: "https://example.com/survey3", proofHint: "رمز" }
    );
  }
  if (!all.some((t) => t.type === "app_level" && t.title.includes("20"))) {
    extra.push(
      { title: "لعبة أكشن — المستوى 20", description: "العب وتقدم", type: "app_level", reward: "2.00", targetUrl: "https://example.com/game2", proofHint: "لقطة المستوى" }
    );
  }
  if (extra.length) await db.insert(tasks).values(extra);
}

async function ensureAds() {
  const [count] = await db.select({ c: sql<number>`count(*)::int` }).from(ads);
  if ((count?.c || 0) > 0) return;
  await db.insert(ads).values([
    {
      title: "إعلان مكافأة 1",
      targetUrl: "https://example.com/ad1",
      reward: "0.005",
      requiredSeconds: 8,
      cooldownHours: 1,
    },
    {
      title: "إعلان مكافأة 2",
      targetUrl: "https://example.com/ad2",
      reward: "0.008",
      requiredSeconds: 10,
      cooldownHours: 2,
    },
    {
      title: "إعلان مكافأة 3",
      targetUrl: "https://example.com/ad3",
      reward: "0.010",
      requiredSeconds: 12,
      cooldownHours: 1,
    },
  ]);
}

async function ensureContests() {
  const [count] = await db.select({ c: sql<number>`count(*)::int` }).from(contests);
  if ((count?.c || 0) > 0) return;
  const ends = new Date();
  ends.setDate(ends.getDate() + 14);
  await db.insert(contests).values([
    {
      title: "مسابقة هاتف الشهر",
      description: "شارك بنقاطك للفوز بهاتف جديد.",
      prize: "هاتف ذكي",
      prizeValue: "250",
      entryCost: 50,
      endsAt: ends,
      active: true,
    },
  ]);
}
