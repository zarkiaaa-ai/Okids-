import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  numeric,
  varchar,
  index,
} from "drizzle-orm/pg-core";

// ============== المستخدمون ==============
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    username: varchar("username", { length: 64 }).notNull().unique(),
    email: varchar("email", { length: 191 }).notNull().unique(),
    passwordHash: text("password_hash").notNull(),
    passwordSalt: text("password_salt").notNull(),
    balance: numeric("balance", { precision: 20, scale: 6 }).notNull().default("0"), // رصيد قابل للسحب (بالدولار)
    points: integer("points").notNull().default(0), // نقاط للمشاركة في المسابقات
    referralCode: varchar("referral_code", { length: 16 }).notNull().unique(),
    referredBy: integer("referred_by"),
    isAdmin: boolean("is_admin").notNull().default(false),
    telegram: varchar("telegram", { length: 120 }),
    usdtAddress: varchar("usdt_address", { length: 200 }),
    ccpRip: varchar("ccp_rip", { length: 40 }),
    gameFreefireId: varchar("game_freefire_id", { length: 60 }),
    gamePubgId: varchar("game_pubg_id", { length: 60 }),
    displayName: varchar("display_name", { length: 64 }),
    avatarUrl: text("avatar_url"),
    language: varchar("language", { length: 8 }).notNull().default("ar"),
    notifications: boolean("notifications").notNull().default(true),
    lastDailyAt: timestamp("last_daily_at"),
    dailyStreak: integer("daily_streak").notNull().default(0),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    refIdx: index("users_referred_by_idx").on(t.referredBy),
    pointsIdx: index("users_points_idx").on(t.points),
  })
);

// ============== المهام ==============
export type TaskType =
  | "ad_watch"
  | "install_app"
  | "app_level"
  | "register_app"
  | "follow_youtube"
  | "follow_tiktok"
  | "follow_telegram"
  | "other";

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  type: varchar("type", { length: 40 }).notNull(),
  reward: numeric("reward", { precision: 14, scale: 6 }).notNull(), // بالدولار
  targetUrl: text("target_url"),
  proofHint: text("proof_hint"), // تلميح لما يجب رفعه كدليل
  maxCompletions: integer("max_completions"), // null = غير محدود
  currentCompletions: integer("current_completions").notNull().default(0),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ============== إكمالات المهام ==============
export type CompletionStatus = "pending" | "approved" | "rejected";
export const taskCompletions = pgTable(
  "task_completions",
  {
    id: serial("id").primaryKey(),
    taskId: integer("task_id")
      .notNull()
      .references(() => tasks.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    proofText: text("proof_text"), // رابط/اسم/لقطة
    status: varchar("status", { length: 20 }).notNull().default("pending"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
    reviewedAt: timestamp("reviewed_at"),
  },
  (t) => ({
    userTaskIdx: index("tc_user_task_idx").on(t.userId, t.taskId),
    userStatusIdx: index("tc_user_status_idx").on(t.userId, t.status),
  })
);

// ============== الإعلانات ==============
export const ads = pgTable("ads", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  imageUrl: text("image_url"),
  targetUrl: text("target_url"),
  reward: numeric("reward", { precision: 14, scale: 6 }).notNull().default("0.005"),
  requiredSeconds: integer("required_seconds").notNull().default(15),
  cooldownHours: integer("cooldown_hours").notNull().default(24),
  active: boolean("active").notNull().default(true),
});

export const adViews = pgTable(
  "ad_views",
  {
    id: serial("id").primaryKey(),
    adId: integer("ad_id")
      .notNull()
      .references(() => ads.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    earned: numeric("earned", { precision: 14, scale: 6 }).notNull(),
    viewedAt: timestamp("viewed_at").notNull().defaultNow(),
  },
  (t) => ({
    userAdIdx: index("adviews_user_ad_idx").on(t.userId, t.adId),
    userViewedIdx: index("adviews_user_viewed_idx").on(t.userId, t.viewedAt),
  })
);

// ============== المسابقات ==============
export const contests = pgTable("contests", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  prize: text("prize").notNull(), // "iPhone 15 Pro" مثلاً
  prizeValue: numeric("prize_value", { precision: 14, scale: 2 }), // قيمة الجائزة بالدولار للعرض
  entryCost: integer("entry_cost").notNull().default(100), // نقاط
  maxEntries: integer("max_entries"), // null = غير محدود
  currentEntries: integer("current_entries").notNull().default(0),
  endsAt: timestamp("ends_at").notNull(),
  winnerUserId: integer("winner_user_id"),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const contestEntries = pgTable(
  "contest_entries",
  {
    id: serial("id").primaryKey(),
    contestId: integer("contest_id")
      .notNull()
      .references(() => contests.id, { onDelete: "cascade" }),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    pointsSpent: integer("points_spent").notNull(),
    enteredAt: timestamp("entered_at").notNull().defaultNow(),
  },
  (t) => ({
    userContestIdx: index("ce_user_contest_idx").on(t.userId, t.contestId),
  })
);

// ============== السحب ==============
export type WithdrawMethod = "usdt" | "ccp";
export type WithdrawStatus = "pending" | "completed" | "rejected";

export const withdrawals = pgTable("withdrawals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  method: varchar("method", { length: 20 }).notNull(),
  amount: numeric("amount", { precision: 20, scale: 6 }).notNull(),
  address: text("address").notNull(),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
}, (t) => ({
  userStatusIdx: index("wd_user_status_idx").on(t.userId, t.status),
  statusIdx: index("wd_status_idx").on(t.status),
}));

// ============== شحن الألعاب ==============
export type TopupStatus = "pending" | "completed" | "rejected";
export const gameTopups = pgTable("game_topups", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  game: varchar("game", { length: 40 }).notNull(), // freefire | pubg
  playerId: varchar("player_id", { length: 120 }).notNull(),
  packageLabel: text("package_label").notNull(), // "100 جوهرة"
  priceUsd: numeric("price_usd", { precision: 14, scale: 6 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
}, (t) => ({
  userStatusIdx: index("gt_user_status_idx").on(t.userId, t.status),
}));

// ============== شراء النقاط ==============
export type PurchaseMethod = "usdt" | "ccp";
export type PurchaseStatus = "pending" | "completed" | "rejected";

export const pointPurchases = pgTable("point_purchases", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  points: integer("points").notNull(),
  priceUsd: numeric("price_usd", { precision: 14, scale: 6 }).notNull(),
  priceDzd: numeric("price_dzd", { precision: 14, scale: 2 }).notNull(),
  method: varchar("method", { length: 20 }).notNull(),
  txId: text("tx_id"), // رقم العملية أو مرجع
  status: varchar("status", { length: 20 }).notNull().default("pending"),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  processedAt: timestamp("processed_at"),
}, (t) => ({
  userStatusIdx: index("pp_user_status_idx").on(t.userId, t.status),
}));

// ============== إعدادات الموقع ==============
export const siteSettings = pgTable("site_settings", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ============== جلسات المستخدمين ==============
export const sessions = pgTable("sessions", {
  token: varchar("token", { length: 64 }).primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
