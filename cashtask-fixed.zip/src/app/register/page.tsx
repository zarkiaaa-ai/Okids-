"use client";

import Link from "next/link";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

function RegisterInner() {
  const router = useRouter();
  const params = useSearchParams();
  const refParam = (params.get("ref") || "").trim().toUpperCase();
  const [code, setCode] = useState(refParam);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setCode(refParam);
  }, [refParam]);

  async function applyAndEnter() {
    setMsg(null);
    const c = code.trim().toUpperCase();
    if (!c) {
      router.push("/");
      return;
    }
    setLoading(true);
    try {
      const r = await fetch("/api/referrals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "apply", code: c }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) {
        setMsg({ tone: "err", text: j.error || "تعذر ربط الدعوة" });
        return;
      }
      setMsg({
        tone: "ok",
        text: j.already
          ? "حسابك مربوط بدعوة مسبقاً — جاري الدخول..."
          : `تم قبول دعوة ${j.inviter ? `صديقك (${j.inviter})` : "صديقك"} — جاري الدخول...`,
      });
      setTimeout(() => router.push("/"), 900);
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال — حاول مجدداً" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-black text-white flex items-center justify-center px-4">
      <div className="w-full max-w-md space-y-4">
        <div className="text-center">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-[#c4122f] flex items-center justify-center font-black text-2xl">
            C
          </div>
          <h1 className="text-2xl font-black mt-3">انضم وابدأ الربح 🎉</h1>
          <p className="text-sm text-zinc-400 mt-2 leading-7">
            {refParam
              ? "وصلت عبر رابط دعوة — أدخل التطبيق وسيُحتسب صديقك كداعٍ لك."
              : "أدخل كود دعوة صديقك إن وجد، أو ادخل مباشرة."}
          </p>
        </div>

        <div className="card-dark p-5 space-y-3">
          <label className="block">
            <span className="block text-xs text-zinc-400 mb-1.5 font-bold">كود الدعوة (اختياري)</span>
            <input
              className="inp-dark text-center font-black tracking-[0.25em]"
              dir="ltr"
              placeholder="GUEST01"
              value={code}
              maxLength={16}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
            />
          </label>

          {msg && (
            <div
              className={`rounded-xl border px-3 py-2.5 text-[13px] ${
                msg.tone === "ok"
                  ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
                  : "bg-red-500/10 border-red-500/30 text-red-300"
              }`}
            >
              {msg.text}
            </div>
          )}

          <button
            type="button"
            disabled={loading}
            onClick={applyAndEnter}
            className="w-full py-3.5 rounded-2xl bg-[#c4122f] font-black press disabled:opacity-50"
          >
            {loading ? "جاري الدخول..." : code ? "تأكيد الدعوة والدخول" : "ادخل التطبيق"}
          </button>

          <Link href="/" className="block text-center text-xs text-zinc-400 press">
            دخول بدون كود →
          </Link>
        </div>

        <p className="text-center text-[11px] text-zinc-600 leading-6">
          بالدخول تحصل على 10% عمولة لصديقك عن نشاطك الحقيقي فقط
        </p>
      </div>
    </main>
  );
}

export default function RegisterPage() {
  return (
    <Suspense
      fallback={
        <main className="min-h-screen bg-black text-white flex items-center justify-center">
          <div className="text-sm text-zinc-400">جاري التحميل...</div>
        </main>
      }
    >
      <RegisterInner />
    </Suspense>
  );
}
