import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { ThemeProvider } from "@/components/ThemeProvider";
import { LanguageProvider } from "@/components/LanguageProvider";
import { SessionBridge } from "@/components/SessionBridge";

export const metadata: Metadata = {
  title: "CashTask - اربح المال من المهام والإعلانات",
  description: "أكمل المهام، شاهد الإعلانات، ادعُ أصدقاءك، واسحب عبر USDT أو CCP.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "CashTask", statusBarStyle: "black" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  colorScheme: "light dark",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f7faff" },
    { media: "(prefers-color-scheme: dark)", color: "#020617" },
  ],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <meta name="color-scheme" content="light dark" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap"
          rel="stylesheet"
        />
        <script
          dangerouslySetInnerHTML={{
            __html: `try{if(localStorage.getItem('theme')==='dark'){document.documentElement.classList.add('dark');document.documentElement.style.colorScheme='dark'}var l=localStorage.getItem('lang');if(l==='en'||l==='fr'){document.documentElement.lang=l;document.documentElement.dir='ltr'}}catch(e){}`,
          }}
        />
      </head>
      <body className="bg-app text-primary min-h-screen">
        <ThemeProvider>
          <LanguageProvider>
            <SessionBridge />
            {children}
          </LanguageProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
