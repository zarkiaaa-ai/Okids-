export default function Loading() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-app">
      <div className="text-center">
        <div className="text-5xl mb-3">💰</div>
        <p className="font-black text-lg">CashTask</p>
        <p className="text-sm text-muted mt-1">جاري التحميل...</p>
      </div>
    </main>
  );
}
