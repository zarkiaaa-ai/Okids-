"use client";

import { useEffect } from "react";

// This page used to check a password that was hardcoded in the client
// bundle (visible to anyone via view-source / devtools) and has been
// retired for that reason. Admins now sign in with their real account
// through the normal /login page — /admin checks the isAdmin flag on
// their session server-side (see src/lib/auth.ts: requireAdmin).
export default function AdminLoginRedirect() {
  useEffect(() => {
    window.location.href = "/login?next=/admin";
  }, []);

  return (
    <main className="min-h-screen flex items-center justify-center px-4 bg-slate-950 text-white">
      <p className="text-slate-400">يتم تحويلك لتسجيل الدخول...</p>
    </main>
  );
}
