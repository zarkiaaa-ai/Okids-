"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";
import { Notice, SkeletonList, StatusPill, TopBar } from "@/components/ui";

type Pkg = { id: string; label: string; diamonds: number; points: number };
type Topup = { id: number; packageLabel: string; playerId: string; status: string; createdAt: string };

export default function DiamondsPage() {
  const ov = useOverview();
  const [pkgs, setPkgs] = useState<Pkg[]>([]);
  const [rows, setRows] = useState<Topup[]>([]);
  const [playerId, setPlayerId] = useState("");
  const [pkgId, setPkgId] = useState("");
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [sending, setSending] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [m, t] = await Promise.allSettled([
        fetch("/api/me").then((r) => r.json()),
        fetch("/api/topup").then((r) => r.json()),
      ]);
      if (m.status === "fulfilled" && m.value.user?.gameFreefireId) setPlayerId(m.value.user.gameFreefireId);
      if (t.status === "fulfilled") {
        setPkgs(t.value.packages || []);
        setRows(t.value.topups || []);
        if (!pkgId && t.value.packages?.length) setPkgId(t.value.packages[0].id);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const pkg = pkgs.find((p) => p.id === pkgId);

  async function submit() {
    setMsg(null);
    if (!pkg) return;
    if (!playerId.trim()) {
      setMsg({ tone: "err", text: "أدخل ID لاعب Free Fire" });
      return;
    }
    if (ov.data.points < pkg.points) {
      setMsg({ tone: "err", text: `تحتاج ${pkg.points.toLocaleString()} نقطة — رصيدك ${ov.data.points.toLocaleString()}` });
      return;
    }
    setSending(true);
    try {
      const r = await fetch("/api/topup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "request", packageId: pkg.id, playerId }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الطلب" });
      else {
        setMsg({ tone: "ok", text: `تم طلب ${pkg.label} — الشحن خلال 24-72 ساعة` });
        bustOverviewCache();
        ov.refresh(true);
        load();
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar
        title="شحن الجواهر 💎"
        fallback="/withdraw"
        action={
          <div className="text-xs bg-white/10 rounded-full px-3 py-1.5 tabular-nums whitespace-nowrap">
            <b>{ov.data.points.toLocaleString()}</b> 🪙
          </div>
        }
      />

      <div className="rounded-2xl bg-fuchsia-500/10 border border-fuchsia-500/25 p-3 text-[12px] leading-6 text-fuchsia-200">
        كل <b>5,000 نقطة = 100 جوهرة</b> — أدخل ID اللاعب بدقة، الشحن يدوي خلال 24-72 ساعة.
      </div>

      {loading ? (
        <SkeletonList rows={3} />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2">
            {pkgs.map((p) => {
              const afford = ov.data.points >= p.points;
              return (
                <button
                  key={p.id}
                  onClick={() => setPkgId(p.id)}
                  className={`p-3.5 rounded-2xl border text-right press ${
                    pkgId === p.id ? "border-fuchsia-500 bg-fuchsia-500/10" : "border-white/10 bg-[#141416]"
                  } ${!afford ? "opacity-60" : ""}`}
                >
                  <div className="font-black">💎 {p.label}</div>
                  <div className="text-xs text-amber-300 mt-1 tabular-nums">{p.points.toLocaleString()} نقطة</div>
                </button>
              );
            })}
          </div>

          <input className="inp-dark tabular-nums" dir="ltr" placeholder="Free Fire Player ID" value={playerId} onChange={(e) => setPlayerId(e.target.value)} />

          {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}

          <button disabled={sending || !pkg} onClick={submit} className="w-full py-3.5 rounded-2xl bg-[#c4122f] font-black press disabled:opacity-50">
            {sending ? "جاري..." : pkg ? `شحن ${pkg.label}` : "اختر باقة"}
          </button>

          {rows.length > 0 && (
            <div>
              <div className="font-black text-[15px] mb-2">طلبات الشحن</div>
              <div className="space-y-2">
                {rows.slice(0, 6).map((t) => (
                  <div key={t.id} className="card-dark p-3.5 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-bold text-sm">💎 {t.packageLabel}</div>
                      <div className="text-[11px] text-zinc-500 mt-0.5">ID: {t.playerId} · {new Date(t.createdAt).toLocaleDateString("ar")}</div>
                    </div>
                    <StatusPill status={t.status} />
                  </div>
                ))}
              </div>
            </div>
          )}

          <Link href="/withdraw" className="block text-center text-xs text-zinc-400">
            أو اشحن الجواهر من المحفظة →
          </Link>
        </>
      )}
    </div>
  );
}
