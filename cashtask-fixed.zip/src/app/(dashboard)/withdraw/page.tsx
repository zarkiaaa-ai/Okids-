"use client";

import { useEffect, useMemo, useState } from "react";
import {
  MIN_WITHDRAW_POINTS,
  FREEFIRE_POINTS_PACKAGES,
  pointsToUsd,
  pointsToDzd,
  usdToPoints,
} from "@/lib/constants";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";
import { Notice, ProgressRing, Segmented, SkeletonList, StatusPill } from "@/components/ui";

type Withdrawal = { id: number; method: string; amount: string; address: string; status: string; createdAt: string };
type Topup = { id: number; game: string; packageLabel: string; playerId: string; status: string; createdAt: string };
type Completion = { taskTitle: string; reward: string; status: string; createdAt: string };

type FeedItem = { key: string; date: string; title: string; sub: string; pts: number; kind: "in" | "out" | "lock" };

export default function WalletPage() {
  const ov = useOverview();
  const [tab, setTab] = useState<"activity" | "payouts">("activity");
  const [cashOpen, setCashOpen] = useState(false);
  const [method, setMethod] = useState<"usdt" | "ccp" | "freefire">("usdt");
  const [address, setAddress] = useState("");
  const [playerId, setPlayerId] = useState("");
  const [amountPts, setAmountPts] = useState("");
  const [pkgId, setPkgId] = useState("ff_100");
  const [rows, setRows] = useState<Withdrawal[]>([]);
  const [topups, setTopups] = useState<Topup[]>([]);
  const [feed, setFeed] = useState<FeedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [sending, setSending] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const [m, w, c] = await Promise.allSettled([
        fetch("/api/me").then((r) => r.json()),
        fetch("/api/withdraw").then((r) => r.json()),
        fetch("/api/tasks?my=1").then((r) => r.json()),
      ]);
      if (m.status === "fulfilled" && m.value.user) {
        if (m.value.user.usdtAddress) setAddress((a) => a || m.value.user.usdtAddress);
        if (m.value.user.gameFreefireId) setPlayerId((p) => p || m.value.user.gameFreefireId);
      }
      const wr: Withdrawal[] = w.status === "fulfilled" ? w.value.withdrawals || [] : [];
      const tp: Topup[] = w.status === "fulfilled" ? w.value.topups || [] : [];
      setRows(wr);
      setTopups(tp);
      const comps: Completion[] = c.status === "fulfilled" ? c.value.completions || [] : [];
      const items: FeedItem[] = [
        ...comps
          .filter((x) => x.status === "approved" || x.status === "pending")
          .map((x, i) => ({
            key: `c${i}-${x.createdAt}`,
            date: x.createdAt,
            title: x.taskTitle,
            sub: x.status === "approved" ? "مهمة مقبولة" : "بانتظار المراجعة",
            pts: usdToPoints(x.reward || "0"),
            kind: (x.status === "approved" ? "in" : "lock") as FeedItem["kind"],
          })),
        ...wr.map((x) => ({
          key: `w${x.id}`,
          date: x.createdAt,
          title: `سحب ${x.method === "usdt" ? "USDT" : x.method === "ccp" ? "CCP" : x.method}`,
          sub: x.status === "pending" ? "قيد التنفيذ" : x.status === "completed" ? "تم التحويل" : "مرفوض",
          pts: -Math.abs(usdToPoints(x.amount || "0")),
          kind: "out" as const,
        })),
        ...tp.map((x) => ({
          key: `t${x.id}`,
          date: x.createdAt,
          title: `💎 ${x.packageLabel}`,
          sub: x.status === "pending" ? "قيد الشحن" : x.status === "completed" ? "تم الشحن" : "مرفوض",
          pts: 0,
          kind: "lock" as const,
        })),
      ];
      items.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setFeed(items.slice(0, 12));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const points = ov.data.points;
  const amountNum = Math.floor(Number(amountPts) || 0);
  const usdEq = pointsToUsd(amountNum);
  const pkg = FREEFIRE_POINTS_PACKAGES.find((p) => p.id === pkgId);
  const month = useMemo(() => new Date().toLocaleDateString("ar", { month: "long" }), []);
  const rest = Math.max(0, MIN_WITHDRAW_POINTS - points);

  async function submitMoney() {
    setMsg(null);
    if (!amountNum || amountNum < MIN_WITHDRAW_POINTS) {
      setMsg({ tone: "err", text: `الحد الأدنى ${MIN_WITHDRAW_POINTS.toLocaleString()} نقطة` });
      return;
    }
    if (amountNum > points) {
      setMsg({ tone: "err", text: "نقاطك غير كافية" });
      return;
    }
    if (!address.trim()) {
      setMsg({ tone: "err", text: method === "usdt" ? "أدخل عنوان USDT (TRC20)" : "أدخل رقم حساب CCP" });
      return;
    }
    // حفظ العنوان تلقائياً للمرات القادمة
    fetch("/api/me", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(method === "usdt" ? { usdtAddress: address.trim() } : { ccpRip: address.trim() }),
    }).catch(() => {});
    setSending(true);
    try {
      const r = await fetch("/api/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "request", method, points: amountNum, address }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الطلب" });
      else {
        setMsg({ tone: "ok", text: "تم إرسال طلب الصرف — يصلك خلال 24-72 ساعة بعد المراجعة" });
        setAmountPts("");
        setCashOpen(false);
        bustOverviewCache();
        ov.refresh(true);
        load();
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setSending(false);
    }
  }

  async function submitDiamonds() {
    setMsg(null);
    if (!pkg) return;
    if (!playerId.trim()) {
      setMsg({ tone: "err", text: "أدخل ID لاعب Free Fire" });
      return;
    }
    if (points < pkg.points) {
      setMsg({ tone: "err", text: `تحتاج ${pkg.points.toLocaleString()} نقطة` });
      return;
    }
    setSending(true);
    try {
      const r = await fetch("/api/withdraw", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "request", method: "freefire", packageId: pkg.id, playerId }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الطلب" });
      else {
        setMsg({ tone: "ok", text: `تم طلب ${pkg.label} — الشحن خلال 24-72 ساعة` });
        setCashOpen(false);
        bustOverviewCache();
        ov.refresh(true);
        load();
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white">
      <div className="bg-gradient-to-b from-[#1c3d32] to-black pt-4 pb-8 px-4">
        <h1 className="text-center text-xl font-black">المحفظة</h1>
        <div className="mt-4">
          <ProgressRing
            value={points}
            max={MIN_WITHDRAW_POINTS}
            label={`${points.toLocaleString()}`}
            sub={rest > 0 ? `متبقٍ ${rest.toLocaleString()} نقطة للسحب · ${pointsToUsd(points).toFixed(2)}$` : "جاهز للسحب 🎉"}
          />
        </div>
        <div className="text-center text-[11px] text-zinc-400 mt-2">
          500 نقطة = 1$ · 5,000 نقطة = 100 جوهرة 💎 · الحد الأدنى {MIN_WITHDRAW_POINTS.toLocaleString()} نقطة
        </div>
      </div>

      <div className="px-4 -mt-2 space-y-4 pb-6">
        <button onClick={() => setCashOpen((v) => !v)} className="w-full py-4 rounded-2xl bg-[#3d8f6e] text-white text-lg font-black press">
          {cashOpen ? "إغلاق" : "صرف النقود"}
        </button>

        {cashOpen && (
          <div className="card-dark p-4 space-y-3 fade-up">
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: "usdt", t: "USDT" },
                { id: "ccp", t: "CCP" },
                { id: "freefire", t: "💎 جواهر" },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setMethod(m.id as typeof method)}
                  className={`py-2.5 rounded-xl font-bold text-sm press ${method === m.id ? "bg-[#3d8f6e] text-white" : "bg-white/5 text-zinc-400"}`}
                >
                  {m.t}
                </button>
              ))}
            </div>

            {method === "freefire" ? (
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  {FREEFIRE_POINTS_PACKAGES.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setPkgId(p.id)}
                      className={`p-3 rounded-xl border text-right press ${pkgId === p.id ? "border-emerald-500 bg-emerald-500/10" : "border-white/10 bg-white/5"}`}
                    >
                      <div className="font-black text-sm">💎 {p.label}</div>
                      <div className="text-xs text-amber-300 mt-1 tabular-nums">{p.points.toLocaleString()} نقطة</div>
                    </button>
                  ))}
                </div>
                <input className="inp-dark" dir="ltr" placeholder="ID لاعب Free Fire" value={playerId} onChange={(e) => setPlayerId(e.target.value)} />
                {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}
                <button disabled={sending} onClick={submitDiamonds} className="w-full py-3 rounded-xl bg-white text-black font-black press disabled:opacity-50">
                  {sending ? "جاري..." : `شحن ${pkg?.label}`}
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="grid grid-cols-4 gap-1.5">
                  {[10000, 20000, 50000].map((v) => (
                    <button key={v} onClick={() => setAmountPts(String(v))} className="py-2 rounded-lg bg-white/5 text-xs font-bold tabular-nums press">
                      {v.toLocaleString()}
                    </button>
                  ))}
                  <button onClick={() => setAmountPts(String(points))} className="py-2 rounded-lg bg-white/5 text-xs font-bold press">الكل</button>
                </div>
                <input className="inp-dark tabular-nums" type="number" dir="ltr" placeholder="عدد النقاط — مثال 10000" value={amountPts} onChange={(e) => setAmountPts(e.target.value)} />
                {amountNum > 0 && (
                  <div className="text-[11px] text-zinc-400 tabular-nums">
                    ≈ ${usdEq.toFixed(2)} · {pointsToDzd(amountNum).toFixed(0)} د.ج
                  </div>
                )}
                <input
                  className="inp-dark"
                  dir="ltr"
                  placeholder={method === "usdt" ? "عنوان USDT (TRC20)" : "رقم حساب CCP"}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
                {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}
                <button disabled={sending} onClick={submitMoney} className="w-full py-3 rounded-xl bg-white text-black font-black press disabled:opacity-50">
                  {sending ? "جاري..." : "تأكيد الصرف"}
                </button>
              </div>
            )}
          </div>
        )}

        <Segmented
          value={tab}
          onChange={setTab}
          options={[
            { id: "activity", label: "النشاط" },
            { id: "payouts", label: "المدفوعات" },
          ]}
        />

        {loading ? (
          <SkeletonList rows={4} />
        ) : tab === "activity" ? (
          <div>
            <div className="text-zinc-400 text-sm mb-2">{month}</div>
            {feed.length === 0 ? (
              <div className="card-dark p-8 text-center text-sm text-zinc-400">
                لا نشاط بعد — أكمل مهمة من صفحة <b>يكسب</b> وستظهر هنا
              </div>
            ) : (
              <div className="card-dark divide-y divide-white/5 overflow-hidden">
                {feed.map((f) => (
                  <div key={f.key} className="flex items-center justify-between px-4 py-3.5 gap-2">
                    <div className="min-w-0">
                      <div className="font-bold text-sm truncate">{f.title}</div>
                      <div className="text-[11px] text-zinc-500 mt-0.5">{f.sub} · {new Date(f.date).toLocaleDateString("ar")}</div>
                    </div>
                    <div
                      className={`font-black tabular-nums text-sm whitespace-nowrap ${
                        f.kind === "in" ? "text-emerald-400" : f.kind === "out" ? "text-red-400" : "text-amber-300"
                      }`}
                    >
                      {f.kind === "out" ? "−" : f.kind === "in" ? "+" : "⏳ "}
                      {f.pts !== 0 ? `${Math.abs(f.pts).toLocaleString()} 🪙` : ""}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            {rows.length === 0 && topups.length === 0 ? (
              <div className="card-dark p-8 text-center text-sm text-zinc-400">لا مدفوعات بعد</div>
            ) : (
              <>
                {rows.map((w) => (
                  <div key={`w${w.id}`} className="card-dark p-4 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-black text-sm tabular-nums">
                        {(w.address.match(/([\d,]+) نقطة/) || [])[1]
                          ? `${(w.address.match(/([\d,]+) نقطة/) as RegExpMatchArray)[1]} نقطة`
                          : `$${w.amount}`} · {w.method === "usdt" ? "USDT" : w.method === "ccp" ? "CCP" : w.method}
                      </div>
                      <div className="text-[11px] text-zinc-500 mt-0.5">{new Date(w.createdAt).toLocaleDateString("ar")}</div>
                    </div>
                    <StatusPill status={w.status} />
                  </div>
                ))}
                {topups.map((t) => (
                  <div key={`t${t.id}`} className="card-dark p-4 flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-black text-sm">💎 {t.packageLabel}</div>
                      <div className="text-[11px] text-zinc-500 mt-0.5">ID: {t.playerId}</div>
                    </div>
                    <StatusPill status={t.status} />
                  </div>
                ))}
              </>
            )}
          </div>
        )}

        <p className="text-center text-[11px] text-zinc-600">
          الصرف بالنقاط فقط · المراجعة خلال 24-72 ساعة · احفظ عناوينك في الإعدادات
        </p>
      </div>
    </div>
  );
}
