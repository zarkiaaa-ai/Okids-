"use client";

import { EarnScreen } from "@/components/EarnScreen";

export default function HomePage() {
  return <EarnScreen />;
}
