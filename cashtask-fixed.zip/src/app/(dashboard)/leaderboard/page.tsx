"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { SkeletonList, TopBar } from "@/components/ui";

type Row = { id: number; username: string; displayName: string | null; points: number; approved: number };

const MEDAL = ["🥇", "🥈", "🥉"];

export default function LeaderboardPage() {
  const [top, setTop] = useState<Row[]>([]);
  const [myRank, setMyRank] = useState<number | null>(null);
  const [myPoints, setMyPoints] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((j) => {
        setTop(j.top || []);
        setMyRank(j.myRank ?? null);
        setMyPoints(j.myPoints || 0);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar
        title="لوحة الصدارة 🏆"
        sub="أكثر المستخدمين نقاطاً — أكمل المهام لتصعد الترتيب"
        fallback="/profile"
      />

      {myRank !== null && (
        <div className="rounded-2xl bg-amber-400/10 border border-amber-400/25 p-3.5 flex items-center justify-between">
          <span className="text-sm font-bold">ترتيبك الحالي</span>
          <span className="font-black tabular-nums">#{myRank} · {myPoints.toLocaleString()} 🪙</span>
        </div>
      )}

      {loading ? (
        <SkeletonList rows={6} />
      ) : top.length === 0 ? (
        <div className="card-dark p-10 text-center text-sm text-zinc-400">لا بيانات بعد</div>
      ) : (
        <div className="space-y-2">
          {top.slice(0, 3).map((u, i) => (
            <div
              key={u.id}
              className={`rounded-2xl p-4 flex items-center gap-3 border ${
                i === 0 ? "bg-amber-400/10 border-amber-400/40" : "card-dark"
              }`}
            >
              <span className="text-3xl">{MEDAL[i]}</span>
              <div className="flex-1 min-w-0">
                <div className="font-black truncate">{u.displayName || u.username}</div>
                <div className="text-[11px] text-zinc-400">{u.approved} مهمة مقبولة</div>
              </div>
              <div className="font-black tabular-nums text-amber-300">{u.points.toLocaleString()} 🪙</div>
            </div>
          ))}
          {top.slice(3).map((u, i) => (
            <div key={u.id} className="card-dark px-4 py-3 flex items-center gap-3">
              <span className="w-7 text-center font-black text-zinc-500 tabular-nums">{i + 4}</span>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-sm truncate">{u.displayName || u.username}</div>
              </div>
              <div className="font-black text-sm tabular-nums">{u.points.toLocaleString()} 🪙</div>
            </div>
          ))}
        </div>
      )}

      <Link href="/" className="block text-center text-xs text-zinc-400">
        ← عودة إلى يكسب
      </Link>
    </div>
  );
}
