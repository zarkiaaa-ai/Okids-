"use client";

import { EarnScreen } from "@/components/EarnScreen";

export default function TasksPage() {
  return <EarnScreen />;
}
