"use client";

import { TopBar } from "@/components/ui";

const BLOCKS: [string, string][] = [
  ["ما الذي نجمعه؟", "الاسم، البريد، النقاط، وعناوين السحب التي تدخلها بنفسك (USDT / CCP / ID اللاعب). لا نبيع بياناتك أبداً."],
  ["لماذا؟", "لتشغيل حسابك: إضافة النقاط، مراجعة المهام، وتنفيذ السحب والشحن. بدون هذه البيانات لا يمكن الدفع لك."],
  ["الإعلانات والعروض", "عند المشاهدة أو إكمال عرض قد تصل للشبكة بيانات تقنية محدودة (نوع الجهاز، رمز الإتمام) للتحقق ومنع الغش. لا نقاط بدون تأكيد حقيقي."],
  ["الإحالات", "نحتفظ بعلاقة الدعوة لاحتساب عمولة 10% عن النشاط الحقيقي فقط — وليس بمجرد التسجيل."],
  ["من يرى بياناتي؟", "أنت وفريق المراجعة فقط (لتنفيذ السحب). لا نشارك عناوين محافظك مع أي طرف ثالث."],
  ["الحذف", "اطلب حذف حسابك عبر الدعم وسيتم مسح بياناتك. الرصيد غير المسحوب يُفقد بعد الحذف."],
];

export default function PrivacyPage() {
  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-3">
      <TopBar title="الخصوصية 🔒" sub="بياناتك تُستخدم لتدفع لك — لا للبيع ولا للإزعاج" fallback="/profile" />
      {BLOCKS.map(([t, d]) => (
        <div key={t} className="card-dark p-4">
          <div className="font-black text-sm mb-1.5">{t}</div>
          <p className="text-[13px] text-zinc-400 leading-7">{d}</p>
        </div>
      ))}
      <p className="text-center text-[11px] text-zinc-600">privacy@cashtask.app</p>
    </div>
  );
}
