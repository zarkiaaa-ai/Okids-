"use client";

import { useEffect, useState } from "react";
import { Notice, TopBar } from "@/components/ui";

const FAQ = [
  { q: "كيف أربح النقاط؟", a: "من صفحة يكسب: أكمل مهمة وسلّم الدليل، أو شاهد إعلاناً كاملاً. النقاط تُضاف بعد المراجعة أو تأكيد الشبكة." },
  { q: "متى أستطيع السحب؟", a: "عندما تصل إلى 10,000 نقطة. الصرف من المحفظة عبر USDT أو CCP أو جواهر Free Fire، والمراجعة خلال 24-72 ساعة." },
  { q: "كم تساوي النقاط؟", a: "500 نقطة = 1$ تقريباً. و5,000 نقطة = 100 جوهرة Free Fire." },
  { q: "لماذا رُفضت مهمتي؟", a: "غالباً الدليل ناقص أو غير واضح. أعد التنفيذ بدقة وأرفق دليلاً واضحاً ثم سلّم مجدداً." },
  { q: "كيف تعمل الإحالة؟", a: "شارك رابطك. تحصل على 10% عمولة فقط عندما يُكمل أصدقاؤك مهام أو إعلانات حقيقية — وليس بمجرد التسجيل." },
];

export default function SupportPage() {
  const [open, setOpen] = useState<number | null>(0);
  const [email, setEmail] = useState("support@cashtask.app");
  const [tg, setTg] = useState("https://t.me/cashtask_support");
  const [msg, setMsg] = useState("");
  const [sent, setSent] = useState(false);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((j) => {
        if (j.settings?.support_email) setEmail(j.settings.support_email);
        if (j.settings?.support_telegram) setTg(j.settings.support_telegram);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar title="الدعم والمساعدة 💬" fallback="/profile" />

      <div className="card-dark divide-y divide-white/5 overflow-hidden">
        {FAQ.map((f, i) => (
          <button key={i} onClick={() => setOpen(open === i ? null : i)} className="w-full text-right p-4 press">
            <div className="flex justify-between items-center gap-2">
              <span className="font-bold text-sm">{f.q}</span>
              <span className="text-zinc-500">{open === i ? "−" : "+"}</span>
            </div>
            {open === i && <p className="text-xs text-zinc-400 leading-7 mt-2">{f.a}</p>}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <a href={`mailto:${email}`} className="card-dark p-4 text-center press">
          <div className="text-2xl">📧</div>
          <div className="text-xs font-bold mt-1">البريد</div>
          <div className="text-[10px] text-zinc-500 mt-0.5 break-all" dir="ltr">{email}</div>
        </a>
        <a href={tg} target="_blank" rel="noreferrer" className="card-dark p-4 text-center press">
          <div className="text-2xl">✈️</div>
          <div className="text-xs font-bold mt-1">تيليجرام</div>
          <div className="text-[10px] text-zinc-500 mt-0.5">رد سريع عادة</div>
        </a>
      </div>

      <div className="card-dark p-4">
        <div className="font-black text-sm mb-2">أرسل مشكلتك</div>
        <textarea
          className="inp-dark min-h-24"
          placeholder="اشرح المشكلة: رقم الطلب، نوع المهمة..."
          value={msg}
          onChange={(e) => setMsg(e.target.value)}
        />
        <button
          onClick={() => {
            if (!msg.trim()) return;
            window.location.href = `mailto:${email}?subject=${encodeURIComponent("مشكلة في CashTask")}&body=${encodeURIComponent(msg)}`;
            setSent(true);
          }}
          className="mt-2 w-full py-3 rounded-xl bg-white text-black font-black press"
        >
          إرسال عبر البريد
        </button>
        {sent && <div className="mt-2"><Notice tone="ok">تم تجهيز رسالتك في تطبيق البريد ✓</Notice></div>}
      </div>
    </div>
  );
}
