"use client";

import { useEffect, useState } from "react";
import { LANGS, type Lang } from "@/lib/i18n";
import { useI18n } from "@/components/LanguageProvider";
import { Notice, SkeletonList, TopBar } from "@/components/ui";
import { bustOverviewCache } from "@/hooks/useOverview";

const PRESETS = ["🦊", "🐼", "🦁", "🐯", "🐸", "🐧", "🦋", "🌟", "💎", "🚀"];

export default function SettingsPage() {
  const { t, lang, setLang } = useI18n();
  const [loading, setLoading] = useState(true);
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [notifications, setNotifications] = useState(true);
  const [telegram, setTelegram] = useState("");
  const [usdtAddress, setUsdtAddress] = useState("");
  const [ccpRip, setCcpRip] = useState("");
  const [gameFreefireId, setGameFreefireId] = useState("");
  const [gamePubgId, setGamePubgId] = useState("");
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/me")
      .then((r) => r.json())
      .then((j) => {
        if (!j.user) return;
        setDisplayName(j.user.displayName || j.user.username || "");
        setAvatarUrl(j.user.avatarUrl || "");
        setNotifications(j.user.notifications !== false);
        setTelegram(j.user.telegram || "");
        setUsdtAddress(j.user.usdtAddress || "");
        setCcpRip(j.user.ccpRip || "");
        setGameFreefireId(j.user.gameFreefireId || "");
        setGamePubgId(j.user.gamePubgId || "");
        if (j.user.language) setLang(j.user.language as Lang);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [setLang]);

  async function save() {
    setSaving(true);
    setMsg(null);
    try {
      const r = await fetch("/api/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          displayName: displayName.trim(),
          avatarUrl,
          language: lang,
          notifications,
          telegram: telegram.trim(),
          usdtAddress: usdtAddress.trim(),
          ccpRip: ccpRip.trim(),
          gameFreefireId: gameFreefireId.trim(),
          gamePubgId: gamePubgId.trim(),
        }),
      });
      if (r.ok) {
        setMsg({ tone: "ok", text: t.saved });
        bustOverviewCache();
      } else setMsg({ tone: "err", text: "تعذر الحفظ" });
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar title={t.settings} fallback="/profile" />

      {loading ? (
        <SkeletonList rows={4} />
      ) : (
        <>
          <div className="card-dark p-4">
            <div className="font-black text-sm mb-3">{t.photo}</div>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-14 h-14 rounded-full bg-white/10 flex items-center justify-center text-2xl font-black">
                {avatarUrl || (displayName || "?").charAt(0)}
              </div>
              <input
                className="inp-dark"
                placeholder={t.name}
                value={displayName}
                maxLength={30}
                onChange={(e) => setDisplayName(e.target.value)}
              />
            </div>
            <div className="grid grid-cols-5 gap-2">
              {PRESETS.map((p) => (
                <button
                  key={p}
                  onClick={() => setAvatarUrl(avatarUrl === p ? "" : p)}
                  className={`h-11 rounded-xl text-xl border press ${avatarUrl === p ? "border-red-500 bg-red-500/10" : "border-white/10 bg-white/5"}`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="card-dark p-4">
            <div className="font-black text-sm mb-3">{t.language}</div>
            <div className="grid grid-cols-3 gap-2">
              {LANGS.map((l) => (
                <button
                  key={l.id}
                  onClick={() => setLang(l.id)}
                  className={`py-2.5 rounded-xl text-sm font-bold press ${lang === l.id ? "bg-[#c4122f] text-white" : "bg-white/5 text-zinc-400"}`}
                >
                  {l.native}
                </button>
              ))}
            </div>
            <button
              onClick={() => setNotifications((v) => !v)}
              className="mt-3 w-full flex items-center justify-between p-3 rounded-xl bg-white/5 press"
            >
              <span className="text-sm font-bold">🔔 {t.notifications}</span>
              <span className={`w-11 h-6 rounded-full relative ${notifications ? "bg-emerald-500" : "bg-zinc-700"}`}>
                <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${notifications ? "right-0.5" : "left-0.5"}`} />
              </span>
            </button>
          </div>

          <div className="card-dark p-4 space-y-2">
            <div className="font-black text-sm mb-1">{t.payment}</div>
            <input className="inp-dark tabular-nums" dir="ltr" placeholder="USDT (TRC20)" value={usdtAddress} onChange={(e) => setUsdtAddress(e.target.value)} />
            <input className="inp-dark tabular-nums" dir="ltr" placeholder="CCP RIP" value={ccpRip} onChange={(e) => setCcpRip(e.target.value)} />
            <input className="inp-dark tabular-nums" dir="ltr" placeholder="Telegram @username" value={telegram} onChange={(e) => setTelegram(e.target.value)} />
          </div>

          <div className="card-dark p-4 space-y-2">
            <div className="font-black text-sm mb-1">{t.games}</div>
            <input className="inp-dark tabular-nums" dir="ltr" placeholder="Free Fire ID" value={gameFreefireId} onChange={(e) => setGameFreefireId(e.target.value)} />
            <input className="inp-dark tabular-nums" dir="ltr" placeholder="PUBG ID" value={gamePubgId} onChange={(e) => setGamePubgId(e.target.value)} />
          </div>

          {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}

          <button disabled={saving} onClick={save} className="w-full py-3.5 rounded-2xl bg-[#c4122f] font-black press disabled:opacity-50">
            {saving ? "جاري الحفظ..." : t.save}
          </button>

          <button
            onClick={() => {
              localStorage.clear();
              bustOverviewCache();
              window.location.reload();
            }}
            className="w-full py-3 rounded-2xl bg-white/5 text-zinc-400 text-sm font-bold press"
          >
            🧹 مسح ذاكرة التخزين المؤقت
          </button>
        </>
      )}
    </div>
  );
}
