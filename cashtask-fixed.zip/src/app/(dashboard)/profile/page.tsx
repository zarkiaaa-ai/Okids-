"use client";

import Link from "next/link";
import { useState } from "react";
import { pointsToUsd } from "@/lib/constants";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";
import { LevelBar, SectionTitle, StatusPill } from "@/components/ui";

export default function ProfilePage() {
  const ov = useOverview();
  const d = ov.data;
  const [copied, setCopied] = useState(false);
  const [shared, setShared] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const initial = (d.name || "ز").charAt(0);
  const since = d.createdAt
    ? new Date(d.createdAt).toLocaleDateString("ar", { year: "numeric", month: "long" })
    : "";
  const usd = pointsToUsd(d.points);

  const steps = [
    { done: d.hasName, t: "أضف اسمك", href: "/profile/settings" },
    { done: d.hasPayout, t: "أضف عنوان السحب", href: "/profile/settings" },
    { done: d.hasGameId, t: "أضف ID اللعبة", href: "/profile/settings" },
    { done: d.referrals > 0, t: "ادعُ أول صديق", href: "/referrals" },
  ];
  const doneSteps = steps.filter((s) => s.done).length;
  const complete = Math.round((doneSteps / steps.length) * 100);

  function copyCode() {
    if (!d.referralCode) return;
    try {
      navigator.clipboard.writeText(d.referralCode);
    } catch {
      /* ignore */
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  async function shareApp() {
    const url = typeof window !== "undefined" ? window.location.origin : "";
    const text = `اربح معي من CashTask! سجّل هنا: ${url}/register?ref=${d.referralCode}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "CashTask", text, url });
        return;
      } catch {
        return;
      }
    }
    try {
      navigator.clipboard.writeText(text);
    } catch {
      /* ignore */
    }
    setShared(true);
    setTimeout(() => setShared(false), 1500);
  }

  async function refresh() {
    setRefreshing(true);
    bustOverviewCache();
    await ov.refresh(true);
    setRefreshing(false);
  }

  const stats: [string, string][] = [
    [`${d.points.toLocaleString()} 🪙`, "النقاط"],
    [`$${usd.toFixed(2)}`, "القيمة التقريبية"],
    [String(d.approvedCount), "مهام مقبولة"],
    [String(d.todayAds), "إعلانات اليوم"],
    [`${d.referrals} (${d.activeReferrals} نشط)`, "الأصدقاء"],
    [`${d.streak} 🔥`, "سلسلة الأيام"],
  ];

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-4 pb-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-black">ملفي الشخصي</h1>
        <button
          onClick={refresh}
          className="text-[11px] text-zinc-300 bg-white/10 rounded-full px-3 py-1.5 press"
        >
          {refreshing ? "..." : "↻ تحديث"}
        </button>
      </div>

      {/* بطاقة الحساب */}
      <div className="rounded-3xl bg-gradient-to-br from-[#7a2228] to-[#161616] p-5">
        <div className="flex items-center gap-3">
          <div className="w-16 h-16 rounded-full bg-[#c4122f] flex items-center justify-center text-2xl font-black shrink-0 overflow-hidden">
            {d.avatarUrl && d.avatarUrl.length <= 4 ? d.avatarUrl : initial}
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-black text-xl truncate">{d.name}</div>
            <div className="text-xs text-zinc-300 mt-0.5 truncate" dir="ltr">
              {d.email || "guest@cashtask.app"}
            </div>
            <div className="text-[11px] text-zinc-400 mt-0.5">
              {since ? `عضو منذ ${since}` : "عضو CashTask"}
            </div>
          </div>
          <Link
            href="/profile/settings"
            className="shrink-0 text-[11px] font-bold bg-white/15 rounded-full px-3 py-1.5 press"
          >
            تعديل ✏️
          </Link>
        </div>
        <div className="mt-4">
          <LevelBar points={d.points} />
        </div>
        {d.referralCode && (
          <button
            onClick={copyCode}
            className="mt-3 w-full rounded-2xl bg-black/30 border border-white/10 p-3 flex items-center justify-between press"
          >
            <span className="text-[11px] text-zinc-300">كود الدعوة الخاص بك</span>
            <span className="font-black tracking-[0.2em] tabular-nums" dir="ltr">
              {copied ? "تم النسخ ✓" : d.referralCode}
            </span>
          </button>
        )}
      </div>

      {/* إكمال الحساب */}
      {complete < 100 && (
        <div className="card-dark p-4">
          <div className="flex justify-between items-center mb-2">
            <div className="font-black text-sm">أكمل حسابك ({doneSteps}/4)</div>
            <div className="text-[11px] text-zinc-400 tabular-nums">{complete}%</div>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden mb-3">
            <div
              className="h-full rounded-full bg-gradient-to-l from-emerald-400 to-teal-500"
              style={{ width: `${complete}%` }}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            {steps.map((s) => (
              <Link
                key={s.t}
                href={s.href}
                className="rounded-xl bg-white/5 p-2.5 text-[12px] font-bold flex items-center gap-2 press"
              >
                <span>{s.done ? "✅" : "⭕"}</span>
                <span className={s.done ? "text-zinc-500 line-through" : ""}>{s.t}</span>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* إحصائيات */}
      <div className="grid grid-cols-3 gap-2">
        {stats.map(([v, l]) => (
          <div key={l} className="card-dark p-3 text-center">
            <div className="font-black text-[15px] tabular-nums">{v}</div>
            <div className="text-[10px] text-zinc-400 mt-1">{l}</div>
          </div>
        ))}
      </div>

      {/* المحفظة والربح */}
      <div>
        <SectionTitle>المحفظة والربح</SectionTitle>
        <div className="card-dark divide-y divide-white/5 overflow-hidden">
          <Item
            href="/withdraw"
            icon="💳"
            t="المحفظة"
            s={`السحب · ${d.payoutsPending ? `${d.payoutsPending} قيد التنفيذ` : "لا طلبات معلقة"}`}
            badge={d.payoutsPending > 0 ? String(d.payoutsPending) : undefined}
          />
          <Item
            href="/rewards"
            icon="🎁"
            t="المكافآت"
            s={d.canClaim ? "مكافأتك اليومية جاهزة" : `سلسلة ${d.streak} أيام 🔥`}
            dot={d.canClaim}
          />
          <Item
            href="/contests"
            icon="🏆"
            t="المسابقات"
            s={d.contestsActive ? `${d.contestsActive} نشطة` : "لا مسابقات نشطة"}
          />
          <Item href="/leaderboard" icon="📊" t="لوحة الصدارة" s="ترتيبك بين الأوائل" />
          <Item href="/topup" icon="💎" t="شحن الجواهر" s="5,000 نقطة = 100 جوهرة" />
        </div>
      </div>

      {/* النشاط الأخير */}
      <div>
        <SectionTitle
          action={
            <Link href="/withdraw" className="text-[11px] text-zinc-400 font-bold">
              الكل ←
            </Link>
          }
        >
          آخر عمليات السحب
        </SectionTitle>
        {d.recentWithdrawals.length === 0 ? (
          <div className="card-dark p-5 text-center text-[13px] text-zinc-400">
            لا عمليات بعد — اطلب أول سحب من المحفظة عند بلوغ 10,000 نقطة
          </div>
        ) : (
          <div className="card-dark divide-y divide-white/5 overflow-hidden">
            {d.recentWithdrawals.map((w, i) => (
              <div key={i} className="flex items-center justify-between p-3.5 gap-2">
                <div className="min-w-0">
                  <div className="font-bold text-sm tabular-nums">
                    {(w.amount.match(/([\d,]+) نقطة/) || [])[1]
                      ? `${(w.amount.match(/([\d,]+) نقطة/) as RegExpMatchArray)[1]} نقطة`
                      : `$${w.amount}`}
                  </div>
                  <div className="text-[11px] text-zinc-500 mt-0.5">
                    {w.createdAt ? new Date(w.createdAt).toLocaleDateString("ar") : ""}
                  </div>
                </div>
                <StatusPill status={w.status} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* الدعوة */}
      <div>
        <SectionTitle>الدعوة</SectionTitle>
        <div className="card-dark divide-y divide-white/5 overflow-hidden">
          <Item
            href="/referrals"
            icon="👥"
            t="دعوة الأصدقاء"
            s={`${d.referrals} صديق · ${d.activeReferrals} نشط · عمولة 10%`}
          />
          <button onClick={shareApp} className="w-full flex items-center gap-3 p-3.5 press text-right">
            <span className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-lg shrink-0">
              📤
            </span>
            <span className="flex-1 min-w-0">
              <span className="block font-bold text-sm">{shared ? "تم نسخ رابط الدعوة ✓" : "مشاركة التطبيق"}</span>
              <span className="block text-[11px] text-zinc-400 truncate mt-0.5">أرسل رابطك لأصدقائك</span>
            </span>
            <span className="text-zinc-600">‹</span>
          </button>
        </div>
      </div>

      {/* الحساب */}
      <div>
        <SectionTitle>الحساب</SectionTitle>
        <div className="card-dark divide-y divide-white/5 overflow-hidden">
          <Item href="/profile/settings" icon="⚙️" t="الإعدادات" s="الاسم · الصورة · اللغة · الدفع · الألعاب · الإشعارات" />
          <Item href="/profile/privacy" icon="🔒" t="الخصوصية" s="بياناتك وحمايتها" />
          <Item href="/profile/support" icon="💬" t="الدعم" s="أسئلة وأجوبة · تواصل" />
        </div>
      </div>

      <Link href="/admin" className="card-dark p-4 flex items-center gap-3 press">
        <span className="text-2xl">🛡️</span>
        <span className="flex-1">
          <span className="block font-black text-sm">لوحة التحكم</span>
          <span className="block text-[11px] text-zinc-400">إدارة المهام والإعلانات والناس</span>
        </span>
        <span className="text-zinc-500">‹</span>
      </Link>

      <button
        onClick={async () => {
          try {
            await fetch("/api/auth", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ action: "logout" }),
            });
          } catch {
            /* ignore */
          }
          try {
            localStorage.removeItem("ct_session");
          } catch {
            /* ignore */
          }
          bustOverviewCache();
          window.location.href = "/login";
        }}
        className="w-full py-3 rounded-2xl bg-red-500/10 border border-red-500/20 text-red-300 text-[13px] font-bold press"
      >
        تسجيل الخروج
      </button>

      <button
        onClick={() => {
          bustOverviewCache();
          window.location.reload();
        }}
        className="w-full py-3 rounded-2xl bg-white/5 text-zinc-400 text-[13px] font-bold press"
      >
        🧹 تحديث البيانات
      </button>

      <p className="text-center text-[11px] text-zinc-600">CashTask v2 · الأرباح من شبكات الإعلانات والعروض</p>
    </div>
  );
}

function Item({
  href,
  icon,
  t,
  s,
  badge,
  dot,
}: {
  href: string;
  icon: string;
  t: string;
  s: string;
  badge?: string;
  dot?: boolean;
}) {
  return (
    <Link href={href} className="flex items-center gap-3 p-3.5 press">
      <span className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-lg shrink-0">
        {icon}
      </span>
      <span className="flex-1 min-w-0">
        <span className="font-bold text-sm flex items-center gap-2">
          {t}
          {dot && <span className="w-2 h-2 rounded-full bg-amber-400" />}
        </span>
        <span className="block text-[11px] text-zinc-400 truncate mt-0.5">{s}</span>
      </span>
      {badge && (
        <span className="min-w-6 h-6 px-1.5 rounded-full bg-[#c4122f] text-white text-[11px] font-black flex items-center justify-center tabular-nums">
          {badge}
        </span>
      )}
      <span className="text-zinc-600">‹</span>
    </Link>
  );
}
