"use client";

import { useEffect, useState } from "react";
import { Notice, SkeletonList, StatusPill, TopBar } from "@/components/ui";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";

type Contest = {
  id: number;
  title: string;
  description: string | null;
  prize: string;
  prizeValue: string | null;
  entryCost: number;
  currentEntries: number;
  maxEntries: number | null;
  endsAt: string;
  winnerUserId: number | null;
};
type MyEntry = { contestId: number; pointsSpent: number; enteredAt: string };

function left(ms: number) {
  if (ms <= 0) return "انتهت";
  const d = Math.floor(ms / 86400000);
  const h = Math.floor((ms % 86400000) / 3600000);
  if (d > 0) return `${d} يوم ${h} س`;
  const m = Math.floor((ms % 3600000) / 60000);
  if (h > 0) return `${h} س ${m} د`;
  return `${m} د`;
}

export default function ContestsPage() {
  const ov = useOverview();
  const [items, setItems] = useState<Contest[]>([]);
  const [mine, setMine] = useState<MyEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState<number | null>(null);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);

  async function load() {
    setLoading(true);
    try {
      const r = await fetch("/api/contests?mine=1");
      const j = await r.json();
      setItems(j.contests || []);
      setMine(j.myEntries || []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function enter(id: number, cost: number) {
    if (ov.data.points < cost) {
      setMsg({ tone: "err", text: "نقاطك غير كافية — أكمل مهاماً أولاً" });
      return;
    }
    setJoining(id);
    setMsg(null);
    try {
      const r = await fetch("/api/contests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "enter", contestId: id }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الاشتراك" });
      else {
        setMsg({ tone: "ok", text: "تم اشتراكك بالتوفيق 🎉" });
        bustOverviewCache();
        ov.refresh(true);
        load();
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setJoining(null);
    }
  }

  const enteredIds = new Set(mine.map((m) => m.contestId));

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar
        title="المسابقات 🏆"
        fallback="/rewards"
        action={
          <div className="text-xs bg-white/10 rounded-full px-3 py-1.5 tabular-nums whitespace-nowrap">
            <b>{ov.data.points.toLocaleString()}</b> 🪙
          </div>
        }
      />

      {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}

      {loading ? (
        <SkeletonList rows={3} />
      ) : items.length === 0 ? (
        <div className="card-dark p-10 text-center">
          <div className="text-4xl mb-2">🏆</div>
          <div className="font-black text-sm">لا مسابقات نشطة</div>
          <p className="text-xs text-zinc-400 mt-2">تابعنا — مسابقات وجوائز جديدة قريباً</p>
        </div>
      ) : (
        items.map((c) => {
          const ms = new Date(c.endsAt).getTime() - Date.now();
          const joined = enteredIds.has(c.id);
          const pct = c.maxEntries ? Math.min(100, (c.currentEntries / c.maxEntries) * 100) : null;
          return (
            <div key={c.id} className="card-dark p-4">
              <div className="flex justify-between gap-2">
                <div className="font-black">{c.title}</div>
                {c.winnerUserId ? <StatusPill status="completed" /> : <StatusPill status="pending" />}
              </div>
              {c.description && <p className="text-xs text-zinc-400 mt-1 leading-6">{c.description}</p>}
              <div className="mt-3 rounded-2xl bg-amber-400/10 border border-amber-400/25 p-3 flex items-center gap-3">
                <span className="text-3xl">🎁</span>
                <div>
                  <div className="font-black text-sm">{c.prize}</div>
                  {c.prizeValue && <div className="text-[11px] text-zinc-400 tabular-nums">بقيمة ${c.prizeValue}</div>}
                </div>
              </div>
              <div className="flex justify-between text-[11px] text-zinc-400 mt-3 tabular-nums">
                <span>⏳ {left(ms)}</span>
                <span>👥 {c.currentEntries}{c.maxEntries ? ` / ${c.maxEntries}` : ""}</span>
                <span>🎟️ {c.entryCost} نقطة</span>
              </div>
              {pct !== null && (
                <div className="h-1.5 rounded-full bg-white/10 overflow-hidden mt-2">
                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                </div>
              )}
              {c.winnerUserId ? (
                <div className="mt-3 text-center text-sm font-bold text-amber-300">🎉 فاز المتسابق #{c.winnerUserId}</div>
              ) : joined ? (
                <div className="mt-3 text-center text-sm font-bold text-emerald-300 bg-emerald-500/10 rounded-xl py-2.5">مشترك ✓ بالتوفيق</div>
              ) : ms <= 0 ? (
                <div className="mt-3 text-center text-sm text-zinc-500">انتهت المسابقة</div>
              ) : (
                <button
                  disabled={joining === c.id}
                  onClick={() => enter(c.id, c.entryCost)}
                  className="mt-3 w-full py-3 rounded-xl bg-amber-400 text-black font-black press disabled:opacity-50"
                >
                  {joining === c.id ? "جاري..." : `اشترك بـ ${c.entryCost} نقطة`}
                </button>
              )}
            </div>
          );
        })
      )}
    </div>
  );
}
