"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";
import { Notice, SkeletonList, TopBar } from "@/components/ui";

type Contest = { id: number; title: string; prize: string; entryCost: number; currentEntries: number; endsAt: string };

export default function RewardsPage() {
  const ov = useOverview();
  const [canClaim, setCanClaim] = useState(true);
  const [streak, setStreak] = useState(0);
  const [reward, setReward] = useState(20);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [claiming, setClaiming] = useState(false);
  const [contests, setContests] = useState<Contest[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      const [r, c] = await Promise.allSettled([
        fetch("/api/rewards").then((x) => x.json()),
        fetch("/api/contests?mine=1").then((x) => x.json()),
      ]);
      if (r.status === "fulfilled" && r.value.dailyBonus) {
        setCanClaim(!!r.value.dailyBonus.canClaim);
        setStreak(r.value.dailyBonus.streak || 0);
        setReward(r.value.dailyBonus.todayReward || 20);
      }
      if (c.status === "fulfilled") setContests((c.value.contests || []).slice(0, 2));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function claim() {
    setClaiming(true);
    setMsg(null);
    try {
      const r = await fetch("/api/rewards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "claim-daily" }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الاستلام" });
      else {
        setCanClaim(false);
        setStreak(j.streak || streak + 1);
        setMsg({ tone: "ok", text: `تمت إضافة ${j.reward} نقطة 🎉` });
        bustOverviewCache();
        ov.refresh(true);
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setClaiming(false);
    }
  }

  const days = [1, 2, 3, 4, 5, 6, 7];
  const missions = [
    { done: ov.data.approvedCount + ov.data.pendingCount > 0, icon: "📋", t: "سلّم مهمة", href: "/?tab=tasks" },
    { done: ov.data.todayAds >= 3, icon: "📺", t: `شاهد 3 إعلانات (${ov.data.todayAds}/3)`, href: "/?tab=ads" },
    { done: ov.data.referrals > 0, icon: "👥", t: "ادعُ صديقاً", href: "/referrals" },
  ];

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar title="المكافآت" fallback="/" />

      <div className="rounded-3xl bg-gradient-to-br from-[#7a4a10] via-[#4a2f0c] to-[#141414] p-5">
        <div className="text-sm text-amber-200/80">المكافأة اليومية</div>
        <div className="text-4xl font-black mt-1 tabular-nums">+{reward} 🪙</div>
        <div className="grid grid-cols-7 gap-1.5 mt-4">
          {days.map((d) => {
            const done = d <= Math.min(streak, 7);
            const today = d === Math.min(streak + 1, 7) && canClaim;
            return (
              <div
                key={d}
                className={`aspect-square rounded-xl flex items-center justify-center text-xs font-black ${
                  done ? "bg-amber-400 text-black" : today ? "border border-amber-400/60 text-amber-300" : "bg-white/10 text-zinc-500"
                }`}
              >
                {done ? "✓" : d}
              </div>
            );
          })}
        </div>
        <button
          onClick={claim}
          disabled={!canClaim || claiming}
          className="mt-4 w-full py-3.5 rounded-2xl bg-amber-400 text-black font-black press disabled:opacity-50"
        >
          {!canClaim ? "تم الاستلام — عد غداً" : claiming ? "جاري..." : `استلم ${reward} نقطة`}
        </button>
      </div>

      {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}

      <div>
        <div className="font-black text-[15px] mb-2">مهام اليوم</div>
        <div className="space-y-2">
          {missions.map((m) => (
            <Link key={m.t} href={m.href} className="card-dark p-3.5 flex items-center gap-3 press">
              <span className="text-xl">{m.icon}</span>
              <span className="flex-1 text-sm font-bold">{m.t}</span>
              <span className={`text-xs px-2 py-1 rounded-full font-bold ${m.done ? "bg-emerald-500/15 text-emerald-300" : "bg-white/10 text-zinc-400"}`}>
                {m.done ? "تم ✓" : "ابدأ"}
              </span>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-2">
          <div className="font-black text-[15px]">مسابقات قريبة</div>
          <Link href="/contests" className="text-xs text-amber-300 font-bold">الكل</Link>
        </div>
        {loading ? (
          <SkeletonList rows={2} />
        ) : contests.length === 0 ? (
          <div className="card-dark p-6 text-center text-sm text-zinc-400">لا مسابقات نشطة حالياً</div>
        ) : (
          <div className="space-y-2">
            {contests.map((c) => (
              <Link key={c.id} href="/contests" className="card-dark p-4 flex items-center justify-between gap-2 press">
                <div>
                  <div className="font-black text-sm">🏆 {c.title}</div>
                  <div className="text-[11px] text-zinc-400 mt-1">الجائزة: {c.prize} · الدخول {c.entryCost} نقطة</div>
                </div>
                <span className="text-amber-300 text-lg">‹</span>
              </Link>
            ))}
          </div>
        )}
      </div>

      <Link href="/referrals" className="card-dark p-4 flex items-center gap-3 press">
        <span className="text-2xl">👥</span>
        <span className="flex-1">
          <span className="block font-black text-sm">ادعُ أصدقاءك واربح 10%</span>
          <span className="block text-[11px] text-zinc-400 mt-0.5">عمولة عن كل نشاط حقيقي لهم</span>
        </span>
        <span className="text-zinc-500">‹</span>
      </Link>
    </div>
  );
}
