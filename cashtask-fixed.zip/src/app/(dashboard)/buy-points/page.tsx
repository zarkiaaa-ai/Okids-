"use client";

import { useEffect, useState } from "react";
import { pointsToUsd } from "@/lib/constants";
import { Notice, SkeletonList, StatusPill, TopBar } from "@/components/ui";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";

type Pkg = { points: number; usd: number };
type Purchase = { id: number; points: number; priceUsd: string; method: string; txId: string | null; status: string; createdAt: string };

export default function BuyPointsPage() {
  const ov = useOverview();
  const [pkgs, setPkgs] = useState<Pkg[]>([]);
  const [rows, setRows] = useState<Purchase[]>([]);
  const [idx, setIdx] = useState(0);
  const [method, setMethod] = useState<"usdt" | "ccp">("usdt");
  const [txId, setTxId] = useState("");
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [sending, setSending] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const r = await fetch("/api/points");
      const j = await r.json();
      setPkgs(j.packages || []);
      setRows(j.purchases || []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function submit() {
    setMsg(null);
    if (!txId.trim()) {
      setMsg({ tone: "err", text: "أدخل رقم عملية التحويل (TXID)" });
      return;
    }
    setSending(true);
    try {
      const r = await fetch("/api/points", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "request", packageIndex: idx, method, txId }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الطلب" });
      else {
        setMsg({ tone: "ok", text: "تم إرسال طلبك — تُضاف النقاط بعد تأكيد التحويل" });
        setTxId("");
        bustOverviewCache();
        ov.refresh(true);
        load();
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setSending(false);
    }
  }

  const pkg = pkgs[idx];

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar
        title="شراء النقاط 💎"
        fallback="/withdraw"
        action={
          <div className="text-xs bg-white/10 rounded-full px-3 py-1.5 tabular-nums whitespace-nowrap">
            <b>{ov.data.points.toLocaleString()}</b> 🪙
          </div>
        }
      />

      <div className="rounded-2xl bg-amber-400/10 border border-amber-400/25 p-3 text-[12px] leading-6 text-amber-200">
        الطريقة الأسرع مجاناً: أكمل المهام من صفحة <b>يكسب</b>. الشراء اختياري لمن يريد نقاطاً فورية.
      </div>

      {loading ? (
        <SkeletonList rows={3} />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-2">
            {pkgs.map((p, i) => (
              <button
                key={i}
                onClick={() => setIdx(i)}
                className={`p-3.5 rounded-2xl border text-right press ${idx === i ? "border-amber-400 bg-amber-400/10" : "border-white/10 bg-[#141416]"}`}
              >
                <div className="font-black tabular-nums">🪙 {p.points.toLocaleString()}</div>
                <div className="text-xs text-zinc-400 mt-1 tabular-nums">${p.usd} · ≈ {pointsToUsd(p.points).toFixed(2)}$ قيمة</div>
              </button>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => setMethod("usdt")} className={`py-2.5 rounded-xl font-bold press ${method === "usdt" ? "bg-[#3d8f6e] text-white" : "bg-white/5 text-zinc-400"}`}>USDT</button>
            <button onClick={() => setMethod("ccp")} className={`py-2.5 rounded-xl font-bold press ${method === "ccp" ? "bg-[#3d8f6e] text-white" : "bg-white/5 text-zinc-400"}`}>CCP</button>
          </div>

          <input className="inp-dark tabular-nums" dir="ltr" placeholder="رقم عملية التحويل TXID" value={txId} onChange={(e) => setTxId(e.target.value)} />

          {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}

          <button disabled={sending || !pkg} onClick={submit} className="w-full py-3.5 rounded-2xl bg-amber-400 text-black font-black press disabled:opacity-50">
            {sending ? "جاري..." : pkg ? `تأكيد شراء ${pkg.points.toLocaleString()} نقطة` : "اختر باقة"}
          </button>

          {rows.length > 0 && (
            <div className="space-y-2">
              <div className="font-black text-[15px]">طلبات الشراء</div>
              {rows.slice(0, 6).map((p) => (
                <div key={p.id} className="card-dark p-3.5 flex items-center justify-between gap-2">
                  <div>
                    <div className="font-bold text-sm tabular-nums">🪙 {p.points.toLocaleString()} · ${p.priceUsd}</div>
                    <div className="text-[11px] text-zinc-500 mt-0.5">{p.method.toUpperCase()} · {new Date(p.createdAt).toLocaleDateString("ar")}</div>
                  </div>
                  <StatusPill status={p.status} />
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
