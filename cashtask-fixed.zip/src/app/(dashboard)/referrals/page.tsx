"use client";

import { useEffect, useMemo, useState } from "react";
import { REFERRAL_PERCENT } from "@/lib/constants";
import { SkeletonList } from "@/components/ui";

type Referral = { username: string; balance: string; createdAt: string };

const TIERS = [
  { n: 1, t: "البداية 🌱" },
  { n: 5, t: "نشط 🔥" },
  { n: 20, t: "سفير 👑" },
];

export default function InvitePage() {
  const [code, setCode] = useState("GUEST01");
  const [copied, setCopied] = useState(false);
  const [referrals, setReferrals] = useState<Referral[]>([]);
  const [showEarnings, setShowEarnings] = useState(false);
  const [showTerms, setShowTerms] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/referrals")
      .then((r) => r.json())
      .then((j) => {
        if (j.referralCode) setCode(j.referralCode);
        setReferrals(j.referrals || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const link = `${typeof window !== "undefined" ? window.location.origin : ""}/register?ref=${code}`;
  const active = useMemo(() => referrals.filter((r) => parseFloat(r.balance || "0") > 0), [referrals]);
  const tier = [...TIERS].reverse().find((t) => referrals.length >= t.n)?.t || "جديد ✨";
  const nextTier = TIERS.find((t) => referrals.length < t.n);

  function copyText(text: string) {
    try {
      navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  }

  async function invite() {
    const text = `اربح معي من المهام! سجّل هنا: ${link}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: "دعوة صديق", text, url: link });
        return;
      } catch {
        return;
      }
    }
    copyText(text);
  }

  const wa = `https://wa.me/?text=${encodeURIComponent(`اربح معي من المهام! سجّل هنا: ${link}`)}`;
  const tg = `https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent("اربح معي من المهام!")}`;

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white pb-6">
      <div className="relative overflow-hidden bg-gradient-to-b from-[#7a5c10] via-[#4a3a0c] to-black px-5 pt-6 pb-10">
        <Coin x="6%" y="16%" s={72} o={0.9} />
        <Coin x="78%" y="6%" s={110} o={0.95} />
        <Coin x="70%" y="60%" s={90} o={0.9} />
        <Coin x="4%" y="64%" s={64} o={0.85} />

        <h1 className="relative text-center text-[26px] font-black leading-10">قم بدعوة صديق و اكسب</h1>

        <div className="relative mt-4 rounded-3xl bg-black/55 border border-white/10 p-5">
          <p className="text-right text-[15px] leading-8">
            لكل مهمة يُكملها المدعوون. لا يوجد حد أقصى.
            <br />
            اكسب {REFERRAL_PERCENT}% 🎖️
          </p>
          <button
            onClick={() => setShowEarnings((v) => !v)}
            className="mt-4 w-full py-3.5 rounded-full border border-white/30 text-lg font-bold press"
          >
            🗂️ رؤى الأرباح
          </button>
          {showEarnings && (
            <div className="mt-4 rounded-2xl bg-white/5 border border-white/10 p-4 text-sm">
              {loading ? (
                <SkeletonList rows={2} />
              ) : (
                <>
                  <div className="grid grid-cols-3 gap-2 text-center mb-3">
                    <div className="rounded-xl bg-black/40 p-2">
                      <div className="font-black text-lg tabular-nums">{referrals.length}</div>
                      <div className="text-[10px] text-zinc-400">صديق</div>
                    </div>
                    <div className="rounded-xl bg-black/40 p-2">
                      <div className="font-black text-lg tabular-nums">{active.length}</div>
                      <div className="text-[10px] text-zinc-400">نشط</div>
                    </div>
                    <div className="rounded-xl bg-black/40 p-2">
                      <div className="font-black text-lg">{REFERRAL_PERCENT}%</div>
                      <div className="text-[10px] text-zinc-400">عمولة</div>
                    </div>
                  </div>
                  {referrals.length === 0 ? (
                    <p className="text-zinc-400">لم يدعُ أحد بعد — شارك رابطك وستظهر أرباحك هنا.</p>
                  ) : (
                    <div className="space-y-2 max-h-44 overflow-auto">
                      {referrals.map((r, i) => (
                        <div key={i} className="flex justify-between items-center bg-black/40 rounded-xl px-3 py-2">
                          <span className="font-bold text-sm">{r.username}</span>
                          <span className={`text-[11px] px-2 py-0.5 rounded-full ${parseFloat(r.balance || "0") > 0 ? "bg-emerald-500/15 text-emerald-300" : "bg-white/10 text-zinc-400"}`}>
                            {parseFloat(r.balance || "0") > 0 ? "نشط ✅" : "جديد"}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="-mt-6">
        <img src="/illustrations/invite-people.png" alt="أشخاص ونقود" loading="lazy" decoding="async" className="w-full h-56 object-cover object-top" />
      </div>

      <div className="px-4 -mt-8 space-y-3">
        <div className="rounded-3xl bg-[#16181d]/95 border border-white/5 p-4">
          <button onClick={() => copyText(link)} className="w-full rounded-2xl bg-[#26262b] px-4 py-4 press">
            <span className="block text-3xl font-black tracking-[0.2em]" dir="ltr">{code}</span>
            <span className="block text-xs text-zinc-400 mt-1">رمز الإحالة الخاص بك — اضغط للنسخ</span>
          </button>
          {copied && <p className="text-center text-emerald-400 text-sm mt-2">تم النسخ ✓</p>}

          <button onClick={invite} className="mt-3 w-full py-4 rounded-2xl bg-[#3d8f6e] text-white text-xl font-black press">
            🤍 دعوة صديق
          </button>
          <div className="grid grid-cols-2 gap-2 mt-2">
            <a href={wa} target="_blank" rel="noreferrer" className="py-3 rounded-2xl bg-[#25D366]/15 border border-[#25D366]/30 text-center font-bold text-sm press">
              واتساب
            </a>
            <a href={tg} target="_blank" rel="noreferrer" className="py-3 rounded-2xl bg-sky-500/15 border border-sky-500/30 text-center font-bold text-sm press">
              تيليجرام
            </a>
          </div>
          <button onClick={() => setShowTerms((v) => !v)} className="w-full text-center text-[#3d8f6e] mt-4 mb-1 font-bold">
            قراءة الشروط
          </button>
          {showTerms && (
            <div className="text-xs text-zinc-400 leading-6 bg-black/40 rounded-2xl p-3">
              • العمولة ({REFERRAL_PERCENT}%) تُدفع فقط عندما يُكمل الصديق مهمة أو إعلاناً حقيقياً — وليس بمجرد التسجيل.
              <br />• لا يوجد حد أقصى لعدد الأصدقاء.
              <br />• الحسابات الوهمية تلغي الأرباح.
            </div>
          )}
        </div>

        <div className="card-dark p-4">
          <div className="flex justify-between items-center mb-2">
            <div className="font-black text-sm">مستواك: {tier}</div>
            <div className="text-[11px] text-zinc-400 tabular-nums">{referrals.length} صديق</div>
          </div>
          <div className="h-2 rounded-full bg-white/10 overflow-hidden">
            <div
              className="h-full rounded-full bg-gradient-to-l from-amber-400 to-orange-500"
              style={{ width: `${Math.min(100, (referrals.length / (nextTier?.n || 20)) * 100)}%` }}
            />
          </div>
          {nextTier && (
            <div className="text-[11px] text-zinc-400 mt-1.5">
              ادعُ {nextTier.n - referrals.length} بعد → {nextTier.t}
            </div>
          )}
        </div>

        <div className="grid grid-cols-3 gap-2 text-center">
          {[["1️⃣", "انسخ رابطك"], ["2️⃣", "شاركه"], ["3️⃣", "اربح 10%"]].map(([e, t]) => (
            <div key={t} className="card-dark p-3">
              <div className="text-xl">{e}</div>
              <div className="text-[11px] font-bold mt-1">{t}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Coin({ x, y, s, o }: { x: string; y: string; s: number; o: number }) {
  return (
    <div
      className="absolute rounded-full flex items-center justify-center font-black text-[#7a5c10]"
      style={{
        left: x,
        top: y,
        width: s,
        height: s,
        opacity: o,
        background: "radial-gradient(circle at 30% 30%, #ffe9a3, #f5b81e 60%, #c78d0a)",
        boxShadow: "0 8px 24px rgba(0,0,0,.4)",
        fontSize: s * 0.5,
      }}
    >
      $
    </div>
  );
}
