"use client";

import { useEffect, useState } from "react";
import { usdToPoints } from "@/lib/constants";
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";
import { Notice, SkeletonList, TopBar } from "@/components/ui";

type Ad = {
  id: number;
  title: string;
  targetUrl: string | null;
  reward: string;
  requiredSeconds: number;
  ready?: boolean;
  secondsLeft?: number;
};

function fmt(s?: number) {
  if (!s || s <= 0) return "";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h}س ${m}د` : m > 0 ? `${m}د` : `${s}ث`;
}

export default function AdsPage() {
  const ov = useOverview();
  const [ads, setAds] = useState<Ad[]>([]);
  const [loading, setLoading] = useState(true);
  const [watching, setWatching] = useState<number | null>(null);
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(8);
  const [msg, setMsg] = useState<{ tone: "ok" | "err"; text: string } | null>(null);
  const [todayViews, setTodayViews] = useState(0);
  const [todayPts, setTodayPts] = useState(0);

  async function load(silent = false) {
    if (!silent) setLoading(true);
    try {
      const r = await fetch("/api/ads");
      const j = await r.json();
      setAds(j.ads || []);
      setTodayViews(j.todayViews || 0);
      setTodayPts(usdToPoints(j.todayEarnings || 0));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (watching === null || count <= 0) return;
    const t = setTimeout(() => setCount((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [watching, count]);

  useEffect(() => {
    if (watching !== null && count === 0) finish(watching);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [count]);

  function start(ad: Ad) {
    if (ad.ready === false || watching !== null) return;
    if (ad.targetUrl) window.open(ad.targetUrl, "_blank", "noopener,noreferrer");
    setMsg(null);
    setWatching(ad.id);
    setTotal(ad.requiredSeconds || 8);
    setCount(ad.requiredSeconds || 8);
  }

  async function finish(id: number) {
    try {
      const r = await fetch("/api/ads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adId: id }),
      });
      const j = await r.json().catch(() => ({}));
      setWatching(null);
      if (r.ok) {
        setMsg({ tone: "ok", text: `تمت إضافة ${usdToPoints(j.earned).toLocaleString()} نقطة 🎉` });
        bustOverviewCache();
        ov.refresh(true);
        load(true);
      } else setMsg({ tone: "err", text: j.error || "لم تكتمل المشاهدة" });
    } catch {
      setWatching(null);
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    }
  }

  const readyCount = ads.filter((a) => a.ready !== false).length;

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white px-4 pt-0 pb-6 space-y-4">
      <TopBar title="الإعلانات 📺" sub="شاهد الإعلان كاملاً لتحصل على النقاط" fallback="/" />

      <div className="grid grid-cols-3 gap-2 text-center">
        {[
          [String(readyCount), "متاح الآن"],
          [String(todayViews), "شاهدت اليوم"],
          [`${todayPts.toLocaleString()}`, "نقاط اليوم"],
        ].map(([v, l]) => (
          <div key={l} className="card-dark p-3">
            <div className="font-black text-lg tabular-nums">{v}</div>
            <div className="text-[10px] text-zinc-400 mt-0.5">{l}</div>
          </div>
        ))}
      </div>

      {msg && <Notice tone={msg.tone === "ok" ? "ok" : "err"}>{msg.text}</Notice>}

      {loading ? (
        <SkeletonList rows={3} />
      ) : ads.length === 0 ? (
        <div className="card-dark p-10 text-center">
          <div className="text-4xl mb-2">📺</div>
          <div className="font-black text-sm">لا إعلانات متاحة الآن</div>
          <p className="text-xs text-zinc-400 mt-2">تظهر إعلانات جديدة دورياً — فعّل التحديث لاحقاً</p>
        </div>
      ) : (
        ads.map((ad) => {
          const pts = usdToPoints(ad.reward);
          const w = watching === ad.id;
          return (
            <div key={ad.id} className="card-dark p-4">
              <div className="flex justify-between gap-2">
                <div>
                  <div className="text-[10px] text-zinc-500">إعلان مكافأة · {ad.requiredSeconds} ثانية</div>
                  <div className="font-black text-sm mt-0.5">{ad.title}</div>
                </div>
                <div className="text-emerald-400 font-black tabular-nums whitespace-nowrap">+{pts.toLocaleString()} 🪙</div>
              </div>
              {w ? (
                <div>
                  <div className="h-2 rounded-full bg-white/10 overflow-hidden mt-3">
                    <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${((total - count) / total) * 100}%` }} />
                  </div>
                  <div className="text-center text-xs text-zinc-300 mt-2 tabular-nums">مشاهدة جارية… {count}ث — لا تغلق الصفحة</div>
                </div>
              ) : ad.ready === false ? (
                <div className="mt-3 text-center text-xs text-zinc-500 bg-white/5 rounded-xl py-2.5">
                  يعود بعد {fmt(ad.secondsLeft)}
                </div>
              ) : (
                <button onClick={() => start(ad)} className="w-full mt-3 py-2.5 rounded-xl bg-[#c4122f] font-black text-sm press">
                  ▶ شاهد واربح {pts.toLocaleString()} نقطة
                </button>
              )}
            </div>
          );
        })
      )}

      <div className="card-dark p-4 text-[12px] text-zinc-400 leading-7">
        <b className="text-zinc-200">كيف تُحتسب النقاط؟</b>
        <br />• تُضاف النقاط فقط بعد مشاهدة كاملة وتأكيد الشبكة
        <br />• إغلاق الإعلان مبكراً = لا نقاط
        <br />• كل إعلان يعود بعد فترة انتظار
      </div>
    </div>
  );
}
