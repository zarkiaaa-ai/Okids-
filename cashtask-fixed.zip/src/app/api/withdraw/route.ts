import { NextResponse } from "next/server";
import { eq, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, withdrawals, gameTopups } from "@/db/schema";
import { getSessionUser, requireAdmin, requireUser } from "@/lib/auth";
import { MIN_WITHDRAW_POINTS, pointsToUsd, FREEFIRE_POINTS_PACKAGES } from "@/lib/constants";

export const runtime = "nodejs";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    const rows = await db
      .select()
      .from(withdrawals)
      .where(eq(withdrawals.userId, user.id))
      .orderBy(desc(withdrawals.createdAt));
    const topups = await db.select().from(gameTopups).where(eq(gameTopups.userId, user.id)).orderBy(desc(gameTopups.createdAt));
    return NextResponse.json({ withdrawals: rows, topups });
  } catch (e) {
    console.error("[withdraw GET]", e);
    return NextResponse.json({ withdrawals: [], topups: [] });
  }
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "request";

  try {
    if (action === "request") {
      const u = requireUser(user);
      const method = String(body.method) as "usdt" | "ccp" | "freefire";

      // ---- سحب جواهر فري فاير بالنقاط ----
      if (method === "freefire") {
        const pkgId = String(body.packageId || "");
        const pkg = FREEFIRE_POINTS_PACKAGES.find((p) => p.id === pkgId);
        if (!pkg) return NextResponse.json({ error: "اختر باقة جواهر" }, { status: 400 });
        const playerId = String(body.playerId || body.address || "").trim();
        if (!playerId) return NextResponse.json({ error: "أدخل ID لاعب Free Fire" }, { status: 400 });
        if (u.points < pkg.points)
          return NextResponse.json({ error: `تحتاج ${pkg.points.toLocaleString()} نقطة` }, { status: 402 });
        const usdEq = pointsToUsd(pkg.points);
        await db.transaction(async (tx) => {
          await tx.update(users).set({ points: sql`points - ${pkg.points}` }).where(eq(users.id, u.id));
          await tx.execute(sql`update users set balance = GREATEST(0, (balance::numeric - ${usdEq}::numeric))::text where id = ${u.id}`);
          await tx.insert(gameTopups).values({
            userId: u.id,
            game: "freefire",
            playerId,
            packageLabel: `${pkg.label} (${pkg.points.toLocaleString()} نقطة)`,
            priceUsd: String(usdEq),
            status: "pending",
          });
        });
        return NextResponse.json({ ok: true, points: pkg.points });
      }

      // ---- سحب USDT / CCP بالنقاط ----
      if (!["usdt", "ccp"].includes(method))
        return NextResponse.json({ error: "طريقة غير مدعومة" }, { status: 400 });
      const points = Math.floor(Number(body.points || body.amount || 0));
      const address = String(body.address || "").trim();
      if (!points || isNaN(points) || points < MIN_WITHDRAW_POINTS)
        return NextResponse.json(
          { error: `الحد الأدنى للسحب ${MIN_WITHDRAW_POINTS.toLocaleString()} نقطة` },
          { status: 400 }
        );
      if (!address)
        return NextResponse.json(
          { error: method === "usdt" ? "أدخل عنوان USDT" : "أدخل رقم حساب CCP" },
          { status: 400 }
        );
      if (u.points < points)
        return NextResponse.json({ error: "نقاطك غير كافية" }, { status: 402 });

      const usdEq = pointsToUsd(points);
      await db.transaction(async (tx) => {
        await tx.update(users).set({ points: sql`points - ${points}` }).where(eq(users.id, u.id));
        await tx.execute(sql`update users set balance = GREATEST(0, (balance::numeric - ${usdEq}::numeric))::text where id = ${u.id}`);
        await tx.insert(withdrawals).values({
          userId: u.id,
          method,
          amount: String(usdEq),
          address: `${address} | ${points.toLocaleString()} نقطة`,
          status: "pending",
        });
      });
      return NextResponse.json({ ok: true, points, usd: usdEq });
    }

    if (action === "process") {
      requireAdmin(user);
      const id = Number(body.id);
      const status = body.status as "completed" | "rejected";
      const [w] = await db.select().from(withdrawals).where(eq(withdrawals.id, id)).limit(1);
      if (!w) return NextResponse.json({ error: "غير موجود" }, { status: 404 });
      if (w.status !== "pending")
        return NextResponse.json({ error: "تمت معالجتها" }, { status: 409 });
      if (status === "rejected") {
        // إرجاع النقاط من العنوان
        const m = w.address.match(/([\d,]+) نقطة/);
        const pts = m ? parseInt(m[1].replace(/,/g, "")) : 0;
        if (pts > 0) {
          await db.update(users).set({ points: sql`points + ${pts}` }).where(eq(users.id, w.userId));
        }
        await db.execute(
          sql`update users set balance = (balance::numeric + ${parseFloat(w.amount)}::numeric)::text where id = ${w.userId}`
        );
      }
      await db
        .update(withdrawals)
        .set({ status, processedAt: new Date(), adminNote: body.adminNote || null })
        .where(eq(withdrawals.id, id));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "غير مدعوم" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "UNAUTHORIZED") return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    if (msg === "FORBIDDEN") return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    console.error(e);
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}
