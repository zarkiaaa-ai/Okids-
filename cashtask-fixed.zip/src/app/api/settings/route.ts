import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { siteSettings } from "@/db/schema";
import { getSessionUser, requireAdmin } from "@/lib/auth";

export const runtime = "nodejs";

const DEFAULTS: Record<string, string> = {
  site_name: "CashTask",
  usdt_address: "",
  ccp_rip: "",
  support_email: "support@cashtask.app",
  support_telegram: "https://t.me/cashtask_support",
  min_withdraw: "2",
  referral_percent: "10",
  referral_bonus: "0.1",
  announcement_title: "",
  announcement_text: "",
};

export async function GET() {
  try {
    const rows = await db.select().from(siteSettings);
    const map: Record<string, string> = { ...DEFAULTS };
    for (const r of rows) map[r.key] = r.value;
    return NextResponse.json({ settings: map });
  } catch {
    return NextResponse.json({ settings: DEFAULTS });
  }
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  try {
    requireAdmin(user);
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }
  const body = await req.json().catch(() => ({}));
  const entries = Object.entries(body as Record<string, string>).filter(([k]) => k in DEFAULTS);
  for (const [key, raw] of entries) {
    const value = String(raw ?? "");
    const existing = await db.select().from(siteSettings).where(eq(siteSettings.key, key)).limit(1);
    if (existing.length) {
      await db.update(siteSettings).set({ value, updatedAt: new Date() }).where(eq(siteSettings.key, key));
    } else {
      await db.insert(siteSettings).values({ key, value, updatedAt: new Date() });
    }
  }
  return NextResponse.json({ ok: true });
}
