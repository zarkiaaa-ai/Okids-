import { NextResponse } from "next/server";
import { eq, or, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  applySessionCookie,
  createSession,
  destroySession,
  generateReferralCode,
  generateSalt,
  hashPassword,
  safeCompare,
  SESSION_COOKIE,
} from "@/lib/auth";
import { REFERRAL_BONUS_USD } from "@/lib/constants";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status });
}

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "";

  try {
    if (action === "register") {
      const username = String(body.username || "").trim();
      const email = String(body.email || "").trim().toLowerCase();
      const password = String(body.password || "");
      const referralCode = String(body.referralCode || "").trim();

      if (!username || !email || !password) {
        return jsonError("أدخل اسم المستخدم والبريد وكلمة المرور", 400);
      }
      if (username.length < 3) {
        return jsonError("اسم المستخدم قصير جداً", 400);
      }
      if (!email.includes("@")) {
        return jsonError("البريد الإلكتروني غير صحيح", 400);
      }
      if (password.length < 6) {
        return jsonError("كلمة المرور يجب أن تكون 6 أحرف على الأقل", 400);
      }

      const existing = await db
        .select({ id: users.id })
        .from(users)
        .where(or(eq(users.email, email), eq(users.username, username)))
        .limit(1);
      if (existing.length) {
        return jsonError("البريد أو اسم المستخدم مستخدم بالفعل", 409);
      }

      let referredBy: number | undefined;
      if (referralCode) {
        const ref = await db
          .select({ id: users.id })
          .from(users)
          .where(eq(users.referralCode, referralCode.toUpperCase()))
          .limit(1);
        if (ref[0]) referredBy = ref[0].id;
      }

      const salt = generateSalt();
      const hash = await hashPassword(password, salt);

      let insertedId: number | null = null;
      for (let i = 0; i < 4 && insertedId === null; i++) {
        try {
          const inserted = await db
            .insert(users)
            .values({
              username,
              email,
              passwordHash: hash,
              passwordSalt: salt,
              referralCode: generateReferralCode(),
              referredBy,
              balance: "0",
              points: 0,
            })
            .returning({ id: users.id });
          insertedId = inserted[0].id;
        } catch (err) {
          if (i === 3) throw err;
        }
      }
      if (!insertedId) return jsonError("تعذر إنشاء الحساب، حاول مرة أخرى", 500);

      if (referredBy) {
        await db.execute(
          sql`update users set balance = (balance::numeric + ${REFERRAL_BONUS_USD}::numeric)::text where id = ${referredBy}`
        );
      }

      const { token, expiresAt } = await createSession(insertedId);
      const res = NextResponse.json({ ok: true, token, isAdmin: false });
      applySessionCookie(res, token, expiresAt);
      return res;
    }

    if (action === "login") {
      const identifier = String(body.email || body.username || "").trim();
      const password = String(body.password || "");
      if (!identifier || !password) {
        return jsonError("أدخل البريد وكلمة المرور", 400);
      }

      const email = identifier.toLowerCase();
      const row = await db
        .select()
        .from(users)
        .where(or(eq(users.email, email), eq(users.username, identifier)))
        .limit(1);
      if (!row[0]) {
        return jsonError("البريد أو كلمة المرور غير صحيحة", 401);
      }
      const hash = await hashPassword(password, row[0].passwordSalt);
      if (!safeCompare(hash, row[0].passwordHash)) {
        return jsonError("البريد أو كلمة المرور غير صحيحة", 401);
      }

      const { token, expiresAt } = await createSession(row[0].id);
      const res = NextResponse.json({
        ok: true,
        token,
        isAdmin: row[0].isAdmin,
      });
      applySessionCookie(res, token, expiresAt);
      return res;
    }

    if (action === "logout") {
      await destroySession();
      const res = NextResponse.json({ ok: true });
      res.cookies.set(SESSION_COOKIE, "", { path: "/", maxAge: 0 });
      return res;
    }

    return jsonError("عملية غير مدعومة", 400);
  } catch (e) {
    console.error("[auth]", e);
    return jsonError("خطأ في الخادم، حاول مرة أخرى", 500);
  }
}
