import { NextResponse } from "next/server";
import { eq, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser, requireUser } from "@/lib/auth";

export const runtime = "nodejs";

function startOfToday() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export async function GET() {
  let user;
  try {
    user = await getSessionUser();
  } catch (e) {
    console.error("[rewards user]", e);
    return NextResponse.json({ error: "تعذر الاتصال" }, { status: 503 });
  }
  if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });

  let referrals: { username: string; balance: string; createdAt: Date }[] = [];
  try {
    referrals = await db
      .select({
        username: users.username,
        balance: users.balance,
        createdAt: users.createdAt,
      })
      .from(users)
      .where(eq(users.referredBy, user.id))
      .orderBy(desc(users.createdAt));
  } catch (e) {
    console.error("[rewards refs]", e);
  }

  const last = user.lastDailyAt ? new Date(user.lastDailyAt) : null;
  const claimedToday = !!(last && last.getTime() >= startOfToday().getTime());
  const streak = user.dailyStreak || 0;
  const nextStreak = claimedToday ? streak : streak + 1;
  const todayReward = 10 + Math.min(claimedToday ? streak : nextStreak, 7) * 5;

  return NextResponse.json({
    user: {
      points: user.points,
      balance: user.balance,
      referralCode: user.referralCode,
    },
    referrals,
    dailyBonus: {
      canClaim: !claimedToday,
      lastClaim: last,
      streak,
      todayReward,
    },
  });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  const body = await req.json().catch(() => ({}));
  const action = body.action as string;

  try {
    if (action === "claim-daily") {
      const u = requireUser(user);
      const last = u.lastDailyAt ? new Date(u.lastDailyAt) : null;
      if (last && last.getTime() >= startOfToday().getTime()) {
        return NextResponse.json({ error: "لقد استلمت مكافأتك اليوم بالفعل" }, { status: 409 });
      }

      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      yesterday.setHours(0, 0, 0, 0);
      const keepStreak = !!(last && last.getTime() >= yesterday.getTime());
      const streak = keepStreak ? (u.dailyStreak || 0) + 1 : 1;
      const reward = 10 + Math.min(streak, 7) * 5;

      await db
        .update(users)
        .set({
          points: sql`points + ${reward}`,
          lastDailyAt: new Date(),
          dailyStreak: streak,
        })
        .where(eq(users.id, u.id));

      return NextResponse.json({ ok: true, reward, streak });
    }

    return NextResponse.json({ error: "عملية غير مدعومة" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "UNAUTHORIZED") return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    console.error(e);
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}
