import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { gameTopups, users } from "@/db/schema";
import { getSessionUser, requireAdmin, requireUser } from "@/lib/auth";
import { FREEFIRE_POINTS_PACKAGES, pointsToUsd } from "@/lib/constants";
import { sql } from "drizzle-orm";

export const runtime = "nodejs";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    const rows = await db
      .select()
      .from(gameTopups)
      .where(eq(gameTopups.userId, user.id))
      .orderBy(desc(gameTopups.createdAt));
    return NextResponse.json({ topups: rows, packages: FREEFIRE_POINTS_PACKAGES });
  } catch (e) {
    console.error("[topup GET]", e);
    return NextResponse.json({ topups: [], packages: FREEFIRE_POINTS_PACKAGES });
  }
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "request";

  try {
    if (action === "request") {
      const u = requireUser(user);
      const pkgId = String(body.packageId || "");
      const pkg = FREEFIRE_POINTS_PACKAGES.find((p) => p.id === pkgId);
      if (!pkg) return NextResponse.json({ error: "اختر باقة جواهر" }, { status: 400 });
      const playerId = String(body.playerId || "").trim();
      if (!playerId) return NextResponse.json({ error: "أدخل ID اللاعب" }, { status: 400 });
      if (u.points < pkg.points)
        return NextResponse.json({ error: `تحتاج ${pkg.points.toLocaleString()} نقطة` }, { status: 402 });
      const usdEq = pointsToUsd(pkg.points);
      await db.transaction(async (tx) => {
        await tx.update(users).set({ points: sql`points - ${pkg.points}` }).where(eq(users.id, u.id));
        await tx.execute(sql`update users set balance = GREATEST(0, (balance::numeric - ${usdEq}::numeric))::text where id = ${u.id}`);
        await tx.insert(gameTopups).values({
          userId: u.id,
          game: "freefire",
          playerId,
          packageLabel: `${pkg.label} (${pkg.points.toLocaleString()} نقطة)`,
          priceUsd: String(usdEq),
          status: "pending",
        });
      });
      return NextResponse.json({ ok: true });
    }

    if (action === "process") {
      requireAdmin(user);
      const id = Number(body.id);
      const status = body.status as "completed" | "rejected";
      const [t] = await db.select().from(gameTopups).where(eq(gameTopups.id, id)).limit(1);
      if (!t) return NextResponse.json({ error: "غير موجود" }, { status: 404 });
      if (t.status !== "pending") return NextResponse.json({ error: "تمت معالجتها" }, { status: 409 });
      if (status === "rejected") {
        const m = t.packageLabel.match(/([\d,]+) نقطة/);
        const pts = m ? parseInt(m[1].replace(/,/g, "")) : 0;
        if (pts > 0) await db.update(users).set({ points: sql`points + ${pts}` }).where(eq(users.id, t.userId));
        await db.execute(
          sql`update users set balance = (balance::numeric + ${parseFloat(t.priceUsd)}::numeric)::text where id = ${t.userId}`
        );
      }
      await db.update(gameTopups).set({ status, processedAt: new Date() }).where(eq(gameTopups.id, id));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "غير مدعوم" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "UNAUTHORIZED") return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    if (msg === "FORBIDDEN") return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    console.error(e);
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}
