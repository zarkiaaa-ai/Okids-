import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/db";
import {
  users,
  taskCompletions,
  withdrawals,
  pointPurchases,
  gameTopups,
  contests,
} from "@/db/schema";
import { getSessionUser, requireAdmin } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const user = await getSessionUser();
  try {
    requireAdmin(user);
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }
  const url = new URL(req.url);
  const kind = url.searchParams.get("kind") || "pendingTasks";

  if (kind === "users") {
    const rows = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        balance: users.balance,
        points: users.points,
        referralCode: users.referralCode,
        isAdmin: users.isAdmin,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(200);
    return NextResponse.json({ items: rows });
  }
  if (kind === "pendingTasks") {
    const rows = await db.query.taskCompletions.findMany({
      where: (tc, { eq }) => eq(tc.status, "pending"),
      with: {
        user: { columns: { id: true, username: true, email: true } } as never,
      },
      orderBy: (tc, { desc: d }) => d(tc.createdAt),
      limit: 200,
    });
    // enrich with task
    const taskIds = Array.from(new Set(rows.map((r) => r.taskId)));
    const taskRows = taskIds.length
      ? await db.query.tasks.findMany({ where: (t, { inArray }) => inArray(t.id, taskIds) })
      : [];
    const taskMap = new Map(taskRows.map((t) => [t.id, t]));
    const items = rows.map((r) => ({ ...r, task: taskMap.get(r.taskId) ?? null }));
    return NextResponse.json({ items });
  }
  if (kind === "pendingWithdraw") {
    const rows = await db.query.withdrawals.findMany({
      where: (w, { eq }) => eq(w.status, "pending"),
      orderBy: (w, { desc: d }) => d(w.createdAt),
      limit: 200,
    });
    const userIds = Array.from(new Set(rows.map((r) => r.userId)));
    const uRows = userIds.length
      ? await db.query.users.findMany({
          where: (u, { inArray }) => inArray(u.id, userIds),
          columns: { id: true, username: true, email: true },
        })
      : [];
    const uMap = new Map(uRows.map((u) => [u.id, u]));
    return NextResponse.json({
      items: rows.map((r) => ({ ...r, user: uMap.get(r.userId) ?? null })),
    });
  }
  if (kind === "pendingPoints") {
    const rows = await db.query.pointPurchases.findMany({
      where: (p, { eq }) => eq(p.status, "pending"),
      orderBy: (p, { desc: d }) => d(p.createdAt),
      limit: 200,
    });
    const userIds = Array.from(new Set(rows.map((r) => r.userId)));
    const uRows = userIds.length
      ? await db.query.users.findMany({
          where: (u, { inArray }) => inArray(u.id, userIds),
          columns: { id: true, username: true, email: true },
        })
      : [];
    const uMap = new Map(uRows.map((u) => [u.id, u]));
    return NextResponse.json({
      items: rows.map((r) => ({ ...r, user: uMap.get(r.userId) ?? null })),
    });
  }
  if (kind === "pendingTopup") {
    const rows = await db.query.gameTopups.findMany({
      where: (t, { eq }) => eq(t.status, "pending"),
      orderBy: (t, { desc: d }) => d(t.createdAt),
      limit: 200,
    });
    const userIds = Array.from(new Set(rows.map((r) => r.userId)));
    const uRows = userIds.length
      ? await db.query.users.findMany({
          where: (u, { inArray }) => inArray(u.id, userIds),
          columns: { id: true, username: true, email: true },
        })
      : [];
    const uMap = new Map(uRows.map((u) => [u.id, u]));
    return NextResponse.json({
      items: rows.map((r) => ({ ...r, user: uMap.get(r.userId) ?? null })),
    });
  }
  if (kind === "contests") {
    const rows = await db.select().from(contests).orderBy(desc(contests.createdAt));
    return NextResponse.json({ items: rows });
  }
  return NextResponse.json({ error: "غير مدعوم" }, { status: 400 });
}
