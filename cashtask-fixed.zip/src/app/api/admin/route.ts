import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  users,
  tasks,
  taskCompletions,
  withdrawals,
  contests,
  pointPurchases,
  gameTopups,
  ads,
} from "@/db/schema";
import { getSessionUser, requireAdmin } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET() {
  const user = await getSessionUser();
  try {
    requireAdmin(user);
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }

  const [usersCount] = await db.select({ c: sql<number>`count(*)::int` }).from(users);
  const [tasksCount] = await db.select({ c: sql<number>`count(*)::int` }).from(tasks);
  const [adsCount] = await db.select({ c: sql<number>`count(*)::int` }).from(ads);
  const [pendingTasks] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(taskCompletions)
    .where(sql`${taskCompletions.status} = 'pending'`);
  const [pendingWithdraw] = await db
    .select({
      c: sql<number>`count(*)::int`,
      total: sql<string>`coalesce(sum(${withdrawals.amount}::numeric),0)::text`,
    })
    .from(withdrawals)
    .where(sql`${withdrawals.status} = 'pending'`);
  const [pendingPoints] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(pointPurchases)
    .where(sql`${pointPurchases.status} = 'pending'`);
  const [pendingTopup] = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(gameTopups)
    .where(sql`${gameTopups.status} = 'pending'`);
  const [contestsCount] = await db.select({ c: sql<number>`count(*)::int` }).from(contests);
  const [wallet] = await db.select({
    points: sql<number>`coalesce(sum(points),0)::int`,
    balance: sql<string>`coalesce(sum(balance::numeric),0)::text`,
  }).from(users);

  return NextResponse.json({
    stats: {
      users: usersCount.c,
      tasks: tasksCount.c,
      ads: adsCount.c,
      pendingTasks: pendingTasks.c,
      pendingWithdraw: pendingWithdraw.c,
      pendingWithdrawUsd: pendingWithdraw.total,
      pendingPoints: pendingPoints.c,
      pendingTopup: pendingTopup.c,
      contests: contestsCount.c,
      totalPoints: wallet.points,
      totalBalance: wallet.balance,
    },
  });
}

export async function POST(req: Request) {
  const session = await getSessionUser();
  try {
    requireAdmin(session);
  } catch {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }
  const body = await req.json().catch(() => ({}));
  if (body.action === "adjust-user") {
    const id = Number(body.userId);
    const patch: { points?: number; balance?: string } = {};
    if (body.points !== undefined && body.points !== "") patch.points = Math.max(0, Number(body.points));
    if (body.balance !== undefined && body.balance !== "") patch.balance = String(body.balance);
    if (!Object.keys(patch).length) return NextResponse.json({ error: "لا يوجد تعديل" }, { status: 400 });
    const [row] = await db.update(users).set(patch).where(eq(users.id, id)).returning({
      id: users.id,
      username: users.username,
      points: users.points,
      balance: users.balance,
    });
    return NextResponse.json({ ok: true, user: row });
  }
  return NextResponse.json({ error: "غير مدعوم" }, { status: 400 });
}
