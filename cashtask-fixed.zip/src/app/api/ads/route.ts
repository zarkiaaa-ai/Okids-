import { NextResponse } from "next/server";
import { eq, and, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { ads, adViews } from "@/db/schema";
import { getSessionUser, requireAdmin } from "@/lib/auth";
import { usdToPoints } from "@/lib/constants";

export const runtime = "nodejs";

export async function GET(req: Request) {
  try {
  const user = await getSessionUser();
  const all = new URL(req.url).searchParams.get("all") === "1";
  const rows = all
    ? await db.select().from(ads)
    : await db.select().from(ads).where(eq(ads.active, true));
  if (!user) return NextResponse.json({ ads: rows });

  // حساب آخر مشاهدة لكل إعلان
  const views = await db
    .select({ adId: adViews.adId, last: sql<string>`max(${adViews.viewedAt})` })
    .from(adViews)
    .where(eq(adViews.userId, user.id))
    .groupBy(adViews.adId);
  const viewMap = new Map(views.map((v) => [v.adId, new Date(v.last)]));

  const withCooldown = rows.map((ad) => {
    const last = viewMap.get(ad.id);
    let ready = true;
    let secondsLeft = 0;
    if (last) {
      const diffMs = Date.now() - last.getTime();
      const cooldownMs = ad.cooldownHours * 60 * 60 * 1000;
      if (diffMs < cooldownMs) {
        ready = false;
        secondsLeft = Math.ceil((cooldownMs - diffMs) / 1000);
      }
    }
    return { ...ad, ready, secondsLeft };
  });

  const [today] = await db
    .select({
      c: sql<number>`count(*)::int`,
      total: sql<string>`coalesce(sum(${adViews.earned}::numeric),0)::text`,
    })
    .from(adViews)
    .where(sql`${adViews.userId} = ${user.id} AND ${adViews.viewedAt} >= current_date`);

  return NextResponse.json({
    ads: withCooldown,
    todayViews: today?.c || 0,
    todayEarnings: today?.total || "0",
  });
  } catch (e) {
    console.error(e);
    return NextResponse.json({ ads: [], todayViews: 0, todayEarnings: "0" });
  }
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "watch";

  try {
    if (action === "create") {
      requireAdmin(user);
      const [row] = await db
        .insert(ads)
        .values({
          title: String(body.title || "إعلان"),
          targetUrl: body.targetUrl || null,
          imageUrl: body.imageUrl || null,
          reward: String(body.reward || "0.005"),
          requiredSeconds: Number(body.requiredSeconds) || 15,
          cooldownHours: Number(body.cooldownHours) || 24,
          active: body.active !== false,
        })
        .returning();
      return NextResponse.json({ ok: true, ad: row });
    }
    if (action === "update") {
      requireAdmin(user);
      const [row] = await db
        .update(ads)
        .set({
          title: String(body.title),
          targetUrl: body.targetUrl || null,
          imageUrl: body.imageUrl || null,
          reward: String(body.reward),
          requiredSeconds: Number(body.requiredSeconds) || 15,
          cooldownHours: Number(body.cooldownHours) || 24,
          active: !!body.active,
        })
        .where(eq(ads.id, Number(body.id)))
        .returning();
      return NextResponse.json({ ok: true, ad: row });
    }
    if (action === "delete") {
      requireAdmin(user);
      await db.delete(ads).where(eq(ads.id, Number(body.id)));
      return NextResponse.json({ ok: true });
    }
  } catch (e) {
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "FORBIDDEN") return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    console.error(e);
    return NextResponse.json({ error: "خطأ" }, { status: 500 });
  }

  const adId = Number(body.adId);
  if (!adId) return NextResponse.json({ error: "إعلان غير صالح" }, { status: 400 });

  const [ad] = await db.select().from(ads).where(eq(ads.id, adId)).limit(1);
  if (!ad || !ad.active) return NextResponse.json({ error: "غير متاح" }, { status: 404 });

  // cooldown تحقق
  const [last] = await db
    .select({ viewedAt: adViews.viewedAt })
    .from(adViews)
    .where(and(eq(adViews.userId, user.id), eq(adViews.adId, adId)))
    .orderBy(desc(adViews.viewedAt))
    .limit(1);
  if (last) {
    const diffMs = Date.now() - new Date(last.viewedAt).getTime();
    if (diffMs < ad.cooldownHours * 60 * 60 * 1000) {
      return NextResponse.json({ error: "يجب الانتظار قبل المشاهدة مرة أخرى" }, { status: 429 });
    }
  }

  const reward = parseFloat(ad.reward);
  const pts = usdToPoints(reward);
  await db.transaction(async (tx) => {
    await tx.insert(adViews).values({ adId, userId: user.id, earned: ad.reward });
    await tx.execute(
      sql`update users set balance = (balance::numeric + ${reward}::numeric)::text, points = points + ${pts} where id = ${user.id}`
    );
    if (user.referredBy) {
      await tx.execute(
        sql`update users set balance = (balance::numeric + (${reward}::numeric * 0.10))::text where id = ${user.referredBy}`
      );
    }
  });

  return NextResponse.json({ ok: true, earned: reward, points: pts });
}
