import { NextResponse } from "next/server";
import { eq, desc } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser, requireUser } from "@/lib/auth";
import { REFERRAL_BONUS_USD, REFERRAL_PERCENT } from "@/lib/constants";

export const runtime = "nodejs";

export async function GET() {
  let user;
  try {
    user = await getSessionUser();
  } catch (e) {
    console.error("[referrals user]", e);
    return NextResponse.json({ error: "تعذر الاتصال" }, { status: 503 });
  }
  if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });

  try {
    const referrals = await db
      .select({
        id: users.id,
        username: users.username,
        createdAt: users.createdAt,
        balance: users.balance,
      })
      .from(users)
      .where(eq(users.referredBy, user.id))
      .orderBy(desc(users.createdAt));

    const base = `${process.env.NEXT_PUBLIC_BASE_URL || ""}`;
    const referralLink = `${base}/register?ref=${user.referralCode}`;

    return NextResponse.json({
      referralCode: user.referralCode,
      referralLink,
      referralBonus: REFERRAL_BONUS_USD,
      referralPercent: REFERRAL_PERCENT,
      referrals,
    });
  } catch (e) {
    console.error("[referrals GET]", e);
    return NextResponse.json({
      referralCode: user.referralCode,
      referralLink: `/register?ref=${user.referralCode}`,
      referralBonus: REFERRAL_BONUS_USD,
      referralPercent: REFERRAL_PERCENT,
      referrals: [],
    });
  }
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
  const body = await req.json().catch(() => ({} as Record<string, unknown>));

  // ربط حساب الضيف بكود دعوة صديق (لا يمسح أي بيانات)
  if ((body as { action?: string }).action === "apply") {
    try {
      const u = requireUser(user);
      const code = String(
        (body as { code?: unknown; referralCode?: unknown }).code ??
          (body as { referralCode?: unknown }).referralCode ??
          ""
      )
        .trim()
        .toUpperCase();
      if (!code) return NextResponse.json({ error: "أدخل كود الدعوة" }, { status: 400 });
      if (u.referredBy)
        return NextResponse.json({ ok: true, already: true, message: "تم ربط حسابك بدعوة سابقاً" });
      if (code === u.referralCode)
        return NextResponse.json({ error: "لا يمكنك استخدام كودك الخاص" }, { status: 400 });
      const ref = await db
        .select({ id: users.id, username: users.username })
        .from(users)
        .where(eq(users.referralCode, code))
        .limit(1);
      if (!ref[0])
        return NextResponse.json({ error: "كود الدعوة غير صحيح" }, { status: 404 });
      await db.update(users).set({ referredBy: ref[0].id }).where(eq(users.id, u.id));
      return NextResponse.json({ ok: true, inviter: ref[0].username });
    } catch (e) {
      console.error("[referrals apply]", e);
      return NextResponse.json({ error: "تعذر ربط الدعوة" }, { status: 500 });
    }
  }

  // حفظ معلومات الملف الشخصي (فقط الحقول المرسلة — لا تمسح الباقي)
  try {
    const u = requireUser(user);
    const patch: Partial<typeof users.$inferInsert> = {};
    const b = body as Record<string, unknown>;
    if (typeof b.telegram === "string") patch.telegram = b.telegram.trim() || null;
    if (typeof b.usdtAddress === "string") patch.usdtAddress = b.usdtAddress.trim() || null;
    if (typeof b.ccpRip === "string") patch.ccpRip = b.ccpRip.trim() || null;
    if (typeof b.gameFreefireId === "string") patch.gameFreefireId = b.gameFreefireId.trim() || null;
    if (typeof b.gamePubgId === "string") patch.gamePubgId = b.gamePubgId.trim() || null;
    if (Object.keys(patch).length === 0) return NextResponse.json({ ok: true });
    await db.update(users).set(patch).where(eq(users.id, u.id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    console.error("[referrals save]", e);
    return NextResponse.json({ error: "تعذر الحفظ" }, { status: 500 });
  }
}
