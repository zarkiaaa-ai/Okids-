import { NextResponse } from "next/server";
import { eq, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { pointPurchases, users } from "@/db/schema";
import { getSessionUser, requireAdmin, requireUser } from "@/lib/auth";
import { POINT_PACKAGES, POINT_PRICE_USD, DZD_PER_USD } from "@/lib/constants";

export const runtime = "nodejs";

export async function GET() {
  try {
    const user = await getSessionUser();
    if (!user) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    const rows = await db
      .select()
      .from(pointPurchases)
      .where(eq(pointPurchases.userId, user.id))
      .orderBy(desc(pointPurchases.createdAt));
    return NextResponse.json({ purchases: rows, packages: POINT_PACKAGES });
  } catch (e) {
    console.error("[points GET]", e);
    return NextResponse.json({ purchases: [], packages: POINT_PACKAGES });
  }
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "request";

  try {
    if (action === "request") {
      const u = requireUser(user);
      const pkgIdx = Number(body.packageIndex);
      const method = body.method as "usdt" | "ccp";
      if (!["usdt", "ccp"].includes(method))
        return NextResponse.json({ error: "طريقة دفع غير صالحة" }, { status: 400 });
      const pkg = POINT_PACKAGES[pkgIdx];
      if (!pkg) return NextResponse.json({ error: "باقة غير صالحة" }, { status: 400 });
      const priceUsd = pkg.usd;
      const priceDzd = priceUsd * DZD_PER_USD;
      const txId = String(body.txId || "").trim();
      if (!txId)
        return NextResponse.json(
          { error: "أدخل رقم العملية/مرجع التحويل" },
          { status: 400 }
        );
      await db.insert(pointPurchases).values({
        userId: u.id,
        points: pkg.points,
        priceUsd: String(priceUsd),
        priceDzd: String(priceDzd),
        method,
        txId,
        status: "pending",
      });
      return NextResponse.json({ ok: true, priceUsd, priceDzd });
    }

    if (action === "process") {
      const u = requireAdmin(user);
      const id = Number(body.id);
      const status = body.status as "completed" | "rejected";
      const [p] = await db.select().from(pointPurchases).where(eq(pointPurchases.id, id)).limit(1);
      if (!p) return NextResponse.json({ error: "غير موجود" }, { status: 404 });
      if (p.status !== "pending")
        return NextResponse.json({ error: "تمت معالجتها" }, { status: 409 });

      if (status === "completed") {
        await db
          .update(users)
          .set({ points: sql`points + ${p.points}` })
          .where(eq(users.id, p.userId));
      }
      await db
        .update(pointPurchases)
        .set({ status, processedAt: new Date(), adminNote: body.adminNote || null })
        .where(eq(pointPurchases.id, id));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "غير مدعوم" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "UNAUTHORIZED") return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    if (msg === "FORBIDDEN") return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    console.error(e);
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}
