import { NextResponse } from "next/server";
import { eq, desc, sql, asc } from "drizzle-orm";
import { db } from "@/db";
import { contests, contestEntries, users } from "@/db/schema";
import { getSessionUser, requireAdmin, requireUser } from "@/lib/auth";

export const runtime = "nodejs";

export async function GET(req: Request) {
  let user;
  try {
    user = await getSessionUser();
  } catch (e) {
    console.error("[contests user]", e);
    return NextResponse.json({ contests: [], myEntries: [] });
  }
  const url = new URL(req.url);
  const mine = url.searchParams.get("mine");

  let rows: (typeof contests.$inferSelect)[] = [];
  try {
    rows = await db
      .select()
      .from(contests)
      .where(eq(contests.active, true))
      .orderBy(desc(contests.createdAt));
  } catch (e) {
    console.error("[contests list]", e);
    return NextResponse.json({ contests: [], myEntries: [] });
  }

  if (mine === "1" && user) {
    const my = await db
      .select({
        id: contestEntries.id,
        contestId: contestEntries.contestId,
        pointsSpent: contestEntries.pointsSpent,
        enteredAt: contestEntries.enteredAt,
        title: contests.title,
        prize: contests.prize,
        winnerUserId: contests.winnerUserId,
      })
      .from(contestEntries)
      .innerJoin(contests, eq(contests.id, contestEntries.contestId))
      .where(eq(contestEntries.userId, user.id))
      .orderBy(desc(contestEntries.enteredAt));
    return NextResponse.json({ contests: rows, myEntries: my });
  }
  return NextResponse.json({ contests: rows });
}

export async function POST(req: Request) {
  const user = await getSessionUser();
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "enter";

  try {
    if (action === "enter") {
      const u = requireUser(user);
      const contestId = Number(body.contestId);
      const [contest] = await db
        .select()
        .from(contests)
        .where(eq(contests.id, contestId))
        .limit(1);
      if (!contest || !contest.active)
        return NextResponse.json({ error: "مسابقة غير متاحة" }, { status: 404 });
      if (new Date(contest.endsAt).getTime() < Date.now()) {
        return NextResponse.json({ error: "انتهت المسابقة" }, { status: 410 });
      }
      if (u.points < contest.entryCost) {
        return NextResponse.json({ error: "نقاط غير كافية، اشترِ نقاطاً" }, { status: 402 });
      }
      await db.transaction(async (tx) => {
        await tx
          .update(users)
          .set({ points: sql`points - ${contest.entryCost}` })
          .where(eq(users.id, u.id));
        await tx.insert(contestEntries).values({
          contestId,
          userId: u.id,
          pointsSpent: contest.entryCost,
        });
        await tx
          .update(contests)
          .set({ currentEntries: sql`current_entries + 1` })
          .where(eq(contests.id, contestId));
      });
      return NextResponse.json({ ok: true });
    }

    if (action === "create") {
      const u = requireAdmin(user);
      const [c] = await db
        .insert(contests)
        .values({
          title: String(body.title),
          description: body.description || null,
          prize: String(body.prize),
          prizeValue: body.prizeValue ? String(body.prizeValue) : null,
          entryCost: Number(body.entryCost) || 100,
          maxEntries: body.maxEntries ? Number(body.maxEntries) : null,
          endsAt: new Date(String(body.endsAt)),
          active: true,
        })
        .returning();
      return NextResponse.json({ ok: true, contest: c });
    }

    if (action === "draw") {
      const u = requireAdmin(user);
      const id = Number(body.id);
      const [contest] = await db.select().from(contests).where(eq(contests.id, id)).limit(1);
      if (!contest) return NextResponse.json({ error: "غير موجود" }, { status: 404 });
      const entries = await db
        .select()
        .from(contestEntries)
        .where(eq(contestEntries.contestId, id))
        .orderBy(asc(contestEntries.id));
      if (entries.length === 0)
        return NextResponse.json({ error: "لا يوجد مشاركون" }, { status: 400 });
      const winner = entries[Math.floor(Math.random() * entries.length)];
      await db.update(contests).set({ winnerUserId: winner.userId }).where(eq(contests.id, id));
      return NextResponse.json({ ok: true, winnerUserId: winner.userId });
    }

    if (action === "delete") {
      const u = requireAdmin(user);
      await db.delete(contests).where(eq(contests.id, Number(body.id)));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "غير مدعوم" }, { status: 400 });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "UNAUTHORIZED") return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    if (msg === "FORBIDDEN") return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    console.error(e);
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}
