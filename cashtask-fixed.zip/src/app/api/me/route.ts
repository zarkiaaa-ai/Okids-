import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function publicUser(u: typeof users.$inferSelect) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    balance: u.balance,
    points: u.points,
    referralCode: u.referralCode,
    isAdmin: u.isAdmin,
    telegram: u.telegram,
    usdtAddress: u.usdtAddress,
    ccpRip: u.ccpRip,
    gameFreefireId: u.gameFreefireId,
    gamePubgId: u.gamePubgId,
    displayName: u.displayName,
    avatarUrl: u.avatarUrl,
    language: u.language,
    notifications: u.notifications,
    createdAt: u.createdAt,
  };
}

export async function GET() {
  try {
    const u = await getSessionUser();
    if (!u) return NextResponse.json({ authenticated: false }, { status: 401 });
    return NextResponse.json({ authenticated: true, user: publicUser(u) });
  } catch (e) {
    console.error("[me GET]", e);
    return NextResponse.json({ authenticated: false }, { status: 503 });
  }
}

export async function PATCH(req: Request) {
  const u = await getSessionUser();
  if (!u) return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
  const body = await req.json().catch(() => ({}));

  const patch: Partial<typeof users.$inferInsert> = {};
  if (typeof body.displayName === "string") patch.displayName = body.displayName.trim().slice(0, 64) || null;
  if (typeof body.avatarUrl === "string") patch.avatarUrl = body.avatarUrl.slice(0, 400000) || null;
  if (body.language === "ar" || body.language === "fr" || body.language === "en") patch.language = body.language;
  if (typeof body.notifications === "boolean") patch.notifications = body.notifications;
  if (typeof body.telegram === "string") patch.telegram = body.telegram.trim() || null;
  if (typeof body.usdtAddress === "string") patch.usdtAddress = body.usdtAddress.trim() || null;
  if (typeof body.ccpRip === "string") patch.ccpRip = body.ccpRip.trim() || null;
  if (typeof body.gameFreefireId === "string") patch.gameFreefireId = body.gameFreefireId.trim() || null;
  if (typeof body.gamePubgId === "string") patch.gamePubgId = body.gamePubgId.trim() || null;

  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ ok: true, user: publicUser(u) });
  }

  const [updated] = await db.update(users).set(patch).where(eq(users.id, u.id)).returning();
  return NextResponse.json({ ok: true, user: publicUser(updated) });
}
