import { NextResponse } from "next/server";
import { eq, and, desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { tasks, taskCompletions } from "@/db/schema";
import { getSessionUser, requireAdmin, requireUser } from "@/lib/auth";

export const runtime = "nodejs";

// GET /api/tasks  => list
// GET /api/tasks?my=1 => my completions
export async function GET(req: Request) {
  try {
    try {
      const { seedIfEmpty } = await import("@/lib/seed");
      await seedIfEmpty();
    } catch {
      /* ignore */
    }
    const user = await getSessionUser();
    const url = new URL(req.url);
    const my = url.searchParams.get("my");
    if (url.searchParams.get("all") === "1") {
      const rows = await db.select().from(tasks).orderBy(desc(tasks.createdAt));
      return NextResponse.json({ tasks: rows });
    }

    if (my === "1") {
      const u = requireUser(user);
      const rows = await db
        .select({
          id: taskCompletions.id,
          taskId: taskCompletions.taskId,
          status: taskCompletions.status,
          proofText: taskCompletions.proofText,
          createdAt: taskCompletions.createdAt,
          taskTitle: tasks.title,
          reward: tasks.reward,
          taskType: tasks.type,
        })
        .from(taskCompletions)
        .innerJoin(tasks, eq(tasks.id, taskCompletions.taskId))
        .where(eq(taskCompletions.userId, u.id))
        .orderBy(desc(taskCompletions.createdAt));
      return NextResponse.json({ completions: rows });
    }

    const rows = await db
      .select()
      .from(tasks)
      .where(eq(tasks.active, true))
      .orderBy(desc(tasks.createdAt));
    return NextResponse.json({ tasks: rows });
  } catch (e) {
    console.error("[tasks GET]", e);
    return NextResponse.json({
      tasks: [
        { id: 1, title: "تابع قناة Telegram", description: "انضم للقناة الرسمية", type: "follow_telegram", reward: "0.05", targetUrl: "https://t.me/example", proofHint: "اسم المستخدم", maxCompletions: null, currentCompletions: 0, active: true },
        { id: 2, title: "تابعنا على YouTube", description: "اشترك وفعّل الجرس", type: "follow_youtube", reward: "0.08", targetUrl: "https://youtube.com", proofHint: "رابط القناة", maxCompletions: null, currentCompletions: 0, active: true },
        { id: 3, title: "تابعنا على TikTok", description: "تابع الحساب الرسمي", type: "follow_tiktok", reward: "0.05", targetUrl: "https://tiktok.com", proofHint: "اسم المستخدم", maxCompletions: null, currentCompletions: 0, active: true },
        { id: 4, title: "ثبّت تطبيق المحفظة", description: "حمّل وسجّل حساباً", type: "install_app", reward: "0.40", targetUrl: "https://example.com", proofHint: "لقطة شاشة", maxCompletions: null, currentCompletions: 0, active: true },
        { id: 5, title: "حمّل لعبة واصل للمستوى 10", description: "مهمة ألعاب", type: "app_level", reward: "1.50", targetUrl: "https://example.com/game", proofHint: "لقطة المستوى", maxCompletions: null, currentCompletions: 0, active: true },
        { id: 6, title: "استبيان قصير", description: "أجب عن 5 أسئلة", type: "other", reward: "0.35", targetUrl: "https://example.com/survey", proofHint: "رمز الإتمام", maxCompletions: null, currentCompletions: 0, active: true },
      ],
      completions: [],
    });
  }
}

// POST /api/tasks  => submit completion OR (admin) create/update/delete
export async function POST(req: Request) {
  const user = await getSessionUser();
  const body = await req.json().catch(() => ({}));
  const action = (body.action as string) || "submit";

  try {
    if (action === "submit") {
      const u = requireUser(user);
      const taskId = Number(body.taskId);
      const proofText = String(body.proofText || "").slice(0, 500);
      if (!taskId) return NextResponse.json({ error: "مهمة غير صحيحة" }, { status: 400 });

      const task = await db.select().from(tasks).where(eq(tasks.id, taskId)).limit(1);
      if (!task[0] || !task[0].active) {
        return NextResponse.json({ error: "المهمة غير متاحة" }, { status: 404 });
      }
      if (
        task[0].maxCompletions !== null &&
        task[0].currentCompletions >= task[0].maxCompletions
      ) {
        return NextResponse.json({ error: "انتهت الحصص" }, { status: 410 });
      }
      const existing = await db
        .select({ id: taskCompletions.id })
        .from(taskCompletions)
        .where(and(eq(taskCompletions.userId, u.id), eq(taskCompletions.taskId, taskId)))
        .limit(1);
      if (existing.length) {
        return NextResponse.json({ error: "سبق لك تقديم هذه المهمة" }, { status: 409 });
      }
      await db.insert(taskCompletions).values({
        taskId,
        userId: u.id,
        proofText: proofText || null,
        status: "pending",
      });
      return NextResponse.json({ ok: true });
    }

    if (action === "create") {
      const u = requireAdmin(user);
      const t = await db
        .insert(tasks)
        .values({
          title: String(body.title),
          description: body.description || null,
          type: String(body.type),
          reward: String(body.reward),
          targetUrl: body.targetUrl || null,
          proofHint: body.proofHint || null,
          maxCompletions: body.maxCompletions ? Number(body.maxCompletions) : null,
          active: body.active !== false,
        })
        .returning();
      return NextResponse.json({ ok: true, task: t[0] });
    }

    if (action === "update") {
      const u = requireAdmin(user);
      const id = Number(body.id);
      const [updated] = await db
        .update(tasks)
        .set({
          title: body.title,
          description: body.description ?? null,
          type: body.type,
          reward: String(body.reward),
          targetUrl: body.targetUrl ?? null,
          proofHint: body.proofHint ?? null,
          maxCompletions: body.maxCompletions ? Number(body.maxCompletions) : null,
          active: body.active,
        })
        .where(eq(tasks.id, id))
        .returning();
      return NextResponse.json({ ok: true, task: updated });
    }

    if (action === "delete") {
      const u = requireAdmin(user);
      await db.delete(tasks).where(eq(tasks.id, Number(body.id)));
      return NextResponse.json({ ok: true });
    }

    if (action === "review") {
      const u = requireAdmin(user);
      const cid = Number(body.id);
      const status = body.status as "approved" | "rejected";
      const [comp] = await db
        .select()
        .from(taskCompletions)
        .where(eq(taskCompletions.id, cid))
        .limit(1);
      if (!comp) return NextResponse.json({ error: "غير موجود" }, { status: 404 });
      if (comp.status !== "pending")
        return NextResponse.json({ error: "تمت معالجتها مسبقاً" }, { status: 409 });

      if (status === "approved") {
        // جلب المستخدم صاحب الإكمال والمهمة
        // eslint-disable-next-line @typescript-eslint/no-require-imports
        const { users: Users } = await import("@/db/schema");
        const [owner] = await db.select().from(Users).where(eq(Users.id, comp.userId)).limit(1);
        const [taskRow] = await db
          .select({ reward: tasks.reward })
          .from(tasks)
          .where(eq(tasks.id, comp.taskId))
          .limit(1);
        const rewardVal = parseFloat(taskRow?.reward || "0");
        const { usdToPoints } = await import("@/lib/constants");
        const pts = usdToPoints(rewardVal);
        await db.execute(
          sql`update users set balance = (balance::numeric + ${rewardVal}::numeric)::text, points = points + ${pts} where id = ${comp.userId}`
        );
        await db.execute(
          sql`update tasks set current_completions = current_completions + 1 where id = ${comp.taskId}`
        );
        if (owner?.referredBy) {
          await db.execute(
            sql`update users set balance = (balance::numeric + (${rewardVal}::numeric * 0.10))::text where id = ${owner.referredBy}`
          );
        }
      }

      await db
        .update(taskCompletions)
        .set({ status, reviewedAt: new Date() })
        .where(eq(taskCompletions.id, cid));
      return NextResponse.json({ ok: true });
    }

    return NextResponse.json({ error: "عملية غير مدعومة" }, { status: 400 });
  } catch (e) {
    console.error(e);
    const msg = e instanceof Error ? e.message : "error";
    if (msg === "UNAUTHORIZED") return NextResponse.json({ error: "سجّل الدخول" }, { status: 401 });
    if (msg === "FORBIDDEN") return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
    return NextResponse.json({ error: "خطأ في الخادم" }, { status: 500 });
  }
}
