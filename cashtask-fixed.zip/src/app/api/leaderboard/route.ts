import { NextResponse } from "next/server";
import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSessionUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const me = await getSessionUser().catch(() => null);
  try {
    // استعلام واحد: أفضل 20 + عدد المهام المقبولة لكل واحد
    const top = await db.execute(sql`
      SELECT u.id, u.username, u."display_name" AS "displayName", u.points,
        COALESCE((SELECT count(*)::int FROM task_completions tc WHERE tc.user_id = u.id AND tc.status = 'approved'), 0) AS approved
      FROM users u
      ORDER BY u.points DESC
      LIMIT 20
    `);

    let myRank: number | null = null;
    if (me) {
      try {
        const r = await db.execute(sql`SELECT count(*)::int AS c FROM users WHERE points > ${me.points}`);
        const c = Number((r.rows?.[0] as { c: number } | undefined)?.c || 0);
        myRank = c + 1;
      } catch {
        myRank = null;
      }
    }

    const rows = (top.rows || []) as { id: number; username: string; displayName: string | null; points: number; approved: number }[];
    return NextResponse.json({ top: rows, myRank, myPoints: me?.points || 0 });
  } catch {
    return NextResponse.json({ top: [], myRank: null, myPoints: 0 });
  }
}
