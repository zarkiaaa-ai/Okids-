import { NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  users,
  tasks,
  ads,
  adViews,
  taskCompletions,
  withdrawals,
  contests,
} from "@/db/schema";
import { getSessionUser } from "@/lib/auth";
import { usdToPoints } from "@/lib/constants";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function safe<T>(fn: () => Promise<T>, fb: T): Promise<T> {
  try {
    return await fn();
  } catch {
    return fb;
  }
}

export async function GET() {
  let user;
  try {
    user = await getSessionUser();
  } catch (e) {
    console.error("[overview user]", e);
    return NextResponse.json({ error: "تعذر الاتصال" }, { status: 503 });
  }
  if (!user) return NextResponse.json({ error: "no user" }, { status: 401 });

  const [me] = await Promise.all([
    safe(
      async () => (await db.select().from(users).where(eq(users.id, user.id)).limit(1))[0] || user,
      user
    ),
  ]);

  const [tasksActive, adsActive, contestsActive] = await Promise.all([
    safe(async () => (await db.select({ c: sql<number>`count(*)::int` }).from(tasks).where(eq(tasks.active, true)))[0]?.c || 0, 0),
    safe(async () => (await db.select({ c: sql<number>`count(*)::int` }).from(ads).where(eq(ads.active, true)))[0]?.c || 0, 0),
    safe(async () => (await db.select({ c: sql<number>`count(*)::int` }).from(contests).where(eq(contests.active, true)))[0]?.c || 0, 0),
  ]);

  const completions = await safe(
    async () =>
      await db
        .select({ status: taskCompletions.status, reward: tasks.reward })
        .from(taskCompletions)
        .innerJoin(tasks, eq(tasks.id, taskCompletions.taskId))
        .where(eq(taskCompletions.userId, me.id)),
    [] as { status: string; reward: string }[]
  );
  let approvedCount = 0;
  let pendingCount = 0;
  let pendingPoints = 0;
  for (const c of completions) {
    if (c.status === "approved") approvedCount++;
    if (c.status === "pending") {
      pendingCount++;
      pendingPoints += usdToPoints(c.reward || "0");
    }
  }

  const todayAds = await safe(
    async () =>
      (
        await db
          .select({
            c: sql<number>`count(*)::int`,
            total: sql<string>`coalesce(sum(${adViews.earned}::numeric),0)::text`,
          })
          .from(adViews)
          .where(sql`${adViews.userId} = ${me.id} AND ${adViews.viewedAt} >= current_date`)
      )[0] || { c: 0, total: "0" },
    { c: 0, total: "0" }
  );

  const refs = await safe(
    async () =>
      await db
        .select({ balance: users.balance })
        .from(users)
        .where(eq(users.referredBy, me.id)),
    [] as { balance: string }[]
  );

  const payoutsPending = await safe(
    async () =>
      (await db.select({ c: sql<number>`count(*)::int` }).from(withdrawals).where(sql`${withdrawals.userId} = ${me.id} AND ${withdrawals.status} = 'pending'`))[0]?.c || 0,
    0
  );

  const last = me.lastDailyAt ? new Date(me.lastDailyAt) : null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const claimedToday = !!(last && last.getTime() >= today.getTime());
  const streak = me.dailyStreak || 0;

  const recentWithdrawals = await safe(
    async () =>
      await db
        .select({
          amount: withdrawals.amount,
          status: withdrawals.status,
          createdAt: withdrawals.createdAt,
        })
        .from(withdrawals)
        .where(eq(withdrawals.userId, me.id))
        .orderBy(sql`${withdrawals.createdAt} DESC`)
        .limit(3),
    [] as { amount: string; status: string; createdAt: Date }[]
  );

  return NextResponse.json({
    points: me.points || 0,
    balance: me.balance || "0",
    name: me.displayName || me.username || "زائر",
    email: me.email || "",
    avatarUrl: me.avatarUrl || null,
    referralCode: me.referralCode || "",
    createdAt: me.createdAt ? new Date(me.createdAt).toISOString() : null,
    isAdmin: !!me.isAdmin,
    hasName: !!(me.displayName && me.displayName.trim()),
    hasAvatar: !!(me.avatarUrl && me.avatarUrl.trim()),
    hasPayout: !!((me.usdtAddress && me.usdtAddress.trim()) || (me.ccpRip && me.ccpRip.trim())),
    hasGameId: !!((me.gameFreefireId && me.gameFreefireId.trim()) || (me.gamePubgId && me.gamePubgId.trim())),
    recentWithdrawals: recentWithdrawals.map((w) => ({
      amount: w.amount,
      status: w.status,
      createdAt: w.createdAt ? new Date(w.createdAt).toISOString() : null,
    })),
    pendingPoints,
    approvedCount,
    pendingCount,
    todayAds: todayAds.c || 0,
    todayAdsUsd: parseFloat(todayAds.total || "0"),
    tasksActive,
    adsActive,
    referrals: refs.length,
    activeReferrals: refs.filter((r) => parseFloat(r.balance || "0") > 0).length,
    canClaim: !claimedToday,
    streak,
    todayReward: 10 + Math.min(claimedToday ? streak : streak + 1, 7) * 5,
    contestsActive,
    payoutsPending,
  });
}
