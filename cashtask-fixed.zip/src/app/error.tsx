"use client";

export default function ErrorPage({ reset }: { reset: () => void }) {
  return (
    <main className="min-h-screen flex items-center justify-center p-6 bg-app">
      <div className="text-center">
        <div className="text-4xl mb-3">💰</div>
        <p className="font-black text-lg mb-2">حدث خطأ بسيط</p>
        <button onClick={reset} className="px-5 py-2 rounded-xl bg-sky-500 text-white font-bold">
          إعادة المحاولة
        </button>
      </div>
    </main>
  );
}
