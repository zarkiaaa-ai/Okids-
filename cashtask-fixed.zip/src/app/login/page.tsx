"use client";

import { useEffect } from "react";

export default function LoginPage() {
  useEffect(() => {
    window.location.replace("/");
  }, []);
  return (
    <main className="min-h-screen flex items-center justify-center bg-app">
      <div className="text-center">
        <div className="text-4xl mb-3">💰</div>
        <p className="font-bold">جاري فتح التطبيق...</p>
      </div>
    </main>
  );
}
