"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { formatUsd } from "@/lib/constants";

// Admin identity now comes entirely from the real, httpOnly session cookie
// set by /login — the browser attaches it automatically, so no password
// needs to live in this file or in the JS bundle shipped to visitors.
function adminFetch(input: string, init: RequestInit = {}) {
  return fetch(input, { ...init, credentials: "include" });
}

type Tab =
  | "home"
  | "people"
  | "withdraw"
  | "tasks"
  | "ads"
  | "review"
  | "points"
  | "topup"
  | "contests"
  | "settings";

export default function AdminPage() {
  const [status, setStatus] = useState<"checking" | "denied" | "ok">("checking");
  const [tab, setTab] = useState<Tab>("home");
  const [stats, setStats] = useState<Record<string, number | string> | null>(null);

  useEffect(() => {
    (async () => {
      const r = await adminFetch("/api/admin");
      if (r.status === 401 || r.status === 403) {
        setStatus("denied");
        return;
      }
      const j = await r.json().catch(() => ({} as any));
      setStats(j.stats || null);
      setStatus("ok");
    })();
  }, []);

  useEffect(() => {
    if (status === "denied") {
      const t = setTimeout(() => {
        window.location.href = "/login?next=/admin";
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [status]);

  async function logout() {
    await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ action: "logout" }),
    });
    window.location.href = "/login";
  }

  if (status === "checking") {
    return (
      <main className="min-h-screen flex items-center justify-center px-4 text-slate-400">
        جارٍ التحقق من صلاحياتك...
      </main>
    );
  }

  if (status === "denied") {
    return (
      <main className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center text-slate-400 max-w-sm">
          <div className="text-3xl mb-2">🔒</div>
          <p className="font-bold text-slate-200">هذه الصفحة لمسؤولي التطبيق فقط</p>
          <p className="text-sm mt-2">سجّل دخولك بحساب مسؤول من صفحة تسجيل الدخول. يتم تحويلك الآن...</p>
        </div>
      </main>
    );
  }

  const tabs: { id: Tab; label: string }[] = [
    { id: "home", label: "الرئيسية" },
    { id: "people", label: "الناس" },
    { id: "withdraw", label: "السحب" },
    { id: "review", label: "المراجعة" },
    { id: "tasks", label: "المهام" },
    { id: "ads", label: "الإعلانات" },
    { id: "points", label: "النقاط" },
    { id: "topup", label: "الشحن" },
    { id: "contests", label: "مسابقات" },
    { id: "settings", label: "إعدادات" },
  ];

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 bg-slate-950/95 border-b border-slate-800 px-4 py-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="font-black">لوحة التحكم</div>
            <div className="text-[11px] text-slate-400">{Number(stats?.users || 0)} مستخدم</div>
          </div>
          <div className="flex gap-2">
            <Link href="/" className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs">التطبيق</Link>
            <button
              className="px-3 py-1.5 rounded-lg bg-red-500/20 text-red-300 text-xs"
              onClick={logout}
            >
              خروج
            </button>
          </div>
        </div>
        <div className="flex gap-1.5 overflow-x-auto mt-3 pb-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-bold whitespace-nowrap ${
                tab === t.id ? "bg-white text-slate-900" : "bg-slate-800 text-slate-300"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </header>

      <div className="px-4 py-4 space-y-4 max-w-3xl mx-auto">
        {tab === "home" && <Home stats={stats} onOpen={setTab} />}
        {tab === "people" && <People />}
        {tab === "withdraw" && <Pending kind="pendingWithdraw" />}
        {tab === "review" && <Reviews />}
        {tab === "tasks" && <Tasks />}
        {tab === "ads" && <Ads />}
        {tab === "points" && <Pending kind="pendingPoints" />}
        {tab === "topup" && <Pending kind="pendingTopup" />}
        {tab === "contests" && <Contests />}
        {tab === "settings" && <Settings />}
      </div>
    </div>
  );
}

function Home({
  stats,
  onOpen,
}: {
  stats: Record<string, number | string> | null;
  onOpen: (t: Tab) => void;
}) {
  const s = stats || {};
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3">
        <Stat title="عدد الناس" value={String(s.users || 0)} onClick={() => onOpen("people")} />
        <Stat title="مجموع النقاط" value={String(s.totalPoints || 0)} onClick={() => onOpen("people")} />
        <Stat title="طلبات سحب" value={String(s.pendingWithdraw || 0)} sub={formatUsd(String(s.pendingWithdrawUsd || 0))} onClick={() => onOpen("withdraw")} warn />
        <Stat title="مهام للمراجعة" value={String(s.pendingTasks || 0)} onClick={() => onOpen("review")} warn />
        <Stat title="رصيد الكل" value={formatUsd(String(s.totalBalance || 0))} />
        <Stat title="شحن معلّق" value={String(s.pendingTopup || 0)} onClick={() => onOpen("topup")} />
      </div>
      <p className="text-xs text-slate-500">اضغط أي بطاقة لفتح القسم.</p>
    </div>
  );
}

function Stat({
  title,
  value,
  sub,
  warn,
  onClick,
}: {
  title: string;
  value: string;
  sub?: string;
  warn?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-right rounded-2xl p-4 border ${
        warn ? "border-amber-500/40 bg-amber-500/10" : "border-slate-800 bg-slate-900"
      }`}
    >
      <div className="text-[11px] text-slate-400">{title}</div>
      <div className="text-2xl font-black mt-1">{value}</div>
      {sub && <div className="text-xs text-slate-400 mt-1">{sub}</div>}
    </button>
  );
}

function People() {
  const [items, setItems] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [edit, setEdit] = useState<any | null>(null);
  const [points, setPoints] = useState("");
  const [balance, setBalance] = useState("");

  async function load() {
    const r = await adminFetch("/api/admin/list?kind=users");
    const j = await r.json();
    setItems(j.items || []);
  }
  useEffect(() => {
    load();
  }, []);

  const filtered = items.filter(
    (u) =>
      !q ||
      String(u.username).includes(q) ||
      String(u.email).includes(q)
  );

  async function save() {
    if (!edit) return;
    await adminFetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "adjust-user", userId: edit.id, points, balance }),
    });
    setEdit(null);
    await load();
  }

  return (
    <div className="space-y-3">
      <input className="field-input" placeholder="بحث بالاسم أو البريد" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="text-xs text-slate-400">{filtered.length} شخص</div>
      {filtered.map((u) => (
        <div key={u.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-black">{u.displayName || u.username} {u.isAdmin ? "👑" : ""}</div>
              <div className="text-[11px] text-slate-400">{u.email}</div>
            </div>
            <button
              className="text-xs px-2 py-1 rounded-lg bg-slate-800"
              onClick={() => {
                setEdit(u);
                setPoints(String(u.points));
                setBalance(String(u.balance));
              }}
            >
              تعديل
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="rounded-xl bg-slate-950 p-2">
              <div className="text-[10px] text-slate-500">النقاط</div>
              <div className="font-black text-sky-400">{u.points}</div>
            </div>
            <div className="rounded-xl bg-slate-950 p-2">
              <div className="text-[10px] text-slate-500">الرصيد</div>
              <div className="font-black text-emerald-400">{formatUsd(u.balance)}</div>
            </div>
          </div>
        </div>
      ))}
      {edit && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end p-4">
          <div className="w-full rounded-2xl bg-slate-900 p-4 space-y-2">
            <div className="font-black">تعديل {edit.username}</div>
            <input className="field-input" value={points} onChange={(e) => setPoints(e.target.value)} placeholder="النقاط" />
            <input className="field-input" value={balance} onChange={(e) => setBalance(e.target.value)} placeholder="الرصيد بالدولار" />
            <div className="flex gap-2">
              <button onClick={save} className="flex-1 py-2 rounded-xl bg-emerald-600 font-bold">حفظ</button>
              <button onClick={() => setEdit(null)} className="flex-1 py-2 rounded-xl bg-slate-700">إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Pending({ kind }: { kind: "pendingWithdraw" | "pendingPoints" | "pendingTopup" }) {
  const [items, setItems] = useState<any[]>([]);
  async function load() {
    const r = await adminFetch(`/api/admin/list?kind=${kind}`);
    const j = await r.json();
    setItems(j.items || []);
  }
  useEffect(() => {
    load();
  }, [kind]);
  async function process(id: number, status: "completed" | "rejected") {
    const endpoint = kind === "pendingPoints" ? "/api/points" : kind === "pendingTopup" ? "/api/topup" : "/api/withdraw";
    await adminFetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "process", id, status }),
    });
    await load();
  }
  if (!items.length) return <Empty text="لا توجد طلبات الآن" />;
  return (
    <div className="space-y-2">
      {items.map((it) => (
        <div key={it.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <div className="font-black">{it.user?.username || "مستخدم"}</div>
          <div className="text-xs text-slate-400 mt-1 break-all">
            {kind === "pendingWithdraw" && `${it.method === "usdt" ? "USDT" : "CCP"} · ${formatUsd(it.amount)} · ${it.address}`}
            {kind === "pendingPoints" && `${it.points} نقطة · ${it.method} · ${it.txId}`}
            {kind === "pendingTopup" && `${it.game} · ${it.packageLabel} · ID ${it.playerId}`}
          </div>
          <div className="flex gap-2 mt-3">
            <button onClick={() => process(it.id, "completed")} className="flex-1 py-2 rounded-xl bg-emerald-600 font-bold text-sm">تنفيذ</button>
            <button onClick={() => process(it.id, "rejected")} className="flex-1 py-2 rounded-xl bg-red-600 font-bold text-sm">رفض</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function Reviews() {
  const [items, setItems] = useState<any[]>([]);
  async function load() {
    const r = await adminFetch("/api/admin/list?kind=pendingTasks");
    const j = await r.json();
    setItems(j.items || []);
  }
  useEffect(() => {
    load();
  }, []);
  async function review(id: number, status: "approved" | "rejected") {
    await adminFetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "review", id, status }),
    });
    await load();
  }
  if (!items.length) return <Empty text="لا توجد إثباتات للمراجعة" />;
  return (
    <div className="space-y-2">
      {items.map((it) => (
        <div key={it.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <div className="font-black">{it.task?.title}</div>
          <div className="text-xs text-slate-400">{it.user?.username} · {formatUsd(it.task?.reward || 0)}</div>
          {it.proofText && <div className="mt-2 text-sm bg-slate-950 rounded-xl p-2">{it.proofText}</div>}
          <div className="flex gap-2 mt-3">
            <button onClick={() => review(it.id, "approved")} className="flex-1 py-2 rounded-xl bg-emerald-600 font-bold text-sm">قبول</button>
            <button onClick={() => review(it.id, "rejected")} className="flex-1 py-2 rounded-xl bg-red-600 font-bold text-sm">رفض</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function Tasks() {
  const [items, setItems] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ title: "", type: "follow_telegram", reward: "0.05", targetUrl: "", proofHint: "", description: "", active: true });
  async function load() {
    const r = await adminFetch("/api/tasks?all=1");
    setItems((await r.json()).tasks || []);
  }
  useEffect(() => {
    load();
  }, []);
  async function save() {
    await adminFetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: form.id ? "update" : "create", ...form }),
    });
    setOpen(false);
    await load();
  }
  return (
    <div className="space-y-3">
      <button onClick={() => { setForm({ title: "", type: "follow_telegram", reward: "0.05", targetUrl: "", proofHint: "", description: "", active: true }); setOpen(true); }} className="w-full py-3 rounded-2xl bg-sky-600 font-black">+ مهمة جديدة</button>
      {open && (
        <div className="rounded-2xl bg-slate-900 border border-slate-700 p-3 space-y-2">
          <input className="field-input" placeholder="العنوان" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <select className="field-input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
            {["follow_telegram","follow_youtube","follow_tiktok","install_app","app_level","register_app","other"].map((t) => <option key={t}>{t}</option>)}
          </select>
          <input className="field-input" placeholder="المكافأة $" value={form.reward} onChange={(e) => setForm({ ...form, reward: e.target.value })} />
          <input className="field-input" placeholder="الرابط" value={form.targetUrl} onChange={(e) => setForm({ ...form, targetUrl: e.target.value })} />
          <input className="field-input" placeholder="ماذا يرسل كدليل؟" value={form.proofHint} onChange={(e) => setForm({ ...form, proofHint: e.target.value })} />
          <div className="flex gap-2">
            <button onClick={save} className="flex-1 py-2 rounded-xl bg-emerald-600 font-bold">حفظ</button>
            <button onClick={() => setOpen(false)} className="flex-1 py-2 rounded-xl bg-slate-700">إلغاء</button>
          </div>
        </div>
      )}
      {items.map((t) => (
        <div key={t.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <div className="font-black">{t.title}</div>
          <div className="text-xs text-slate-400">{t.type} · ${t.reward} · {t.active ? "نشطة" : "موقوفة"}</div>
          <div className="flex gap-2 mt-2">
            <button className="flex-1 py-2 rounded-xl bg-slate-800 text-sm" onClick={() => { setForm(t); setOpen(true); }}>تعديل</button>
            <button className="flex-1 py-2 rounded-xl bg-red-600 text-sm" onClick={async () => { await adminFetch("/api/tasks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "delete", id: t.id }) }); await load(); }}>حذف</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function Ads() {
  const [items, setItems] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<any>({ title: "", targetUrl: "", reward: "0.005", requiredSeconds: 15, cooldownHours: 24, active: true });
  async function load() {
    const r = await adminFetch("/api/ads?all=1");
    setItems((await r.json()).ads || []);
  }
  useEffect(() => { load(); }, []);
  async function save() {
    await adminFetch("/api/ads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: form.id ? "update" : "create", ...form }) });
    setOpen(false);
    await load();
  }
  return (
    <div className="space-y-3">
      <button onClick={() => { setForm({ title: "", targetUrl: "", reward: "0.005", requiredSeconds: 15, cooldownHours: 24, active: true }); setOpen(true); }} className="w-full py-3 rounded-2xl bg-amber-500 text-black font-black">+ إعلان جديد</button>
      {open && (
        <div className="rounded-2xl bg-slate-900 border border-slate-700 p-3 space-y-2">
          <input className="field-input" placeholder="العنوان" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          <input className="field-input" placeholder="رابط الإعلان" value={form.targetUrl} onChange={(e) => setForm({ ...form, targetUrl: e.target.value })} />
          <input className="field-input" placeholder="المكافأة $" value={form.reward} onChange={(e) => setForm({ ...form, reward: e.target.value })} />
          <input className="field-input" placeholder="ثواني المشاهدة" value={form.requiredSeconds} onChange={(e) => setForm({ ...form, requiredSeconds: e.target.value })} />
          <div className="flex gap-2">
            <button onClick={save} className="flex-1 py-2 rounded-xl bg-emerald-600 font-bold">حفظ</button>
            <button onClick={() => setOpen(false)} className="flex-1 py-2 rounded-xl bg-slate-700">إلغاء</button>
          </div>
        </div>
      )}
      {items.map((a) => (
        <div key={a.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <div className="font-black">{a.title}</div>
          <div className="text-xs text-slate-400">${a.reward} · {a.requiredSeconds}ث</div>
          <div className="flex gap-2 mt-2">
            <button className="flex-1 py-2 rounded-xl bg-slate-800 text-sm" onClick={() => { setForm(a); setOpen(true); }}>تعديل</button>
            <button className="flex-1 py-2 rounded-xl bg-red-600 text-sm" onClick={async () => { await adminFetch("/api/ads", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "delete", id: a.id }) }); await load(); }}>حذف</button>
          </div>
        </div>
      ))}
    </div>
  );
}

function Contests() {
  const [items, setItems] = useState<any[]>([]);
  const [form, setForm] = useState({ title: "", prize: "", entryCost: "100", endsAt: "" });
  async function load() {
    const r = await adminFetch("/api/admin/list?kind=contests");
    setItems((await r.json()).items || []);
  }
  useEffect(() => { load(); }, []);
  return (
    <div className="space-y-3">
      <div className="rounded-2xl bg-slate-900 border border-slate-800 p-3 space-y-2">
        <input className="field-input" placeholder="عنوان المسابقة" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input className="field-input" placeholder="الجائزة" value={form.prize} onChange={(e) => setForm({ ...form, prize: e.target.value })} />
        <input className="field-input" placeholder="تكلفة النقاط" value={form.entryCost} onChange={(e) => setForm({ ...form, entryCost: e.target.value })} />
        <input className="field-input" type="datetime-local" value={form.endsAt} onChange={(e) => setForm({ ...form, endsAt: e.target.value })} />
        <button
          className="w-full py-2 rounded-xl bg-fuchsia-600 font-bold"
          onClick={async () => {
            await adminFetch("/api/contests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "create", ...form, entryCost: Number(form.entryCost) }) });
            await load();
          }}
        >
          إنشاء مسابقة
        </button>
      </div>
      {items.map((c) => (
        <div key={c.id} className="rounded-2xl bg-slate-900 border border-slate-800 p-3">
          <div className="font-black">{c.title}</div>
          <div className="text-xs text-slate-400">{c.prize} · {c.currentEntries} مشارك</div>
          <button
            className="mt-2 w-full py-2 rounded-xl bg-amber-500 text-black font-bold text-sm"
            onClick={async () => {
              const r = await adminFetch("/api/contests", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action: "draw", id: c.id }) });
              const j = await r.json();
              alert(j.ok ? `الفائز #${j.winnerUserId}` : j.error);
              await load();
            }}
          >
            سحب فائز
          </button>
        </div>
      ))}
    </div>
  );
}

function Settings() {
  const [form, setForm] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState("");
  useEffect(() => {
    adminFetch("/api/settings").then((r) => r.json()).then((j) => setForm(j.settings || {}));
  }, []);
  const fields = [
    ["usdt_address", "محفظة USDT"],
    ["ccp_rip", "حساب CCP"],
    ["support_email", "بريد الدعم"],
    ["support_telegram", "تيليجرام الدعم"],
    ["min_withdraw", "أدنى سحب $"],
    ["announcement_title", "عنوان إعلان التطبيق (فارغ = إخفاء)"],
    ["announcement_text", "نص إعلان التطبيق"],
  ];
  return (
    <div className="space-y-2">
      {fields.map(([k, l]) => (
        <label key={k} className="block">
          <span className="text-xs text-slate-400">{l}</span>
          <input className="field-input mt-1" value={form[k] || ""} onChange={(e) => setForm({ ...form, [k]: e.target.value })} />
        </label>
      ))}
      {msg && <div className="text-emerald-400 text-sm">{msg}</div>}
      <button
        className="w-full py-3 rounded-2xl bg-purple-600 font-black"
        onClick={async () => {
          const r = await adminFetch("/api/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
          setMsg(r.ok ? "تم الحفظ" : "فشل");
        }}
      >
        حفظ الإعدادات
      </button>
    </div>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="rounded-2xl border border-slate-800 bg-slate-900 p-8 text-center text-slate-400">{text}</div>;
}
