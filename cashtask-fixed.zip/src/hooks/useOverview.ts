"use client";

import { useCallback, useEffect, useState } from "react";

export type Overview = {
  points: number;
  balance: string;
  name: string;
  pendingPoints: number;
  approvedCount: number;
  pendingCount: number;
  todayAds: number;
  todayAdsUsd: number;
  tasksActive: number;
  adsActive: number;
  referrals: number;
  activeReferrals: number;
  canClaim: boolean;
  streak: number;
  todayReward: number;
  contestsActive: number;
  payoutsPending: number;
  email: string;
  avatarUrl: string | null;
  referralCode: string;
  createdAt: string | null;
  isAdmin: boolean;
  hasName: boolean;
  hasAvatar: boolean;
  hasPayout: boolean;
  hasGameId: boolean;
  recentWithdrawals: { amount: string; status: string; createdAt: string | null }[];
};

const FALLBACK: Overview = {
  points: 0,
  balance: "0",
  name: "زائر",
  pendingPoints: 0,
  approvedCount: 0,
  pendingCount: 0,
  todayAds: 0,
  todayAdsUsd: 0,
  tasksActive: 0,
  adsActive: 0,
  referrals: 0,
  activeReferrals: 0,
  canClaim: true,
  streak: 0,
  todayReward: 20,
  contestsActive: 0,
  payoutsPending: 0,
  email: "",
  avatarUrl: null,
  referralCode: "",
  createdAt: null,
  isAdmin: false,
  hasName: false,
  hasAvatar: false,
  hasPayout: false,
  hasGameId: false,
  recentWithdrawals: [],
};

let cache: Overview | null = null;
let cacheAt = 0;
let inFlight: Promise<Overview> | null = null;
const TTL = 60_000;

export function useOverview() {
  const [data, setData] = useState<Overview>(cache || FALLBACK);
  const [loading, setLoading] = useState(!cache);
  const [error, setError] = useState(false);

  const refresh = useCallback(async (force = false) => {
    const hit = !force ? cache : null;
    if (hit && Date.now() - cacheAt < TTL) {
      setData(hit);
      setLoading(false);
      return hit;
    }
    if (inFlight && !force) {
      try {
        const shared = await inFlight;
        setData(shared);
        return shared;
      } catch {
        /* fall through */
      }
    }
    setError(false);
    const req: Promise<Overview> = (async () => {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 8000);
      try {
        const r = await fetch("/api/overview", { cache: "no-store", signal: ctrl.signal });
        const j = await r.json();
        if (!r.ok) throw new Error("bad");
        const fresh: Overview = { ...FALLBACK, ...j };
        cache = fresh;
        cacheAt = Date.now();
        setData(fresh);
        return fresh;
      } finally {
        clearTimeout(t);
      }
    })();
    inFlight = req;
    try {
      return await req;
    } catch {
      setError(true);
      return cache || FALLBACK;
    } finally {
      inFlight = null;
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { data, loading, error, refresh, setData };
}

export function bustOverviewCache() {
  cache = null;
  cacheAt = 0;
  inFlight = null;
}
