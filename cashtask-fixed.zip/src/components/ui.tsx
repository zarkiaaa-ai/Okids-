"use client";

import { useRouter } from "next/navigation";
import type { ReactNode } from "react";

/* ---------- sticky top bar with back button ---------- */
export function TopBar({
  title,
  sub,
  fallback = "/",
  action,
}: {
  title: string;
  sub?: string;
  fallback?: string;
  action?: ReactNode;
}) {
  const router = useRouter();
  function goBack() {
    if (typeof window !== "undefined" && window.history.length > 1) router.back();
    else router.push(fallback);
  }
  return (
    <div className="sticky top-0 z-30 -mx-4 px-4 pt-3 pb-3 bg-black/90 backdrop-blur border-b border-white/5">
      <div className="flex items-center gap-3">
        <button
          onClick={goBack}
          aria-label="رجوع"
          className="w-[52px] h-[52px] rounded-2xl bg-[#1c1c1f] border border-white/10 flex items-center justify-center text-[28px] font-black press shrink-0"
        >
          →
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black truncate">{title}</h1>
          {sub && <p className="text-xs text-zinc-400 truncate mt-1">{sub}</p>}
        </div>
        {action}
      </div>
    </div>
  );
}

/* ---------- layout primitives ---------- */
export function PageHead({
  title,
  sub,
  action,
}: {
  title: string;
  sub?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-start justify-between gap-3 mb-4">
      <div>
        <h1 className="text-xl font-black">{title}</h1>
        {sub && <p className="text-xs text-zinc-400 mt-1 leading-6">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-2">
      <h2 className="font-black text-[15px]">{children}</h2>
      {action}
    </div>
  );
}

/* ---------- feedback ---------- */
export function Notice({ tone = "info", children }: { tone?: "info" | "ok" | "err" | "warn"; children: ReactNode }) {
  const cls =
    tone === "ok"
      ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-300"
      : tone === "err"
      ? "bg-red-500/10 border-red-500/30 text-red-300"
      : tone === "warn"
      ? "bg-amber-500/10 border-amber-500/30 text-amber-300"
      : "bg-zinc-500/10 border-white/10 text-zinc-300";
  return <div className={`rounded-xl border px-3 py-2.5 text-[13px] leading-6 ${cls}`}>{children}</div>;
}

export function EmptyState({
  emoji,
  title,
  sub,
  action,
}: {
  emoji: string;
  title: string;
  sub?: string;
  action?: ReactNode;
}) {
  return (
    <div className="card-dark p-8 text-center">
      <div className="text-4xl mb-3">{emoji}</div>
      <div className="font-black">{title}</div>
      {sub && <p className="text-xs text-zinc-400 mt-2 leading-6">{sub}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function SkeletonList({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="skel h-20" />
      ))}
    </div>
  );
}

/* ---------- data display ---------- */
export function StatusPill({ status }: { status: string }) {
  const map: Record<string, { t: string; c: string }> = {
    pending: { t: "قيد المراجعة", c: "bg-amber-500/15 text-amber-300" },
    approved: { t: "مقبول", c: "bg-emerald-500/15 text-emerald-300" },
    completed: { t: "تم", c: "bg-emerald-500/15 text-emerald-300" },
    rejected: { t: "مرفوض", c: "bg-red-500/15 text-red-300" },
  };
  const s = map[status] || map.pending;
  return <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold whitespace-nowrap ${s.c}`}>{s.t}</span>;
}

export function ProgressRing({
  value,
  max,
  size = 200,
  label,
  sub,
}: {
  value: number;
  max: number;
  size?: number;
  label: string;
  sub?: string;
}) {
  const r = 80;
  const circ = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(1, max > 0 ? value / max : 0));
  return (
    <div className="relative mx-auto" style={{ width: size, height: size }}>
      <svg viewBox="0 0 200 200" className="w-full h-full -rotate-90">
        <circle cx="100" cy="100" r={r} fill="none" stroke="#17171a" strokeWidth="15" />
        <circle
          cx="100"
          cy="100"
          r={r}
          fill="none"
          stroke="#3d8f6e"
          strokeWidth="15"
          strokeLinecap="round"
          strokeDasharray={`${circ * p} ${circ}`}
          style={{ transition: "stroke-dasharray .6s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center">
        <div className="text-[26px] font-black tabular-nums leading-none">{label}</div>
        {sub && <div className="text-[11px] text-zinc-400 mt-1.5">{sub}</div>}
      </div>
    </div>
  );
}

export function LevelBar({ points, perLevel = 2000 }: { points: number; perLevel?: number }) {
  const level = Math.floor(points / perLevel) + 1;
  const cur = points % perLevel;
  return (
    <div className="rounded-2xl bg-white/5 border border-white/10 p-3">
      <div className="flex justify-between text-[11px] text-zinc-300 mb-1.5">
        <span className="font-bold">المستوى {level}</span>
        <span className="tabular-nums">{cur.toLocaleString()} / {perLevel.toLocaleString()}</span>
      </div>
      <div className="h-2 rounded-full bg-black/50 overflow-hidden">
        <div
          className="h-full rounded-full bg-gradient-to-l from-amber-400 to-orange-500"
          style={{ width: `${(cur / perLevel) * 100}%` }}
        />
      </div>
    </div>
  );
}

export function Segmented<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { id: T; label: string; icon?: string }[];
  value: T;
  onChange: (v: T) => void;
}) {
  return (
    <div className="grid gap-2 bg-[#141416] border border-white/5 rounded-2xl p-1.5" style={{ gridTemplateColumns: `repeat(${options.length}, 1fr)` }}>
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={`py-2.5 rounded-xl text-[13px] font-bold press ${
            value === o.id ? "bg-[#2a2a2e] text-white" : "text-zinc-500"
          }`}
        >
          {o.icon ? `${o.icon} ` : ""}{o.label}
        </button>
      ))}
    </div>
  );
}
