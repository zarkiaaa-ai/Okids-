"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { usdToPoints } from "@/lib/constants";

const VALID_TABS = ["all", "tasks", "games", "surveys", "ads", "mine"];
import { useOverview, bustOverviewCache } from "@/hooks/useOverview";
import { Notice, SkeletonList, StatusPill } from "@/components/ui";

type Task = {
  id: number;
  title: string;
  description: string | null;
  type: string;
  reward: string;
  targetUrl: string | null;
  proofHint: string | null;
};
type Ad = {
  id: number;
  title: string;
  targetUrl: string | null;
  reward: string;
  requiredSeconds: number;
  ready?: boolean;
  secondsLeft?: number;
};
type Completion = {
  id: number;
  taskId: number;
  status: string;
  taskTitle: string;
  reward: string;
  createdAt: string;
};

const FALLBACK: Task[] = [
  { id: -1, title: "تابع قناة Telegram", description: "انضم للقناة الرسمية", type: "follow_telegram", reward: "0.05", targetUrl: "https://t.me/example", proofHint: "اسم المستخدم" },
  { id: -2, title: "اشترك في YouTube", description: "فعّل الجرس", type: "follow_youtube", reward: "0.08", targetUrl: "https://youtube.com", proofHint: "رابط القناة" },
  { id: -3, title: "ثبّت تطبيق المحفظة", description: "حمّل وسجّل حساباً", type: "install_app", reward: "0.40", targetUrl: "https://example.com", proofHint: "لقطة شاشة" },
  { id: -4, title: "لعبة — وصل للمستوى 10", description: "حمّل اللعبة وارفع مستواك", type: "app_level", reward: "1.50", targetUrl: "https://example.com/game", proofHint: "لقطة المستوى" },
  { id: -5, title: "استطلاع رأي المستهلك", description: "5 دقائق فقط", type: "other", reward: "0.35", targetUrl: "https://example.com/survey", proofHint: "رمز الإتمام" },
];

const TYPE_META: Record<string, { e: string; t: string }> = {
  follow_telegram: { e: "✈️", t: "تيليجرام" },
  follow_youtube: { e: "▶️", t: "يوتيوب" },
  follow_tiktok: { e: "🎵", t: "تيك توك" },
  install_app: { e: "📲", t: "تطبيق" },
  register_app: { e: "📝", t: "تسجيل" },
  app_level: { e: "🎮", t: "لعبة" },
  ad_watch: { e: "📺", t: "إعلان" },
  other: { e: "📝", t: "استطلاع" },
};

function matches(tab: string, t: Task) {
  if (tab === "all") return true;
  if (tab === "surveys") return t.type === "other" || /استبيان|استطلاع|survey/i.test(t.title);
  if (tab === "games") return t.type === "app_level";
  if (tab === "ads") return false;
  return ["install_app", "register_app", "follow_telegram", "follow_youtube", "follow_tiktok"].includes(t.type);
}

function difficulty(usd: number) {
  if (usd >= 0.8) return { t: "عالية القيمة", c: "bg-fuchsia-500/15 text-fuchsia-300" };
  if (usd >= 0.2) return { t: "متوسطة", c: "bg-sky-500/15 text-sky-300" };
  return { t: "سهلة", c: "bg-emerald-500/15 text-emerald-300" };
}

function fmtCooldown(s?: number) {
  if (!s || s <= 0) return "";
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}س ${m}د`;
  if (m > 0) return `${m}د`;
  return `${s}ث`;
}

export function EarnScreen() {
  const ov = useOverview();
  const [tab, setTab] = useState("all");
  const [tasks, setTasks] = useState<Task[]>(FALLBACK);
  const [ads, setAds] = useState<Ad[]>([]);
  const [mine, setMine] = useState<Completion[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"top" | "easy">("top");
  const [proof, setProof] = useState<Record<number, string>>({});
  const [msg, setMsg] = useState<{ tone: "ok" | "err" | "info"; text: string } | null>(null);
  const [sending, setSending] = useState<number | null>(null);
  const [openId, setOpenId] = useState<number | null>(null);
  const [watching, setWatching] = useState<number | null>(null);
  const [count, setCount] = useState(0);
  const [announce, setAnnounce] = useState<{ title: string; text: string } | null>(null);
  const [claiming, setClaiming] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [visible, setVisible] = useState(8);

  async function loadAll(silent = false) {
    if (!silent) setLoaded(false);
    try {
      const [tRes, aRes, mRes] = await Promise.allSettled([
        fetch("/api/tasks").then((r) => r.json()),
        fetch("/api/ads").then((r) => r.json()),
        fetch("/api/tasks?my=1").then((r) => r.json()),
      ]);
      if (tRes.status === "fulfilled" && tRes.value.tasks?.length) setTasks(tRes.value.tasks);
      if (aRes.status === "fulfilled") setAds(aRes.value.ads || []);
      if (mRes.status === "fulfilled") setMine(mRes.value.completions || []);
    } catch {
      /* keep fallback */
    } finally {
      setLoaded(true);
    }
  }

  useEffect(() => {
    try {
      const p = new URLSearchParams(window.location.search).get("tab");
      if (p && VALID_TABS.includes(p)) setTab(p);
    } catch {
      /* ignore */
    }
    loadAll();
    fetch("/api/settings")
      .then((r) => r.json())
      .then((j) => {
        const t = String(j.settings?.announcement_title || "").trim();
        const x = String(j.settings?.announcement_text || "").trim();
        if (t || x) setAnnounce({ title: t, text: x });
      })
      .catch(() => {});
    try {
      if (!localStorage.getItem("ct_guide_seen")) setShowGuide(true);
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function dismissGuide() {
    setShowGuide(false);
    try {
      localStorage.setItem("ct_guide_seen", "1");
    } catch {
      /* ignore */
    }
  }

  async function claimDaily() {
    setClaiming(true);
    try {
      const r = await fetch("/api/rewards", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "claim-daily" }),
      });
      const j = await r.json().catch(() => ({}));
      if (r.ok) {
        setMsg({ tone: "ok", text: `تمت إضافة ${j.reward} نقطة 🎉 — سلسلة ${j.streak} أيام` });
        bustOverviewCache();
        ov.refresh(true);
      } else setMsg({ tone: "err", text: j.error || "تعذر الاستلام" });
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setClaiming(false);
    }
  }

  useEffect(() => {
    if (watching === null || count <= 0) return;
    const t = setTimeout(() => setCount((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [watching, count]);

  useEffect(() => {
    if (watching !== null && count === 0) finishAd(watching);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [count]);

  const doneIds = useMemo(() => new Set(mine.map((m) => m.taskId)), [mine]);

  const counts = useMemo(
    () => ({
      all: tasks.length,
      tasks: tasks.filter((t) => matches("tasks", t)).length,
      games: tasks.filter((t) => matches("games", t)).length,
      surveys: tasks.filter((t) => matches("surveys", t)).length,
      ads: ads.length,
    }),
    [tasks, ads]
  );

  const list = useMemo(() => {
    let l = tasks.filter((t) => matches(tab, t));
    if (q.trim()) {
      const s = q.trim();
      l = l.filter((t) => (t.title + (t.description || "")).includes(s));
    }
    l = [...l].sort((a, b) =>
      sort === "top"
        ? parseFloat(b.reward) - parseFloat(a.reward)
        : parseFloat(a.reward) - parseFloat(b.reward)
    );
    return l;
  }, [tasks, tab, q, sort]);

  async function submit(id: number) {
    if (id < 0) {
      setMsg({ tone: "info", text: "حدّث الصفحة لتحميل المهام الحقيقية ثم سلّم" });
      return;
    }
    setSending(id);
    setMsg(null);
    try {
      const r = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "submit", taskId: id, proofText: proof[id] || "" }),
      });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) setMsg({ tone: "err", text: j.error || "تعذر الإرسال" });
      else {
        setMsg({ tone: "ok", text: "تم الإرسال للمراجعة — تابع حالته في تبويب طلباتي" });
        setOpenId(null);
        bustOverviewCache();
        ov.refresh(true);
        const m = await fetch("/api/tasks?my=1").then((x) => x.json()).catch(() => ({}));
        setMine(m.completions || []);
      }
    } catch {
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    } finally {
      setSending(null);
    }
  }

  function startAd(ad: Ad) {
    if (ad.ready === false || watching !== null) return;
    if (ad.targetUrl) window.open(ad.targetUrl, "_blank", "noopener,noreferrer");
    setMsg(null);
    setWatching(ad.id);
    setCount(ad.requiredSeconds || 8);
  }

  async function finishAd(id: number) {
    try {
      const r = await fetch("/api/ads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ adId: id }),
      });
      const j = await r.json().catch(() => ({}));
      setWatching(null);
      if (r.ok) {
        setMsg({ tone: "ok", text: `ربحت ${usdToPoints(j.earned).toLocaleString()} نقطة` });
        bustOverviewCache();
        ov.refresh(true);
        const a = await fetch("/api/ads").then((x) => x.json()).catch(() => ({}));
        setAds(a.ads || []);
      } else setMsg({ tone: "err", text: j.error || "لم تكتمل المشاهدة" });
    } catch {
      setWatching(null);
      setMsg({ tone: "err", text: "تعذر الاتصال" });
    }
  }

  const opened = openId != null ? tasks.find((t) => t.id === openId) || null : null;
  const pendingMine = mine.filter((m) => m.status === "pending");

  return (
    <div className="-mx-4 min-h-[calc(100vh-88px)] bg-black text-white pb-6">
      {/* header */}
      <div className="bg-gradient-to-b from-[#7a2228] to-black px-4 pt-3 pb-4">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-[#c4122f] flex items-center justify-center font-black text-xl">C</div>
          <div className="text-sm font-black">يكسب</div>
          <button onClick={() => { loadAll(); ov.refresh(true); }} className="mr-auto text-[11px] text-zinc-300 bg-white/10 rounded-full px-3 py-1.5 press">
            ↻ تحديث
          </button>
          <div className="px-3 py-1.5 rounded-full bg-[#c4122f] font-black text-[13px] tabular-nums" title="نقاط قيد المراجعة">
            {ov.data.pendingPoints.toLocaleString()} ⏳
          </div>
          <div className="px-3 py-1.5 rounded-full bg-[#2a2a2a] font-black text-[13px] tabular-nums">
            {ov.data.points.toLocaleString()} 🪙
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 mt-4 text-center">
          <div className="rounded-xl bg-black/30 p-2">
            <div className="font-black tabular-nums">{counts.all + counts.ads}</div>
            <div className="text-[10px] text-zinc-300">عرض متاح</div>
          </div>
          <div className="rounded-xl bg-black/30 p-2">
            <div className="font-black tabular-nums">{ov.data.approvedCount}</div>
            <div className="text-[10px] text-zinc-300">مهمة مقبولة</div>
          </div>
          <div className="rounded-xl bg-black/30 p-2">
            <div className="font-black tabular-nums">{ov.data.todayAds}</div>
            <div className="text-[10px] text-zinc-300">إعلان اليوم</div>
          </div>
        </div>

        <div className="flex gap-2 mt-4 overflow-x-auto noscroll pb-1">
          {[
            { id: "all", label: "الكل", icon: "✨", n: counts.all },
            { id: "tasks", label: "المهام", icon: "📋", n: counts.tasks },
            { id: "games", label: "ألعاب", icon: "🎮", n: counts.games },
            { id: "surveys", label: "استطلاعات", icon: "☑️", n: counts.surveys },
            { id: "ads", label: "إعلانات", icon: "📺", n: counts.ads },
            { id: "mine", label: `طلباتي ${pendingMine.length ? `(${pendingMine.length})` : ""}`, icon: "📥", n: null as number | null },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => { setTab(t.id); setVisible(8); }}
              className={`shrink-0 rounded-2xl py-2.5 px-3 min-w-[86px] press ${tab === t.id ? "bg-[#8b1e1e]" : "bg-[#2b2b2b]"}`}
            >
              <div className="text-base">{t.icon}</div>
              <div className="text-[11px] font-bold mt-0.5">{t.label}</div>
              {t.n !== null && <div className="text-[10px] text-zinc-400 tabular-nums">{t.n}</div>}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 space-y-3">
        {announce && (
          <div className="rounded-2xl bg-amber-400/10 border border-amber-400/30 p-3.5">
            <div className="font-black text-sm text-amber-200">📢 {announce.title || "إعلان"}</div>
            {announce.text && <p className="text-xs text-amber-100/80 leading-6 mt-1">{announce.text}</p>}
          </div>
        )}

        {showGuide && (
          <div className="rounded-2xl bg-sky-500/10 border border-sky-500/25 p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="font-black text-sm">كيف تربح؟ 🤔</div>
              <button onClick={dismissGuide} className="text-zinc-400 text-xs px-2 py-1">إخفاء ✕</button>
            </div>
            <div className="grid grid-cols-3 gap-2 mt-3 text-center">
              {[["1️⃣", "اختر مهمة"], ["2️⃣", "نفّذ وسلّم"], ["3️⃣", "استلم نقاطك"]].map(([e, t]) => (
                <div key={t} className="rounded-xl bg-black/30 p-2.5">
                  <div className="text-lg">{e}</div>
                  <div className="text-[11px] font-bold mt-1">{t}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {ov.data.canClaim && (
          <button
            onClick={claimDaily}
            disabled={claiming}
            className="w-full rounded-2xl bg-gradient-to-l from-amber-500 to-orange-500 p-3.5 flex items-center justify-between press disabled:opacity-60"
          >
            <span className="font-black text-sm text-black">🎁 مكافأتك اليومية جاهزة (+{ov.data.todayReward})</span>
            <span className="text-xs font-black text-black bg-white/40 rounded-full px-3 py-1.5">
              {claiming ? "..." : "استلم"}
            </span>
          </button>
        )}

        <Link href="/leaderboard" prefetch className="card-dark p-3.5 flex items-center gap-3 press">
          <span className="text-2xl">🏆</span>
          <span className="flex-1">
            <span className="block font-black text-sm">لوحة الصدارة</span>
            <span className="block text-[11px] text-zinc-400 mt-0.5">شاهد الأوائل ونافسهم</span>
          </span>
          <span className="text-zinc-500">‹</span>
        </Link>

        {msg && <Notice tone={msg.tone}>{msg.text}</Notice>}

        {tab !== "ads" && tab !== "mine" && (
          <div className="flex gap-2">
            <input
              className="inp-dark"
              placeholder="ابحث عن مهمة..."
              value={q}
              onChange={(e) => { setQ(e.target.value); setVisible(8); }}
            />
            <button
              onClick={() => { setSort(sort === "top" ? "easy" : "top"); setVisible(8); }}
              className="shrink-0 px-3 rounded-xl bg-[#1c1c1f] border border-white/10 text-xs font-bold press"
              title="ترتيب"
            >
              {sort === "top" ? "💰 الأعلى" : "⚡ الأسهل"}
            </button>
          </div>
        )}

        {!loaded ? (
          <SkeletonList rows={4} />
        ) : tab === "mine" ? (
          mine.length === 0 ? (
            <div className="card-dark p-8 text-center">
              <div className="text-4xl mb-2">📥</div>
              <div className="font-black text-sm">لا طلبات بعد</div>
              <p className="text-xs text-zinc-400 mt-2">سلّم مهمة وستظهر حالتها هنا</p>
            </div>
          ) : (
            mine.map((m) => (
              <div key={m.id} className="card-dark p-4 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="font-bold text-sm truncate">{m.taskTitle}</div>
                  <div className="text-[11px] text-zinc-400 mt-0.5 tabular-nums">
                    +{usdToPoints(m.reward).toLocaleString()} نقطة · {new Date(m.createdAt).toLocaleDateString("ar")}
                  </div>
                </div>
                <StatusPill status={m.status} />
              </div>
            ))
          )
        ) : tab === "ads" ? (
          ads.length === 0 ? (
            <div className="card-dark p-8 text-center">
              <div className="text-4xl mb-2">📺</div>
              <div className="font-black text-sm">لا إعلانات متاحة الآن</div>
              <p className="text-xs text-zinc-400 mt-2">عد لاحقاً — تظهر إعلانات جديدة دورياً</p>
            </div>
          ) : (
            ads.map((ad) => {
              const pts = usdToPoints(ad.reward);
              const w = watching === ad.id;
              return (
                <div key={ad.id} className="card-dark p-4">
                  <div className="flex justify-between gap-2">
                    <div>
                      <div className="text-[10px] text-zinc-500">إعلان مكافأة · {ad.requiredSeconds} ثانية</div>
                      <div className="font-black text-sm mt-0.5">{ad.title}</div>
                    </div>
                    <div className="text-emerald-400 font-black tabular-nums whitespace-nowrap">+{pts.toLocaleString()} 🪙</div>
                  </div>
                  {w ? (
                    <div>
                      <div className="h-2 rounded-full bg-white/10 overflow-hidden mt-3">
                        <div
                          className="h-full bg-emerald-400 rounded-full"
                          style={{ width: `${((ad.requiredSeconds - count) / ad.requiredSeconds) * 100}%` }}
                        />
                      </div>
                      <div className="text-center text-xs text-zinc-300 mt-2 tabular-nums">لا تغلق الصفحة… {count}ث</div>
                    </div>
                  ) : ad.ready === false ? (
                    <div className="mt-3 text-center text-xs text-zinc-500 bg-white/5 rounded-xl py-2.5">
                      متاح بعد {fmtCooldown(ad.secondsLeft)}
                    </div>
                  ) : (
                    <button onClick={() => startAd(ad)} className="w-full mt-3 py-2.5 rounded-xl bg-[#c4122f] font-black text-sm press">
                      ▶ شاهد واربح {pts.toLocaleString()} نقطة
                    </button>
                  )}
                </div>
              );
            })
          )
        ) : list.length === 0 ? (
          <div className="card-dark p-8 text-center">
            <div className="text-4xl mb-2">🔍</div>
            <div className="font-black text-sm">لا نتائج هنا</div>
            <p className="text-xs text-zinc-400 mt-2">جرّب تبويباً آخر أو امسح البحث</p>
          </div>
        ) : (
          <>
          {list.slice(0, visible).map((t) => {
            const usd = parseFloat(t.reward);
            const pts = usdToPoints(t.reward);
            const meta = TYPE_META[t.type] || TYPE_META.other;
            const d = difficulty(usd);
            const done = doneIds.has(t.id);
            return (
              <button
                key={t.id}
                onClick={() => setOpenId(t.id)}
                className="w-full text-right card-dark p-4 press"
              >
                <div className="flex justify-between gap-3">
                  <div className="flex gap-2.5 min-w-0">
                    <div className="w-11 h-11 rounded-xl bg-white/5 flex items-center justify-center text-xl shrink-0">{meta.e}</div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="text-[10px] text-zinc-500">{meta.t}</span>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-md ${d.c}`}>{d.t}</span>
                        {done && <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-white/10 text-zinc-300">تم التقديم</span>}
                      </div>
                      <div className="font-black text-sm mt-0.5 truncate">{t.title}</div>
                      {t.description && <p className="text-xs text-zinc-400 truncate mt-0.5">{t.description}</p>}
                    </div>
                  </div>
                  <div className="text-left shrink-0">
                    <div className="text-emerald-400 font-black tabular-nums">+{pts.toLocaleString()}</div>
                    <div className="text-[10px] text-zinc-500 tabular-nums">≈ ${usd.toFixed(2)}</div>
                  </div>
                </div>
              </button>
            );
          })}
          {list.length > visible && (
            <button
              onClick={() => setVisible((v) => v + 8)}
              className="w-full py-3 rounded-2xl bg-white/5 text-sm font-bold press"
            >
              عرض المزيد ({list.length - visible} متبقٍ)
            </button>
          )}
          </>
        )}

        <p className="text-center text-[11px] text-zinc-600 pt-1">
          الأرباح من شبكات الإعلانات والعروض — لا نقاط بدون إتمام حقيقي
        </p>
      </div>

      {/* task sheet */}
      {opened && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70" onClick={() => setOpenId(null)}>
          <div
            className="w-full max-w-2xl bg-[#141416] border-t border-white/10 rounded-t-3xl p-5 pb-[calc(7rem+env(safe-area-inset-bottom,0px))] space-y-4 max-h-[88vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-white/20 mx-auto" />
            <div className="flex justify-between gap-3">
              <div>
                <div className="font-black text-lg">{opened.title}</div>
                {opened.description && <p className="text-sm text-zinc-400 mt-1 leading-7">{opened.description}</p>}
              </div>
              <div className="text-emerald-400 font-black tabular-nums whitespace-nowrap">
                +{usdToPoints(opened.reward).toLocaleString()} 🪙
              </div>
            </div>
            <div className="rounded-2xl bg-white/5 p-4 text-[13px] leading-8">
              <div className="font-black mb-2">خطوات الإتمام</div>
              <div>1️⃣ افتح رابط المهمة ونفّذ المطلوب كاملاً</div>
              <div>2️⃣ انسخ الدليل ({opened.proofHint || "اسم المستخدم / لقطة / رمز"})</div>
              <div>3️⃣ الصقه هنا واضغط تسليم — المراجعة خلال 24-72 ساعة</div>
            </div>
            {opened.targetUrl && (
              <a href={opened.targetUrl} target="_blank" rel="noreferrer" className="block text-center py-3 rounded-2xl bg-white/10 font-black press">
                🔗 فتح رابط المهمة
              </a>
            )}
            <input
              className="inp-dark"
              placeholder={opened.proofHint || "الصق الدليل هنا"}
              value={proof[opened.id] || ""}
              onChange={(e) => setProof({ ...proof, [opened.id]: e.target.value })}
            />
            <div className="flex gap-2">
              <button
                disabled={sending === opened.id}
                onClick={() => submit(opened.id)}
                className="flex-1 py-3 rounded-2xl bg-[#c4122f] font-black press disabled:opacity-50"
              >
                {sending === opened.id ? "جاري الإرسال..." : "تسليم المهمة"}
              </button>
              <button onClick={() => setOpenId(null)} className="px-5 py-3 rounded-2xl bg-white/10 font-bold">
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
