"use client";

// This used to copy a session token from localStorage into a JS-writable
// document.cookie on every page load. That defeats the httpOnly flag on
// the real session cookie set by the server (see src/lib/auth.ts) and
// gives any XSS a direct path to steal a live session — so it has been
// disabled. The server-set httpOnly cookie is sufficient on a normal,
// same-origin deployment.
export function SessionBridge() {
  return null;
}
