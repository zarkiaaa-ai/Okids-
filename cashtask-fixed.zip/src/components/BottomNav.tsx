"use client";

import Link from "next/link";
import { memo } from "react";
import { usePathname } from "next/navigation";

const TABS = [
  { href: "/", match: ["/", "/dashboard", "/tasks", "/ads"], icon: EarnIcon, label: "يكسب" },
  { href: "/withdraw", match: ["/withdraw", "/buy-points", "/topup"], icon: WalletIcon, label: "المحفظة" },
  { href: "/referrals", match: ["/referrals", "/rewards", "/contests"], icon: InviteIcon, label: "دعوة" },
  { href: "/profile", match: ["/profile"], icon: UserIcon, label: "ملفي الشخصي" },
];

function BottomNavInner() {
  const pathname = usePathname();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-50 bg-black border-t border-zinc-800 safe-nav">
      <div className="mx-auto max-w-2xl grid grid-cols-4">
        {TABS.map((tab) => {
          const active = tab.match.some((p) =>
            p === "/" ? pathname === "/" || pathname === "/dashboard" || pathname === "/tasks" : pathname === p || pathname.startsWith(p + "/")
          );
          const Icon = tab.icon;
          return (
            <Link key={tab.href} href={tab.href} prefetch={false} className="relative flex flex-col items-center py-3 gap-1.5">
              {active && <span className="absolute top-1 w-10 h-1.5 rounded-full bg-[#c4122f]" />}
              <Icon active={active} />
              <span className={`text-[13px] font-bold ${active ? "text-white" : "text-zinc-500"}`}>{tab.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export const BottomNav = memo(BottomNavInner);

function EarnIcon({ active }: { active: boolean }) {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke={active ? "#fff" : "#737373"} strokeWidth="1.8">
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v10M9.5 9.5c.7-1 2-1.5 3.2-1.2 1.5.4 2 1.6 2 2.6 0 2.2-4.7 2-4.7 4.4 0 .9.8 1.8 2.5 1.8 1.4 0 2.3-.6 2.8-1.4" />
    </svg>
  );
}
function WalletIcon({ active }: { active: boolean }) {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke={active ? "#fff" : "#737373"} strokeWidth="1.8">
      <rect x="3" y="6" width="18" height="13" rx="2" />
      <path d="M3 10h18" />
    </svg>
  );
}
function InviteIcon({ active }: { active: boolean }) {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke={active ? "#fff" : "#737373"} strokeWidth="1.8">
      <circle cx="9" cy="8" r="3" />
      <path d="M3 19c0-3 2.5-5 6-5s6 2 6 5" />
      <path d="M17 8v6M14 11h6" />
    </svg>
  );
}
function UserIcon({ active }: { active: boolean }) {
  return (
    <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke={active ? "#fff" : "#737373"} strokeWidth="1.8">
      <circle cx="12" cy="8" r="3" />
      <path d="M5 19c0-3.3 3-5.5 7-5.5s7 2.2 7 5.5" />
    </svg>
  );
}
