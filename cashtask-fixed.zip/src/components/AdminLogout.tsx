"use client";

export function AdminLogout() {
  return (
    <button
      onClick={async () => {
        await fetch("/api/auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "logout" }),
        });
        window.location.href = "/admin-login";
      }}
      className="px-3 py-1.5 rounded-lg border border-red-500/50 text-red-300 text-sm"
    >
      خروج
    </button>
  );
}
