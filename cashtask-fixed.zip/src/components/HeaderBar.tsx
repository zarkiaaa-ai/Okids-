"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useI18n } from "@/components/LanguageProvider";

export function HeaderBar() {
  const { t } = useI18n();
  const [points, setPoints] = useState(350);
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("");

  useEffect(() => {
    fetch("/api/me")
      .then((r) => r.json())
      .then((j) => {
        if (j.user) {
          setPoints(j.user.points ?? 350);
          setName(j.user.displayName || j.user.username || "");
          setAvatar(j.user.avatarUrl || "");
        }
      })
      .catch(() => {});
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-surface/90 backdrop-blur-xl border-b border-app">
      <div className="mx-auto max-w-2xl px-4 py-3 flex items-center justify-between gap-3">
        <Link href="/" className="flex items-center gap-2 min-w-0">
          {avatar.startsWith("data:") ? (
            <img src={avatar} alt="" className="w-10 h-10 rounded-2xl object-cover" />
          ) : (
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-sky-500 to-purple-600 flex items-center justify-center text-xl">
              {avatar && avatar.length <= 4 ? avatar : "💰"}
            </div>
          )}
          <div className="min-w-0">
            <div className="text-sm font-black text-gradient">CashTask</div>
            <div className="text-[11px] text-muted truncate">
              {t.hello} {name}
            </div>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-amber-50 dark:bg-amber-500/10 border border-amber-400/40">
            <span>🪙</span>
            <span className="font-black text-sm text-amber-700 dark:text-amber-300">
              {Number(points).toLocaleString("ar")}
            </span>
          </div>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}
