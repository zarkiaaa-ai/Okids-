"use client";

import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { dict, type Lang } from "@/lib/i18n";

type Ctx = {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (typeof dict)[Lang];
};

const LanguageCtx = createContext<Ctx>({
  lang: "ar",
  setLang: () => {},
  t: dict.ar,
});

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");

  useEffect(() => {
    const saved = (localStorage.getItem("lang") as Lang | null) || "ar";
    apply(saved);
    setLangState(saved);
  }, []);

  function apply(l: Lang) {
    document.documentElement.lang = l;
    document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
  }

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    localStorage.setItem("lang", l);
    apply(l);
  }, []);

  return (
    <LanguageCtx.Provider value={{ lang, setLang, t: dict[lang] }}>
      {children}
    </LanguageCtx.Provider>
  );
}

export function useI18n() {
  return useContext(LanguageCtx);
}
