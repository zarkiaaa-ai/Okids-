"use client";

import Link from "next/link";
import type { ReactNode } from "react";

export function PageHeader({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="mb-4">
      <h1 className="text-2xl font-black leading-tight">{title}</h1>
      {subtitle && <p className="text-sm text-muted mt-1">{subtitle}</p>}
    </div>
  );
}

export function BackHeader({
  href,
  title,
}: {
  href: string;
  title: string;
}) {
  return (
    <div className="flex items-center gap-3 mb-4">
      <Link
        href={href}
        className="w-10 h-10 rounded-xl bg-surface border border-app flex items-center justify-center text-lg"
        aria-label="رجوع"
      >
        →
      </Link>
      <h1 className="text-lg font-semibold tracking-tight">{title}</h1>
    </div>
  );
}

export function SectionTitle({ children }: { children: ReactNode }) {
  return <h2 className="font-black text-base mb-2">{children}</h2>;
}

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`luxury-card rounded-2xl ${className}`}>{children}</div>
  );
}

export function MenuLink({
  href,
  icon,
  title,
  subtitle,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <Link
      href={href}
      className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60"
    >
      <div className="w-11 h-11 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xl">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-bold text-sm">{title}</div>
        {subtitle && <div className="text-xs text-muted truncate">{subtitle}</div>}
      </div>
      <span className="text-muted">‹</span>
    </Link>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    pending: {
      label: "قيد المراجعة",
      cls: "bg-amber-500/10 text-amber-700 dark:text-amber-300 border-amber-500/30",
    },
    approved: {
      label: "مقبول",
      cls: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
    },
    completed: {
      label: "مكتمل",
      cls: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30",
    },
    rejected: {
      label: "مرفوض",
      cls: "bg-red-500/10 text-red-700 dark:text-red-300 border-red-500/30",
    },
  };
  const s = map[status] || map.pending;
  return (
    <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${s.cls} whitespace-nowrap`}>
      {s.label}
    </span>
  );
}

export function EmptyState({ icon, text }: { icon: string; text: string }) {
  return (
    <div className="rounded-2xl bg-surface border border-app p-8 text-center">
      <div className="text-4xl mb-2">{icon}</div>
      <p className="text-sm text-muted">{text}</p>
    </div>
  );
}

export function Alert({
  type,
  children,
}: {
  type: "ok" | "err" | "info";
  children: ReactNode;
}) {
  const cls =
    type === "ok"
      ? "bg-emerald-50 dark:bg-emerald-500/10 border-emerald-300 text-emerald-800 dark:text-emerald-300"
      : type === "err"
      ? "bg-red-50 dark:bg-red-500/10 border-red-300 text-red-800 dark:text-red-300"
      : "bg-sky-50 dark:bg-sky-500/10 border-sky-300 text-sky-800 dark:text-sky-300";
  return <div className={`px-3 py-2 rounded-xl border text-sm font-bold ${cls}`}>{children}</div>;
}
